from django.urls import path,include
from . import views
from rest_framework.routers import DefaultRouter
from .views_apis.review_api import ReviewCreateAPIView, PublicExpertReviewListAPIView, MyWrittenReviewsAPIView
from .views_apis.expert_api import LocalExpertListAPIView, ItineraryAssigningToExpertAPIView, ExpertItineraryDecisionAPIView,ExpertUpdatedItineraryView, DecisionExpertUpdatedItineraryAPIView
from .views_apis.itinerary_generate import GenerateItineraryView
from .views_apis.chat_api import ChatListAPI, ChatViewSet
from .views_apis.itinerary_api import GeneratedItineraryDetailAPIView,ListItineraryAPIView, UpdateItinerary, ShareAItineraryAPIView
from .views_apis.affiliate_platform_api import AffiliatePlatformBulkUpsertAPIView, AffiliatePlatformExploreAPIView, AffiliatePlatformBulkCreateAPIView, AffiliateTripExploreAPIView
from .views_apis.preferences import TouristPreferenceListCreateAPIView, TouristPreferenceDestroyAPIView, TouristPreferenceActivityListCreateAPIView, TouristPreferenceActivityDestroyAPIView, TouristPreferenceEventListCreateAPIView, TouristPreferenceEventDestroyAPIView
from .views_apis.validation_api import PersonalInfoValidationAPIView
from .views_apis.submit_itinerary import SubmitItineraryFeedbackCreateView, SubmitItineraryFeedbackDetailView, SubmitItineraryFeedbackUpdateView, SubmitItineraryFeedbackDeleteView, SubmitItineraryDecisionAPIView

router = DefaultRouter()
router.register(r'chats/(?P<receiver_id>[^/.]+)', ChatViewSet, basename='chat')


urlpatterns = [

    path("", include(router.urls)),
   
    # Itinerary API's
    path('my-itineraries/', ListItineraryAPIView.as_view(), name='list-itinerary'),
    path('my-itineraries/<str:id>/', GeneratedItineraryDetailAPIView.as_view(), name='generated-itinerary-detail'),
    path('itinerary/<str:trip_id>/', UpdateItinerary.as_view(), name='update-itinerary'),
    path('share/<str:id>/',ShareAItineraryAPIView.as_view(), name="share_itinerary"),

    # Expert API's
    path("local-experts/", LocalExpertListAPIView.as_view(), name="local-experts-list"),
    path("expert-assigned/", ItineraryAssigningToExpertAPIView.as_view(), name="expert-assigned-create"),
    path("expert-invitation/", ExpertItineraryDecisionAPIView.as_view(), name="expert-invitation"),
    path('expert-itinerary/<str:trip_id>/', ExpertUpdatedItineraryView.as_view(), name='expert-itinerary'),
    path('save-itinerary/<str:id>/', DecisionExpertUpdatedItineraryAPIView.as_view(), name='save-itinerary'),

    # Review API's
    path('reviews/create/', ReviewCreateAPIView.as_view(), name='create-review'),
    path('reviews/expert/<str:expert_id>/', PublicExpertReviewListAPIView.as_view(), name='public-expert-reviews'),
    path('my-reviews/', MyWrittenReviewsAPIView.as_view(), name='my-written-reviews'),

    path("discover/", views.DiscoverPlacesAPIView.as_view(), name="discover-places"),
    path("categories/", views.CategoryListAPIView.as_view(), name="category-list"),
    
    # Preferences API's
    path("preferences/", TouristPreferenceListCreateAPIView.as_view(), name="preferences-list-create"),
    path("preferences/delete/", TouristPreferenceDestroyAPIView.as_view(), name="preferences-delete"),
    path("preferences/activity/", TouristPreferenceActivityListCreateAPIView.as_view(), name="activity-preferences-list-create"),
    path("preferences/activity/<str:activity_id>/", TouristPreferenceActivityDestroyAPIView.as_view(), name="activity-preferences-delete"),
    path("preferences/event/", TouristPreferenceEventListCreateAPIView.as_view(), name="event-preferences-list-create"),
    path("preferences/event/<str:event_id>/", TouristPreferenceEventDestroyAPIView.as_view(), name="event-preferences-delete"),

    # Generate Itinerary
    path("guide/create/trip/", GenerateItineraryView.as_view(), name="create_guide_trip"),

    # path('explore/',views.TripExploreView.as_view(),name = "explore_trip"),
    path('generate-explore/',views.TripSubmitView.as_view(),name = "ai_generate_explore_trip"),

    # Affiliate API's
    path('affiliate-explore/',AffiliateTripExploreAPIView.as_view(),name="affliliate_explore"),
    path('affiliate-platforms/bulk-create/', AffiliatePlatformBulkCreateAPIView.as_view(), name='affiliate-platforms-bulk-create'),
    path('affiliate-platforms/bulk-upsert/', AffiliatePlatformBulkUpsertAPIView.as_view(), name='affiliate-platforms-bulk-upsert'),
    # path('affiliate-explore/', AffiliatePlatformExploreAPIView.as_view(), name='affiliate-platform-explore'),


    # Chat APIs
    path("chats/", ChatListAPI.as_view(), name="chat-list"),
    
    # Message Validation API
    path("validate-message/", PersonalInfoValidationAPIView.as_view(), name="validate-message"),
    

    # Submit Itinerary APIs
    path('submit-itinerary/', SubmitItineraryFeedbackCreateView.as_view(), name='feedback-create'),
    path('submit-itinerary/<uuid:pk>/', SubmitItineraryFeedbackDetailView.as_view(), name='feedback-detail'),
    path('submit-itinerary/<uuid:pk>/', SubmitItineraryFeedbackUpdateView.as_view(), name='feedback-update'),
    path('submit-itinerary/<uuid:pk>/', SubmitItineraryFeedbackDeleteView.as_view(), name='feedback-delete'),
    path('submit-itinerary/<uuid:pk>/decision/', SubmitItineraryDecisionAPIView.as_view(), name='feedback-decision'),
] 
