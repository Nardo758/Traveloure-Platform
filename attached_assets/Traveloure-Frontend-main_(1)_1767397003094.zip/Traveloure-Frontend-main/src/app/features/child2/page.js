import React from 'react'

function page() {
  return (
    <div>
      features child2 
    </div>
  )
}

export default page
