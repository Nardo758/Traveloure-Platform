from django.contrib import admin
from .models import ViatorDestination, ViatorProduct

admin.site.register(ViatorProduct)
admin.site.register(ViatorDestination)
