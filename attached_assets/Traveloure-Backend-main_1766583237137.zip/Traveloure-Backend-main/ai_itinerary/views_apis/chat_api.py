from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from ai_itinerary.models import *
from ai_itinerary.serializers import *
from django.db.models import Q, Max
from ai_itinerary.utils import ChatPagination
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer


class ChatListAPI(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user

        latest_chats = (
            UserAndExpertChat.objects
            .filter(Q(sender=user) | Q(receiver=user))
            .values("sender", "receiver")
            .annotate(latest=Max("created_at"))
            .order_by("-latest")
        )

        seen = set()
        results = []

        for chat in latest_chats:
            partner_id = chat["receiver"] if chat["sender"] == user.id else chat["sender"]
            if not partner_id or partner_id in seen:
                continue
            seen.add(partner_id)

            try:
                partner = User.objects.get(id=partner_id)
            except User.DoesNotExist:
                continue

            latest_chat = (
                UserAndExpertChat.objects.filter(
                    Q(sender=user, receiver=partner) | Q(sender=partner, receiver=user)
                ).order_by("-created_at").first()
            )

            if latest_chat:
                results.append({
                    "user": UserSerializer(partner).data,
                    "chat": UserAndExpertChatSerializer(latest_chat).data
                })

        return Response(results)
    

class ChatViewSet(viewsets.ModelViewSet):
    """
    /chats/<receiver_id>/           -> list, create (multipart for attachments)
    /chats/<receiver_id>/<pk>/      -> retrieve, update, partial_update, destroy
    """
    serializer_class = UserAndExpertChatSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = ChatPagination

    def get_queryset(self):
        user = self.request.user
        receiver_id = self.kwargs.get("receiver_id")
        return UserAndExpertChat.objects.filter(
            Q(sender=user, receiver_id=receiver_id) |
            Q(sender_id=receiver_id, receiver=user)
        ).order_by("-created_at")

    def perform_create(self, serializer):
        chat = serializer.save(
            sender=self.request.user,
            receiver_id=self.kwargs.get("receiver_id")
        )
        # Broadcast after saving (covers attachments too)
        self.broadcast_new_or_updated_chat(chat)

    def perform_update(self, serializer):
        chat = serializer.save()
        self.broadcast_new_or_updated_chat(chat)

    def perform_destroy(self, instance):
        # copy to broadcast after deletion
        snapshot = instance
        super().perform_destroy(instance)
        self.broadcast_delete_chat(snapshot)

    # Optional: restrict edits/deletes to the sender only
    def get_object(self):
        obj = super().get_object()
        if self.request.method in ("PUT", "PATCH", "DELETE"):
            if obj.sender_id != self.request.user.id:
                from rest_framework.exceptions import PermissionDenied
                raise PermissionDenied("You can modify only your own messages.")
        return obj
    

    def chat_group_name(self, a_id, b_id) -> str:
        a, b = sorted([str(a_id), str(b_id)])
        return f"chat_{a}_{b}"

    def broadcast_new_or_updated_chat(self, chat_obj):
        channel_layer = get_channel_layer()
        data = UserAndExpertChatSerializer(chat_obj).data
        sender_id = chat_obj.sender_id
        receiver_id = chat_obj.receiver_id
    
        # Receiver notification
        async_to_sync(channel_layer.group_send)(
            f"user_{receiver_id}",
            {"type": "new_message_notification", "payload": data}
        )
    
        # Room broadcast
        room = self.chat_group_name(sender_id, receiver_id)
        async_to_sync(channel_layer.group_send)(
            room,
            {"type": "chat_message", "payload": data}
        )

    def broadcast_delete_chat(self,chat_obj):
        channel_layer = get_channel_layer()
        payload = {"id": str(chat_obj.id), "deleted": True}
        sender_id = chat_obj.sender_id
        receiver_id = chat_obj.receiver_id

        # Receiver notification about deletion (optional)
        async_to_sync(channel_layer.group_send)(
            f"user_{receiver_id}",
            {"type": "new_message_notification", "payload": payload}
        )

        # Room broadcast
        room = self.chat_group_name(sender_id, receiver_id)
        async_to_sync(channel_layer.group_send)(
            room,
            {"type": "chat_message", "payload": payload}
        )