from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from .models import User
from .utils import generate_tokens
from django.core.files.base import ContentFile
import requests  # <-- Make sure this is imported
import logging
logger = logging.getLogger(__name__)
class GoogleCallbackView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        try:
            data = request.data
            email = data.get('email')
            name = data.get('name')
            picture = data.get('picture')
            google_id = data.get('google_id')
            id_token = data.get('id_token')

            if not email:
                return Response({'error': 'Email is required', 'status': False}, status=400)

            user = User.objects.filter(email=email).first()
            if not user:
                username = email.split('@')[0]
                first_name = name.split(' ')[0] if name else ''
                last_name = ' '.join(name.split(' ')[1:]) if name and len(name.split(' ')) > 1 else ''
                user = User.objects.create(
                email=email,
                username=username,
                first_name=first_name,
                last_name=last_name,
                is_email_verified=True,
                is_active=True
            )
                # Save profile picture
                if picture:
                    try:
                        response = requests.get(picture)
                        if response.status_code == 200:
                            avatar_content = ContentFile(response.content)
                            user.image.save(f"{user.id}_avatar.jpg", avatar_content)
                    except Exception as e:
                        logger.error(f"Error downloading profile picture: {e}")
            try:
                from rest_framework_simplejwt.tokens import RefreshToken
                refresh = RefreshToken.for_user(user)
                access_token = refresh.access_token
                
                # Determine user roles - always include 'user' as base role
                roles = ['user']  # All users get the 'user' role
                if user.is_superuser:
                    roles.append('admin')
                if user.is_local_expert:
                    roles.append('local_expert')
                if user.is_service_provider:
                    roles.append('service_provider')
                
                # Convert timestamp to ISO format
                from datetime import datetime
                expires_datetime = datetime.fromtimestamp(access_token['exp'])
                expires_iso = expires_datetime.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'
                
                # Create the exact response structure you want
                response_data = {
                    "user": {
                        "id": str(user.id),
                        "name": f"{user.first_name} {user.last_name}".strip(),
                        "email": user.email,
                        "last_name": user.last_name,
                        "roles": roles
                    },
                    "expires": expires_iso,
                    "accessToken": str(access_token),
                    "refreshToken": str(refresh),
                    "backendData": {
                        "access": str(access_token),
                        "refresh": str(refresh),
                        "accessToken": str(access_token),  # Added at backendData level too
                        "refreshToken": str(refresh),      # Added at backendData level too
                        "user": {
                            "email": user.email,
                            "name": f"{user.first_name} {user.last_name}".strip(),
                            "image": user.image.url if user.image else None,
                            "id": str(user.id),
                            "first_name": user.first_name,
                            "last_name": user.last_name
                        }
                    },
                    "expiresAt": None
                }
                
                return Response(response_data, status=200)
            except Exception as e:
                return Response({'error': f"Token error: {str(e)}", 'status': False}, status=400)

        except Exception as e:
            return Response({'error': f"Outer error: {str(e)}", 'status': False}, status=400)