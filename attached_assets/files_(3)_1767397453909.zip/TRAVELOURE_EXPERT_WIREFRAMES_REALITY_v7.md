# TRAVELOURE EXPERT INTEGRATION - ACTUAL IMPLEMENTATION WIREFRAMES
## Based on Real Frontend Code + Recommended Evolution

**Version**: 7.0 - Reality-Based Expert Integration  
**Last Updated**: January 2, 2026  
**Source**: Analysis of Traveloure-Frontend-main codebase  
**Status**: Current Implementation + Evolution Roadmap

---

## TABLE OF CONTENTS

### PART I: CURRENT IMPLEMENTATION (AS BUILT)
1. [Current Expert Flow](#current-expert-flow)
2. [Expert Marketplace Page (Built)](#expert-marketplace-page-built)
3. [Chat Interface (Built)](#chat-interface-built)
4. [Contract System (Built)](#contract-system-built)
5. [Payment Flow (Built)](#payment-flow-built)

### PART II: EVOLUTION PATH (TO BUILD)
6. [Adding Expert Profile Pages](#adding-expert-profile-pages)
7. [Expert Services Menu System](#expert-services-menu-system)
8. [Self-Service Booking Flow](#self-service-booking-flow)
9. [Integration with DIY Commerce](#integration-with-diy-commerce)

### PART III: UNIFIED SYSTEM
10. [Dual-Path Landing Page](#dual-path-landing-page)
11. [Expert Tab in Trip Planning](#expert-tab-in-trip-planning)
12. [Complete User Journeys](#complete-user-journeys)

---

## CURRENT EXPERT FLOW

### How It Works Today (Based on Code)

```
USER JOURNEY:
┌─────────────────────────────────────────────────────────────┐
│ 1. Homepage → Click "Work with Expert"                      │
│         ↓                                                    │
│ 2. /experts page → Browse expert list with filters          │
│         ↓                                                    │
│ 3. Click "Chat Now" on expert                               │
│         ↓                                                    │
│ 4. Real-time chat opens (WebSocket connection)              │
│         ↓                                                    │
│ 5. User explains needs via chat                             │
│         ↓                                                    │
│ 6. Expert creates & sends Contract through chat             │
│         ↓                                                    │
│ 7. User sees contract in chat → Accept or Reject            │
│         ↓                                                    │
│ 8. If accepted → Redirects to Stripe payment                │
│         ↓                                                    │
│ 9. Payment confirmed → Expert notified → Service begins     │
│         ↓                                                    │
│10. Expert delivers itinerary/service through chat           │
└─────────────────────────────────────────────────────────────┘
```

**Key Characteristics:**
- ✅ Chat-first approach (must talk to expert before booking)
- ✅ Expert manually creates contract for each client
- ✅ Real-time communication throughout
- ✅ Payment integrated with Stripe
- ❌ No pre-defined service packages (experts menu under construction)
- ❌ No self-service selection (requires chat initiation)

---

## EXPERT MARKETPLACE PAGE (BUILT)

### `/experts` - Current Implementation

**File**: `src/app/experts/page.jsx`

```
┌────────────────────────────────────────────────────────────────────┐
│ [NAVBAR]                                     🛒 Cart    [Profile]  │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  ← Back                                                            │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  RECOMMENDED TRAVEL EXPERTS FOR YOU                          │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│  FILTERS:                                                          │
│  ┌────────────────────────────────────────────────────────────┐   │
│  │ 🔍 Search experts...                                       │   │
│  │                                                            │   │
│  │ Location: [Select Country ▼]                              │   │
│  │ Language: [Select Language ▼]                             │   │
│  │ Specialty: [Select ▼]                                     │   │
│  │ Rating: ⭐ 4+ stars                                        │   │
│  └────────────────────────────────────────────────────────────┘   │
│                                                                    │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│  EXPERT CARDS (Grid Layout):                                       │
│                                                                    │
│  ┌─────────────────────────┐  ┌─────────────────────────┐         │
│  │ [Profile Photo]         │  │ [Profile Photo]         │         │
│  │                         │  │                         │         │
│  │ MARIA DUBOIS            │  │ JEAN-LUC MARTIN         │         │
│  │ Paris Travel Expert     │  │ Food & Wine Expert      │         │
│  │                         │  │                         │         │
│  │ ⭐ 4.8/5.0 (650 reviews)│  │ ⭐ 4.9/5.0 (430 reviews)│         │
│  │                         │  │                         │         │
│  │ 🌍 Countries:           │  │ 🌍 Countries:           │         │
│  │ Italy, France, Spain    │  │ France, Italy           │         │
│  │                         │  │                         │         │
│  │ 💬 Languages:           │  │ 💬 Languages:           │         │
│  │ English, French, Spanish│  │ English, French         │         │
│  │                         │  │                         │         │
│  │ Specializing in Coastal │  │ Specializing in         │         │
│  │ Adventures and Hidden   │  │ Culinary Experiences    │         │
│  │ Gems                    │  │ and Wine Tours          │         │
│  │                         │  │                         │         │
│  │      [Chat Now →]       │  │      [Chat Now →]       │         │
│  └─────────────────────────┘  └─────────────────────────┘         │
│                                                                    │
│  ┌─────────────────────────┐  ┌─────────────────────────┐         │
│  │ [More expert cards...]  │  │ [More expert cards...]  │         │
│  └─────────────────────────┘  └─────────────────────────┘         │
│                                                                    │
│  [Load More Experts...]                                            │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

**Static Data Used** (from code):
```javascript
const staticExpertData = {
  rating: "4.8/5.0",
  reviews: 650,
  languages: ["English", "French", "Spanish"],
  countries: ["Italy", "France", "Spain", "Britain"],
  specialization: "Specializing in Coastal Adventures and Hidden Gems",
  image: "/dealperson.png"
}
```

---

## CHAT INTERFACE (BUILT)

### Real-Time Expert Chat (WebSocket)

**Component**: `ChatInterface` used in `/experts/page.jsx`

```
┌────────────────────────────────────────────────────────────────────┐
│ ← Back to Experts          [Photo] Maria Dubois      [Create      │
│                                    Online            Contract]     │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  MESSAGES AREA (Scrollable)                                        │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │ Hi! I'd like help planning a Paris trip for my anniversary.  │ │
│  │ We're going Jan 2-9, 2026.                           12:30pm │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│           ┌────────────────────────────────────────────────────┐  │
│           │ Wonderful! I'd love to help make it special. Tell │  │
│           │ me about your interests - food, culture, romance? │  │
│           │ 12:31pm                                           │  │
│           └────────────────────────────────────────────────────┘  │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │ Definitely romantic and great food! Budget around $2,500.    │ │
│  │ We love authentic local experiences.                  12:32pm│ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│           ┌────────────────────────────────────────────────────┐  │
│           │ Perfect! I can create a custom itinerary for you. │  │
│           │ Let me send you a proposal...                     │  │
│           │ 12:33pm                                           │  │
│           └────────────────────────────────────────────────────┘  │
│                                                                    │
│  [CONTRACT MESSAGE - See next section]                             │
│                                                                    │
├────────────────────────────────────────────────────────────────────┤
│  📎 Attach │ [Type your message...                    ] [Send →]  │
└────────────────────────────────────────────────────────────────────┘
```

**Features from Code:**
- Real-time messaging via WebSocket
- Message history persists
- Attachment support (images, PDFs)
- Online/offline status
- Contract messages rendered differently
- Itinerary messages rendered differently

---

## CONTRACT SYSTEM (BUILT)

### Contract Message in Chat

**Component**: `ContractMessage`

```
┌────────────────────────────────────────────────────────────────────┐
│           ┌────────────────────────────────────────────────────┐  │
│           │ 📋 CONTRACT PROPOSAL                               │  │
│           ├────────────────────────────────────────────────────┤  │
│           │                                                    │  │
│           │ Title: Paris Anniversary Trip - Full Planning     │  │
│           │                                                    │  │
│           │ Description:                                       │  │
│           │ I will create a complete 7-day romantic itinerary  │  │
│           │ for your Paris trip including:                     │  │
│           │ • Restaurant reservations at 3 amazing spots       │  │
│           │ • Skip-line tickets for major attractions          │  │
│           │ • Hidden gem recommendations                       │  │
│           │ • Day-by-day schedule with maps                    │  │
│           │ • 24/7 WhatsApp support during trip                │  │
│           │                                                    │  │
│           │ Amount: $249                                       │  │
│           │                                                    │  │
│           │ Terms:                                             │  │
│           │ - Itinerary delivered within 48 hours              │  │
│           │ - Unlimited revisions until you're happy           │  │
│           │ - Full refund if not satisfied                     │  │
│           │                                                    │  │
│           │ Status: ⏳ Pending                                 │  │
│           │                                                    │  │
│           │ [Accept Contract]  [Reject Contract]               │  │
│           │                                                    │  │
│           │ 12:34pm                                            │  │
│           └────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────┘
```

**Contract States** (from code):
```javascript
Status Options:
- "pending" - Awaiting user response
- "accepted" - User accepted, payment URL generated
- "rejected" - User declined
- "paid" - Payment completed
```

**User Actions**:
- **Accept** → Generates Stripe payment link
- **Reject** → Contract marked as rejected, expert notified
- **Chat** → Can ask questions before accepting

---

## PAYMENT FLOW (BUILT)

### When User Accepts Contract

```
┌────────────────────────────────────────────────────────────────────┐
│           ┌────────────────────────────────────────────────────┐  │
│           │ ✅ CONTRACT ACCEPTED                               │  │
│           ├────────────────────────────────────────────────────┤  │
│           │                                                    │  │
│           │ Title: Paris Anniversary Trip - Full Planning     │  │
│           │ Amount: $249                                       │  │
│           │                                                    │  │
│           │ Status: ✅ Accepted - Payment Required            │  │
│           │                                                    │  │
│           │         [Pay Now via Stripe →]                    │  │
│           │                                                    │  │
│           │ You'll be redirected to secure payment...          │  │
│           │                                                    │  │
│           │ 12:35pm                                            │  │
│           └────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────┘

                         ↓ Click "Pay Now"

┌────────────────────────────────────────────────────────────────────┐
│ [STRIPE PAYMENT PAGE]                                              │
│                                                                    │
│ Pay Maria Dubois - Traveloure                                      │
│                                                                    │
│ Paris Anniversary Trip - Full Planning                             │
│ $249.00                                                            │
│                                                                    │
│ Card Number: [____-____-____-____]                                │
│ Expiry: [MM/YY]  CVC: [___]                                       │
│                                                                    │
│ [Pay $249.00]                                                      │
└────────────────────────────────────────────────────────────────────┘

                         ↓ Payment Complete

┌────────────────────────────────────────────────────────────────────┐
│           ┌────────────────────────────────────────────────────┐  │
│           │ 💚 PAYMENT SUCCESSFUL                              │  │
│           ├────────────────────────────────────────────────────┤  │
│           │                                                    │  │
│           │ Contract: Paris Anniversary Trip - Full Planning   │  │
│           │ Amount: $249 ✅ PAID                               │  │
│           │                                                    │  │
│           │ Maria has been notified and will start working on  │  │
│           │ your itinerary. Expect delivery within 48 hours.   │  │
│           │                                                    │  │
│           │ You can track progress here in chat!               │  │
│           │                                                    │  │
│           │ 12:37pm                                            │  │
│           └────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────┘
```

**Payment Integration** (from code):
- Stripe payment URL generated on contract acceptance
- Payment confirmation updates contract status
- WebSocket notifies expert of payment
- Contract status becomes "paid"

---

## ADDING EXPERT PROFILE PAGES

### NEW: `/experts/[expertId]` - Profile & Services

**What to Build:**
Individual expert page showing bio + services menu

```
┌────────────────────────────────────────────────────────────────────┐
│ [NAVBAR]                                     🛒 Cart    [Profile]  │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  ← Back to All Experts                                             │
│                                                                    │
│  ┌────────────────────────────────────────────────────────────┐   │
│  │                                                            │   │
│  │  [Large Profile Photo]    MARIA DUBOIS                     │   │
│  │                          Paris Travel Expert               │   │
│  │                          ⭐ 4.8 (247 reviews)               │   │
│  │                          💬 Responds in <2 hours           │   │
│  │                          🌍 EN, FR, ES                     │   │
│  │                          📍 Paris, France                  │   │
│  │                                                            │   │
│  │  [Book Service]  [Chat Now]  [View Reviews]               │   │
│  │                                                            │   │
│  └────────────────────────────────────────────────────────────┘   │
│                                                                    │
│  [About] [Services ✓] [Reviews] [Portfolio]                       │
│                                                                    │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│  MY SERVICES                                                       │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  ☎️ QUICK CONSULTATION                              $29     │ │
│  ├──────────────────────────────────────────────────────────────┤ │
│  │  30-minute video or phone call                               │ │
│  │  • Answer specific questions about Paris                     │ │
│  │  • Best neighborhoods, restaurants, timing                   │ │
│  │  • Quick validation of your plans                            │ │
│  │                                                              │ │
│  │  ⏱️ 30 minutes  📅 Usually available same day                │ │
│  │                                                              │ │
│  │  [Select This Service]                                       │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  📋 TRIP CART REVIEW & OPTIMIZATION                  $49     │ │
│  ├──────────────────────────────────────────────────────────────┤ │
│  │  I'll review your complete trip cart and provide:            │ │
│  │  • Better deals & alternatives                               │ │
│  │  • Hidden gems you're missing                                │ │
│  │  • Time/route optimization                                   │ │
│  │  • Detailed PDF recommendations                              │ │
│  │                                                              │ │
│  │  ⏱️ 24-48 hour delivery  💰 Typical savings: $200-400       │ │
│  │                                                              │ │
│  │  [Select This Service]                                       │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  ⭐ FULL TRIP PLANNING                              $249    │ │
│  ├──────────────────────────────────────────────────────────────┤ │
│  │  Complete planning from start to finish:                     │ │
│  │  • Custom itinerary based on your preferences                │ │
│  │  • Restaurant reservations (impossible-to-get spots)         │ │
│  │  • Skip-line tickets & activity bookings                     │ │
│  │  • Day-by-day schedule with maps                             │ │
│  │  • 24/7 WhatsApp support during trip                         │ │
│  │  • Unlimited revisions                                       │ │
│  │                                                              │ │
│  │  ⏱️ 48-72 hour delivery  💯 Satisfaction guaranteed         │ │
│  │                                                              │ │
│  │  [Select This Service] ⭐ MOST POPULAR                      │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│  💡 Not sure which service? [Schedule Free 10-min Intro Call]     │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

**New Route**: `src/app/experts/[expertId]/page.jsx`

**Backend Needed**:
```javascript
// GET /api/experts/{expertId}/services
Response: [
  {
    id: 1,
    title: "Quick Consultation",
    description: "30-minute call...",
    price: 29,
    duration: "30 minutes",
    delivery_time: "Same day",
    service_type: "call"
  },
  {
    id: 2,
    title: "Cart Review",
    description: "Review your cart...",
    price: 49,
    duration: "24-48 hours",
    service_type: "review"
  },
  // etc.
]
```

---

## EXPERT SERVICES MENU SYSTEM

### Expert Dashboard - Create Services

**File to Complete**: `src/app/local-expert/services/page.jsx`

Currently shows "Under Construction" - needs to be built.

```
┌────────────────────────────────────────────────────────────────────┐
│ LOCAL EXPERT DASHBOARD - Maria Dubois                             │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ [Dashboard] [Bookings] [Chats] [Services ✓] [Earnings]           │
│                                                                    │
│  ALL SERVICES                                  [+ Add New Service] │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  ☎️ Quick Consultation                              $29      │ │
│  │  Active • Bookings: 47                                       │ │
│  │  [Edit] [Disable] [View Stats]                               │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  📋 Cart Review                                      $49      │ │
│  │  Active • Bookings: 89                                       │ │
│  │  [Edit] [Disable] [View Stats]                               │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  ⭐ Full Trip Planning                               $249     │ │
│  │  Active • Bookings: 111                                      │ │
│  │  [Edit] [Disable] [View Stats]                               │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

**Service Creation Form**:
```
┌────────────────────────────────────────────────────────────────────┐
│ CREATE NEW SERVICE                                        [✕]      │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ Service Title:                                                     │
│ [Quick Consultation                                           ]    │
│                                                                    │
│ Service Type:                                                      │
│ ● Call/Video  ○ Cart Review  ○ Full Planning  ○ Custom           │
│                                                                    │
│ Description:                                                       │
│ [                                                             ]    │
│ [                                                             ]    │
│ [                                                             ]    │
│                                                                    │
│ Price: $[29    ]                                                   │
│                                                                    │
│ Duration/Delivery:                                                 │
│ [30 minutes / Same day                                        ]    │
│                                                                    │
│ What's Included: (bullet points)                                   │
│ • [Answer specific questions                                  ]    │
│ • [Neighborhood recommendations                               ]    │
│ • [+ Add bullet]                                                   │
│                                                                    │
│ Availability:                                                      │
│ ☑ Available now  ☐ Limited slots  ☐ By request                   │
│                                                                    │
│                   [Cancel]  [Create Service]                       │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

---

## SELF-SERVICE BOOKING FLOW

### When User Selects Service from Profile

```
USER CLICKS "Select This Service" on Maria's Profile
                    ↓
┌────────────────────────────────────────────────────────────────────┐
│ BOOKING CONFIRMATION                                      [✕]      │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ You're booking:                                                    │
│                                                                    │
│ ┌──────────────────────────────────────────────────────────────┐  │
│ │ Cart Review & Optimization                              $49   │  │
│ │ with Maria Dubois                                            │  │
│ │                                                              │  │
│ │ What happens next:                                           │  │
│ │ 1. Maria will be notified of your booking                    │  │
│ │ 2. She'll request access to your cart                        │  │
│ │ 3. You'll receive detailed recommendations in 24-48 hours    │  │
│ │ 4. Ask questions via chat anytime                            │  │
│ └──────────────────────────────────────────────────────────────┘  │
│                                                                    │
│ Your Trip Cart:                                                    │
│ • Paris, France - Jan 2-9, 2026                                   │
│ • Current total: $2,112                                            │
│ • 6 items (activities, hotel, services)                           │
│                                                                    │
│ Additional Notes for Maria: (optional)                             │
│ [We love romantic spots and great food!                      ]    │
│ [                                                             ]    │
│                                                                    │
│ Total: $49.00                                                      │
│                                                                    │
│         [Cancel]  [Confirm & Pay →]                                │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

                    ↓ Click "Confirm & Pay"

Redirects to Stripe payment (same as current system)
                    ↓
Payment Complete → Auto-generates Contract → Expert Notified
                    ↓
Opens chat with Maria (same chat interface as current system)
```

**Backend Flow**:
```javascript
// When user selects service:
POST /api/bookings/create
{
  expert_id: 123,
  service_id: 2,
  trip_cart_id: 456,
  notes: "We love romantic spots..."
}

Response:
{
  booking_id: 789,
  payment_url: "https://checkout.stripe.com/...",
  contract: {
    id: 101,
    title: "Cart Review",
    amount: 49,
    status: "pending_payment"
  }
}

// After payment:
Webhook from Stripe → Update contract status to "paid"
                   → Notify expert via WebSocket
                   → Create/open chat room
```

---

## INTEGRATION WITH DIY COMMERCE

### Adding "Experts" Tab to Trip Planning

**Update**: `src/app/create-trip/page.js` (or equivalent)

```
┌────────────────────────────────────────────────────────────────────┐
│ Paris • Jan 2-9, 2026              🛒 Cart: $2,112 (6 items)      │
├─────────────────────────────┬──────────────────────────────────────┤
│                             │                                      │
│ [Activities] [Hotels]       │  ┌────────────────────────────────┐ │
│ [Services] [Experts ✓]      │  │      [INTERACTIVE MAP]         │ │
│ [AI Optimization]           │  └────────────────────────────────┘ │
│                             │                                      │
│  PARIS TRAVEL EXPERTS       │  ┌────────────────────────────────┐ │
│                             │  │ YOUR CART                      │ │
│  💡 Get expert help with    │  ├────────────────────────────────┤ │
│  your Paris trip!           │  │ ACTIVITIES (3)        $522     │ │
│                             │  │ HOTEL (7 nights)    $1,330     │ │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━ │  │ SERVICES (3)          $260     │ │
│                             │  │ ━━━━━━━━━━━━━━━━━━━━━━━━━━━   │ │
│  RECOMMENDED FOR YOU:       │  │ SUBTOTAL            $2,112     │ │
│                             │  └────────────────────────────────┘ │
│  ┌───────────────────────┐ │                                      │
│  │ [Photo] MARIA DUBOIS  │ │                                      │
│  │ ⭐ 5.0 (247 reviews)  │ │                                      │
│  │ Paris Travel Expert   │ │                                      │
│  │                       │ │                                      │
│  │ "I can review your    │ │                                      │
│  │ cart and typically    │ │                                      │
│  │ save clients $300-400 │ │                                      │
│  │ while adding hidden   │ │                                      │
│  │ local gems!"          │ │                                      │
│  │                       │ │                                      │
│  │ Services from: $29    │ │                                      │
│  │                       │ │                                      │
│  │ [View Services]       │ │                                      │
│  │ [Chat Now]            │ │                                      │
│  └───────────────────────┘ │                                      │
│                             │                                      │
│  ┌───────────────────────┐ │                                      │
│  │ [Photo] JEAN-LUC      │ │                                      │
│  │ ⭐ 4.9 (183 reviews)  │ │                                      │
│  │ Food & Wine Specialist│ │                                      │
│  │ Services from: $29    │ │                                      │
│  │ [View Services]       │ │                                      │
│  └───────────────────────┘ │                                      │
│                             │                                      │
│  [Browse All Paris Experts] │                                      │
│                             │                                      │
└─────────────────────────────┴──────────────────────────────────────┘
```

**OR add expert service directly to cart:**

```
In cart sidebar:

┌────────────────────────────────────────┐
│ YOUR CART                              │
├────────────────────────────────────────┤
│ ACTIVITIES (3)                  $522   │
│ HOTEL (7 nights)              $1,330   │
│ SERVICES (3)                    $260   │
│ EXPERT SERVICES (1)              $49   │  ← NEW
│ • Cart Review - Maria Dubois           │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│ SUBTOTAL                      $2,161   │
│ Platform Fee                      $0   │
│ (waived with expert service)           │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│ TOTAL                         $2,161   │
│                                        │
│ [Proceed to Checkout →]                │
└────────────────────────────────────────┘
```

---

## DUAL-PATH LANDING PAGE

### Updated Homepage Design

```
┌────────────────────────────────────────────────────────────────────┐
│                     [Hero Background Image]                        │
│                                                                    │
│  [NAVBAR]                            🛒 Cart: $0        [Sign In]  │
│                                                                    │
│              ╔════════════════════════════════════╗                │
│              ║  PLAN YOUR PERFECT EXPERIENCE      ║                │
│              ╚════════════════════════════════════╝                │
│                                                                    │
│          Choose how you'd like to get started:                     │
│                                                                    │
│  ┌─────────────────────────────┐  ┌─────────────────────────────┐ │
│  │  🛍️ BROWSE & BUILD          │  │  👤 WORK WITH AN EXPERT     │ │
│  │                             │  │                             │ │
│  │  Explore real inventory,    │  │  Get personalized help from │ │
│  │  add to cart, get AI        │  │  verified local experts     │ │
│  │  optimization               │  │                             │ │
│  │                             │  │                             │ │
│  │  ✓ Browse activities        │  │  ✓ Chat with experts        │ │
│  │  ✓ Compare hotels           │  │  ✓ Get custom itineraries   │ │
│  │  ✓ Book services            │  │  ✓ Save time & money        │ │
│  │  ✓ Add expert anytime       │  │  ✓ 24/7 support             │ │
│  │                             │  │                             │ │
│  │  Popular for:               │  │  Popular for:               │ │
│  │  • Quick trips              │  │  • First-time visitors      │ │
│  │  • Familiar destinations    │  │  • Complex itineraries      │ │
│  │  • Budget travelers         │  │  • Special occasions        │ │
│  │                             │  │                             │ │
│  │  [Start Browsing - Free →] │  │  [Browse Experts - $29+ →]  │ │
│  └─────────────────────────────┘  └─────────────────────────────┘ │
│                                                                    │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│  🌟 MEET OUR LOCAL EXPERTS                                         │
│                                                                    │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐          │
│  │ [Photo]  │  │ [Photo]  │  │ [Photo]  │  │ [Photo]  │          │
│  │ Maria    │  │ Jean-Luc │  │ Priya    │  │ Kenji    │          │
│  │ Paris    │  │ Paris    │  │ Mumbai   │  │ Kyoto    │          │
│  │ ⭐ 5.0   │  │ ⭐ 4.9   │  │ ⭐ 5.0   │  │ ⭐ 4.9   │          │
│  │ $29+     │  │ $29+     │  │ $29+     │  │ $29+     │          │
│  │ [View]   │  │ [View]   │  │ [View]   │  │ [View]   │          │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘          │
│                                                                    │
│  [Browse All 2,847 Experts Worldwide →]                            │
│                                                                    │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│  BROWSE BY EXPERIENCE TYPE                                         │
│  [Travel] [Wedding] [Proposal] [Date Night] [Birthday] [Corporate]│
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

---

## COMPLETE USER JOURNEYS

### Journey 1: DIY User Adds Expert Mid-Planning

```
1. User starts DIY: "Browse & Build" → Create Trip → Paris
2. User browses activities, hotels → Builds cart ($2,112)
3. User clicks "Experts" tab in trip planner
4. Sees recommended Paris experts
5. Clicks "View Services" on Maria
6. Selects "Cart Review - $49"
7. Confirms booking → Pays via Stripe
8. Chat automatically opens with Maria
9. Maria reviews cart, sends suggestions
10. User accepts changes → Updates cart
11. Proceeds to checkout with optimized cart
```

**Result**: DIY user got expert help when needed, saved $300+

---

### Journey 2: Expert-First User

```
1. User clicks "Work with Expert" on homepage
2. Lands on /experts marketplace
3. Filters by Paris + French language
4. Views Maria's profile
5. Reads about her services
6. Two options:
   
   OPTION A - Self Service:
   - Clicks "Select This Service" on Full Planning ($249)
   - Fills in trip details
   - Pays via Stripe
   - Chat opens automatically
   - Maria starts planning
   
   OPTION B - Chat First:
   - Clicks "Chat Now"
   - Explains needs via chat
   - Maria sends custom contract
   - User accepts & pays
   - Same flow as current system
```

**Result**: User got expert help from start, zero planning stress

---

### Journey 3: Expert Browsing While Building

```
1. User on DIY path, building Paris cart
2. Cart shows: "Want expert help? Browse Paris experts"
3. User clicks, sees experts in sidebar
4. Clicks "View Profile" on Maria
5. Reviews her services without leaving trip page
6. Adds "Quick Consultation - $29" to cart
7. Continues browsing activities
8. Checks out - pays for activities + expert service together
9. Maria gets notification, reaches out via chat
10. 30-min call scheduled
```

**Result**: Seamless integration, expert service like any other purchase

---

## IMPLEMENTATION PRIORITY

### Phase 1: Complete Expert Services CRUD (2-3 weeks)
```
Backend:
- Service model & database
- CRUD endpoints
- Link services to experts

Frontend:
- Complete /local-expert/services/page.jsx
- Service creation/management UI
```

### Phase 2: Expert Profile Pages (1-2 weeks)
```
Frontend:
- Create /experts/[expertId]/page.jsx
- Display services menu
- "Select Service" action
```

### Phase 3: Self-Service Booking (1 week)
```
Backend:
- Auto-generate contracts from service selection
- Webhook handling

Frontend:
- Service booking modal
- Auto-open chat after booking
```

### Phase 4: DIY Integration (1 week)
```
Frontend:
- Add "Experts" tab to trip planner
- Expert recommendations in cart
- Unified checkout
```

---

## KEY TECHNICAL NOTES

### Contract Auto-Generation
When user selects a service (vs chat-first), auto-create contract:

```javascript
// On service booking:
const contract = {
  title: service.title, // "Cart Review"
  description: service.description,
  amount: service.price, // 49
  terms: service.terms || defaultTerms,
  expert_id: expert.id,
  traveler_id: user.id,
  service_id: service.id,
  status: "pending_payment"
}

// Generate Stripe payment link
// On payment success → status = "paid"
// WebSocket notify expert
// Open chat room
```

This plugs into existing contract system with zero changes to:
- `ContractMessage` component
- Payment flow
- WebSocket notifications
- Chat system

---

## SUMMARY

**Current System (Built):**
- Chat-first expert engagement
- Manual contract creation by expert
- Real-time messaging
- Stripe payment integration
- ✅ Works great for personalized service

**Evolution (To Build):**
- Expert profile pages with service menu
- Self-service booking option
- Auto-contract generation
- Integration with DIY cart
- ✅ Adds convenience without losing personalization

**Result:**
Users can choose their path - chat first for personalized guidance, or self-service for speed. Both funnel to same proven contract/payment/chat system.

---

This wireframe set matches your actual implementation and provides clear build instructions!