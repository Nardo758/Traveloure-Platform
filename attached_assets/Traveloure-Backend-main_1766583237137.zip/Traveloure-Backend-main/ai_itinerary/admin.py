from django.contrib import admin
from .models import (
    Trip, GeneratedItinerary, TripExpertAdvisor, ReviewRating, ExpertUpdatedItinerary,
    TouristPlacesSearches, TouristPlaceResults, TouristPreferences,
    TouristHelpMeGuideActivities, TouristHelpMeGuideEvents,
    TouristPlaceCategory, HelpGuideTrip, LiveEvent,
    TripSelectedPlace, TripSelectedHotel, TripSelectedService, TripOtherService, TripSelectedFlight,
    AffiliateTrip, AffiliatePlatform, SubmitItineraryFeedback, UserAndExpertChat
)

# ---- GENERIC ADMIN CLASS ----
class DefaultAdmin(admin.ModelAdmin):
    list_display = ('id',)
    search_fields = ('id',)
    list_filter = ()
    ordering = ('-id',)


# ---- CUSTOM DISPLAY ADMIN CLASSES ----

@admin.register(Trip)
class TripAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'title', 'destination', 'start_date', 'end_date', 'status')
    search_fields = ('id', 'title', 'destination', 'user__email')
    list_filter = ('status', 'destination', 'start_date')


@admin.register(GeneratedItinerary)
class GeneratedItineraryAdmin(admin.ModelAdmin):
    list_display = ('id', 'trip', 'status', 'created_at')
    search_fields = ('id', 'trip__title', 'trip__destination')


@admin.register(TripExpertAdvisor)
class TripExpertAdvisorAdmin(admin.ModelAdmin):
    list_display = ('id', 'trip', 'local_expert', 'status', 'assigned_at')
    search_fields = ('trip__title', 'local_expert__email')
    list_filter = ('status',)


@admin.register(ReviewRating)
class ReviewRatingAdmin(admin.ModelAdmin):
    list_display = ('id', 'local_expert', 'reviewer', 'rating', 'created_at')
    search_fields = ('local_expert__email', 'reviewer__email')
    list_filter = ('rating',)


@admin.register(ExpertUpdatedItinerary)
class ExpertUpdatedItineraryAdmin(admin.ModelAdmin):
    list_display = ('id', 'trip', 'created_by', 'status', 'created_at')
    search_fields = ('trip__title', 'created_by__email')
    list_filter = ('status',)


# ---- TOURIST MODELS ----

@admin.register(TouristPlacesSearches)
class TouristPlacesSearchesAdmin(DefaultAdmin):
    list_display = ('id', 'search')


@admin.register(TouristPlaceResults)
class TouristPlaceResultsAdmin(admin.ModelAdmin):
    list_display = ('id', 'search', 'place', 'city', 'country', 'category')
    search_fields = ('place', 'city', 'country')
    list_filter = ('country', 'city', 'category')


@admin.register(TouristPreferences)
class TouristPreferencesAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'preference')


@admin.register(TouristHelpMeGuideActivities)
class TouristHelpMeGuideActivitiesAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'location', 'activity')


@admin.register(TouristHelpMeGuideEvents)
class TouristHelpMeGuideEventsAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'location')


@admin.register(TouristPlaceCategory)
class TouristPlaceCategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'created_at')


@admin.register(HelpGuideTrip)
class HelpGuideTripAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'title', 'country', 'city', 'price', 'start_date', 'end_date')
    search_fields = ('title', 'country', 'city')


@admin.register(LiveEvent)
class LiveEventAdmin(admin.ModelAdmin):
    list_display = ('id', 'search', 'title', 'start_date')


# ---- TRIP SELECTION MODELS ----

@admin.register(TripSelectedPlace)
class TripSelectedPlaceAdmin(admin.ModelAdmin):
    list_display = ('id', 'trip', 'name', 'rating')


@admin.register(TripSelectedHotel)
class TripSelectedHotelAdmin(admin.ModelAdmin):
    list_display = ('id', 'trip', 'name', 'rating', 'price_range')


@admin.register(TripSelectedService)
class TripSelectedServiceAdmin(admin.ModelAdmin):
    list_display = ('id', 'trip', 'name', 'service_type')


@admin.register(TripOtherService)
class TripOtherServiceAdmin(admin.ModelAdmin):
    list_display = ('id', 'trip')


@admin.register(TripSelectedFlight)
class TripSelectedFlightAdmin(admin.ModelAdmin):
    list_display = ('id', 'trip', 'name', 'origin', 'destination', 'departure_date')


# ---- AFFILIATE MODELS ----

@admin.register(AffiliateTrip)
class AffiliateTripAdmin(DefaultAdmin):
    list_display = ('id', 'trip', 'created_at')


@admin.register(AffiliatePlatform)
class AffiliatePlatformAdmin(DefaultAdmin):
    list_display = ('id', 'title', 'platform')


# ---- FEEDBACK & CHAT MODELS ----

@admin.register(SubmitItineraryFeedback)
class SubmitItineraryFeedbackAdmin(admin.ModelAdmin):
    list_display = ('id', 'expert', 'title', 'location', 'status', 'created_at')
    list_filter = ('status',)


@admin.register(UserAndExpertChat)
class UserAndExpertChatAdmin(admin.ModelAdmin):
    list_display = ('id', 'sender', 'receiver', 'contract', 'created_at')
    search_fields = ('sender__email', 'receiver__email')
