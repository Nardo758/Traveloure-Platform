from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.permissions import AllowAny
from ai_itinerary.models import *
from ai_itinerary.serializers import *


class ListItineraryAPIView(APIView):
    def get(self, request,*args, **kwargs):
        
        # Get all trips for this user
        user_trips = Trip.objects.filter(user=request.user)
        
        # Get all generated itineraries for this user
        my_itinerary = GeneratedItinerary.objects.filter(trip__user=request.user).all()
        
        serializer = GeneratedItinerarySerializer(my_itinerary, many=True)
        return Response(serializer.data)
    

class UpdateItinerary(APIView):
    def patch(self, request,*args, **kwargs):
        trip_id = kwargs.get('trip_id',None)
        if not trip_id :
            return Response({'message':"No trip id provided",'status':False}, status= 400)
        
        instance = Trip.objects.filter(id=trip_id).first()
        if not instance:
            return Response({'message':"No Trip Found",'status':False}, status= 404)
        
        ai_trip = GeneratedItinerary.objects.filter(trip=instance).first()
        if not ai_trip:
            return Response({'message':"No AI Trip Found",'status':False}, status= 404)
    

        if instance.user == request.user:
            serializer = UpdateItinerarySerializer(ai_trip, data=request.data, partial=True)

            if serializer.is_valid():
                serializer.save()
                return Response({'message':"itinerary updated successfully",'status':True},status=200)
            else:
                return Response({'message': "Validation failed", 'errors': serializer.errors, 'status': False}, status=400)

        else:
            return Response({'message':"No Permission to Update the Itinerary",'status':False}, status=403)


class ShareAItineraryAPIView(generics.RetrieveAPIView):
    permission_classes = [AllowAny]
    serializer_class = ShareGeneratedItinerarySerializer
    queryset = GeneratedItinerary.objects.select_related('trip').all()
    lookup_field = "id"

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        return Response(serializer.data)

class GeneratedItineraryDetailAPIView(APIView):
    def get(self, request, id, *args, **kwargs):
        try:
            itinerary = GeneratedItinerary.objects.get(id=id)
        except GeneratedItinerary.DoesNotExist:
            return Response({'message': 'Generated itinerary not found', 'status': False}, status=404)
        serializer = GeneratedItinerarySerializer(itinerary)
        return Response(serializer.data)
   