# views.py
from rest_framework import generics, permissions
from django.db.models import Q
from django.conf import settings
from subscription.models import UserAndExpertContract, TransactionType, ContractTransaction
from subscription.serializers import UserAndExpertContractSerializer, ContractDecideSerializer
from authentication.models import User
from rest_framework.response import Response
from ai_itinerary.models import UserAndExpertChat, SubmitItineraryFeedback
from rest_framework.views import APIView
from rest_framework.response import Response
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from ai_itinerary.serializers import UserAndExpertChatSerializer
import stripe
from datetime import datetime


class ContractListCreateView(generics.ListCreateAPIView):
    serializer_class = UserAndExpertContractSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        return UserAndExpertContract.objects.filter(
            Q(created_by=user) | Q(created_for=user)
        )

    def create(self, request, *args, **kwargs):
        created_for_id = request.data.get("created_for")
        try:
            created_for = User.objects.get(id=created_for_id)
        except User.DoesNotExist:
            return Response({"message": "User does not exist.","status":False}, status=400)
        
        user, expert = None, None
        # Check the current active role using toggle_role
        if created_for.toggle_role == "local_expert":
            expert = created_for
            user = request.user
        else:
            user = created_for
            expert = request.user

        # Only check Stripe onboarding for users currently acting as experts
        if request.user.toggle_role == "local_expert" and expert.stripe_onboarding_complete == False:
            return Response({"message": "Please complete your Stripe onboarding to create a contract.","status":False}, status=400)
        
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        serializer.save(created_by=request.user, created_for=created_for)
        chat = UserAndExpertChat.objects.create(
            sender=request.user,
            receiver=created_for,
            contract=serializer.instance
        )

        self.broadcast_new_contract(chat_obj=chat, request=request)
        return Response({
            "status": True,
            "message": "Contract Created Successfully.",
            "data": serializer.data
        }, status=201)
    
    def chat_group_name(self, a_id, b_id) -> str:
        a, b = sorted([str(a_id), str(b_id)])
        return f"chat_{a}_{b}"

    def broadcast_new_contract(self, chat_obj, request):
        channel_layer = get_channel_layer()
        # Pass request context to serializer for proper URL building
        data = UserAndExpertChatSerializer(chat_obj, context={'request': request}).data
        sender_id = chat_obj.sender_id
        receiver_id = chat_obj.receiver_id
    
        # Receiver notification
        async_to_sync(channel_layer.group_send)(
            f"user_{receiver_id}",
            {"type": "new_message_notification", "payload": data}
        )
        async_to_sync(channel_layer.group_send)(
            f"user_{sender_id}",
            {"type": "new_message_notification", "payload": data}
        )
    
        # Room broadcast
        room = self.chat_group_name(sender_id, receiver_id)
        async_to_sync(channel_layer.group_send)(
            room,
            {"type": "new_contract", "payload": data}
        )

class ContractRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = UserAndExpertContractSerializer
    permission_classes = [permissions.IsAuthenticated]
    queryset = UserAndExpertContract.objects.all()

    def update(self, request, *args, **kwargs):
        mutable_data = request.data.copy()
        mutable_data.pop('status', None)
        mutable_data.pop('is_paid', None)

        request._full_data = mutable_data
        contract = self.get_object()
        if contract.is_paid or contract.status == "accepted":
            return Response({"error": "Cannot update a contract that is already accepted or paid."}, status=400)
        new_amount = mutable_data.get('amount')
        if new_amount:
            try:

                # Create Stripe Checkout Session
                session = stripe.checkout.Session.create(
                    line_items=[
                        {
                            "price_data": {
                                "currency": "usd",
                                "product_data": {"name": f"Contract Payment - {contract.id}"},
                                "unit_amount": int(new_amount * 100),
                            },
                            "quantity": 1,
                        }
                    ],
                    mode="payment",
                    success_url=f"{settings.FRONTEND_URL}/experts",
                    cancel_url=f"{settings.FRONTEND_URL}/payment",
                    metadata={
                        "contract_id": str(contract.id),
                        "status": contract.status,
                        "type": TransactionType.CONTRACT_TRANSACTION,
                        "user_id": str(contract.created_by.id) if contract.created_by.toggle_role != "local_expert" else str(contract.created_for.id),
                        "expert_id": str(contract.created_by.id) if contract.created_by.toggle_role == "local_expert" else str(contract.created_for.id),
                    }
                )

                contract.payment_url = session.url
                contract.save(update_fields=["payment_url"])

            except Exception as e:
                return Response({"error": str(e)}, status=400)

        request._full_data = mutable_data

        return super().update(request, *args, **kwargs)
    
class ContractDecisionAPIView(generics.UpdateAPIView):
    serializer_class = ContractDecideSerializer
    permission_classes = [permissions.IsAuthenticated]
    queryset = UserAndExpertContract.objects.all()

    def update(self, request, *args, **kwargs):
        contract = self.get_object()
        user = request.user
        serializer = self.get_serializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)

        if request.user == contract.created_by:
            return Response({"error": "Only the contract whom it is assigned can accept or reject."}, status=403)

        if contract.is_paid:
            return Response({"error": "Contract is already paid.", "status": False}, status=403)

        status = serializer.validated_data.get("status")
        # contract.status = status

        decision = "accepted" if status == "accepted" else "rejected"
        # Determine expert and user based on current toggle_role
        expert = contract.created_by if contract.created_by.toggle_role == "local_expert" else contract.created_for
        user = contract.created_by if contract.created_by.toggle_role != "local_expert" else contract.created_for
        
        # Only check Stripe onboarding if the current user is acting as an expert
        if request.user.toggle_role == "local_expert" and expert.stripe_onboarding_complete == False:
            return Response({"message": "Please complete your Stripe onboarding to accept or reject contracts.","status":False}, status=400)
        if decision == "accepted":
            session = stripe.checkout.Session.create(
                    payment_method_types = ["card"],
                    line_items = [
                        {
                            "price_data": {
                                "currency": "usd",
                                "product_data": {"name": f"Contract Payment - {contract.id}"},
                                "unit_amount": int(contract.amount * 100),
                            },
                            "quantity": 1,
                        }
                    ],
                    mode = "payment",
                    success_url = f"{settings.FRONTEND_URL}/experts",
                    cancel_url = f"{settings.FRONTEND_URL}/payment",
                    metadata = {
                        "contract_id": str(contract.id),
                        "status": "accepted",
                        "type": TransactionType.CONTRACT_TRANSACTION,
                        "user_id": str(user.id),
                        "expert_id": str(expert.id),
                    }
                )
            contract.payment_url = session.url
            contract.status = decision
            contract.save()
            from asgiref.sync import async_to_sync
            from channels.layers import get_channel_layer

            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                f"user_{user.id}",
                {
                    "type": "contract_accepted",
                    "payload": {
                        "contract_id": str(contract.id),
                        "title": contract.title,
                        "amount": contract.amount,
                        "message": f"Contract: {contract.title} is Accepted",
                        "created_at": contract.created_at.isoformat(),
                        "amount": str(contract.amount),
                        "message": f"Contract: {contract.title} is Accepted",
                        "payment_link": session.url,
                        "created_at": datetime.utcnow().isoformat(),

                    }
                }
            )
            # Sending Notification to Expert without Payment url
            async_to_sync(channel_layer.group_send)(
                f"user_{expert.id}",
                {
                    "type": "contract_accepted",
                    "payload": {
                        "contract_id": str(contract.id),
                        "title": contract.title,
                        "amount": contract.amount,
                        "message": f"Contract: {contract.title} is Accepted",
                        "created_at": contract.created_at.isoformat(),
                        "amount": str(contract.amount),
                        "message": f"Contract: {contract.title} is Accepted",
                        "created_at": datetime.utcnow().isoformat(),
                    }
                }
            )
        else:
            contract.status = decision
            contract.save()
            from asgiref.sync import async_to_sync
            from channels.layers import get_channel_layer

            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                f"user_{contract.created_by.id}",
                {
                    "type": "contract_rejected",
                    "payload": {
                        "contract_id": str(contract.id),
                        "title": contract.title,
                        "amount": contract.amount,
                        "message": f"Contract: {contract.title} has been rejected",
                        "created_at": contract.created_at.isoformat(),
                        "amount": str(contract.amount),
                        "message": f"Contract: {contract.title} is been rejected",
                        "created_at": datetime.utcnow().isoformat(),
                    }
                }
            )
            # channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                f"user_{contract.created_for.id}",
                {
                    "type": "contract_rejected",
                    "payload": {
                        "contract_id": str(contract.id),
                        "title": contract.title,
                        "amount": contract.amount,
                        "message": f"Contract: {contract.title} has been rejected",
                        "created_at": contract.created_at.isoformat(),
                        "amount": str(contract.amount),
                        "message": f"Contract: {contract.title} is been rejected",
                        "created_at": datetime.utcnow().isoformat(),
                    }
                }
            )
        return Response({
                "status": True,
                "message": f"Contract has been {decision}.",
                "payment_url": contract.payment_url if decision == "accepted" and contract.payment_url else None
            }, status=200)
    

class ContractReleaseFundAPIView(generics.CreateAPIView):
    serializer_class = UserAndExpertContractSerializer
    permission_classes = [permissions.IsAdminUser]
    queryset = UserAndExpertContract.objects.all()

    def create(self, request, *args, **kwargs):
        contract = self.get_object()

        # Determine expert and user based on toggle_role
        expert = contract.created_by if contract.created_by.toggle_role == "local_expert" else contract.created_for
        user = contract.created_by if contract.created_by.toggle_role != "local_expert" else contract.created_for

        transfer_amount_cents = int(contract.amount * 100)
        contract_transaction_instance = ContractTransaction.objects.filter(contract_id=contract.id).first()

        # Create transfer
        try:
            transfer = stripe.Transfer.create(
                amount=transfer_amount_cents,
                currency="usd",
                destination=expert.stripe_account_id,
                description=f"Release for Contract {contract.id}",
                metadata={
                    "contract_id": str(contract.id),
                    "user_id": str(user.id),
                    "expert_id": str(expert.id),
                },
                source_transaction=contract_transaction_instance.stripe_charge_id  # Links to original charge (optional, ensures funds traceability)
            )
            contract.save()

            from asgiref.sync import async_to_sync
            from channels.layers import get_channel_layer
            channel_layer = get_channel_layer()

            async_to_sync(channel_layer.group_send)(
                f"user_{user.id}",
                {
                    "type": "funds_released",
                    "payload": {
                        "contract_id": str(contract.id),
                        "title": contract.title,
                        "amount": str(contract.amount),
                        "message": f"Funds for Contract: {contract.title} released to expert after approval.",
                        "created_at": datetime.utcnow().isoformat(),
                    }
                }
            )
            async_to_sync(channel_layer.group_send)(
                f"user_{expert.id}",
                {
                    "type": "funds_released",
                    "payload": {
                        "contract_id": str(contract.id),
                        "title": contract.title,
                        "amount": str(contract.amount),
                        "message": f"Funds for Contract: {contract.title} released to your account.",
                        "created_at": datetime.utcnow().isoformat(),
                    }
                }
            )

            return Response({"status": True, "message": "Funds released successfully."}, status=200)
        except stripe.error.StripeError as e:
            return Response({"status": False, "message": str(e)}, status=400)
        
class CheckContractStatusAPIView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, *args, **kwargs):
        user = request.user
        chat_with = request.query_params.get("with_chat")
        
        if chat_with:
            # Find contract between current user and specific chat partner
            contract = (
                UserAndExpertContract.objects
                .filter(
                    (Q(created_by=user) & Q(created_for_id=chat_with)) |
                    (Q(created_by_id=chat_with) & Q(created_for=user))
                )
                .order_by('-created_at')
                .first()
            )
        else:
            # Find any contract involving current user
            contract = (
                UserAndExpertContract.objects
                .filter(Q(created_by=user) | Q(created_for=user))
                .order_by('-created_at')
                .first()
            )
        if not contract:
            return Response({"message": "No contract found","status": True,"show_contract": True}, status=200)
        
        # Check if current user is acting as expert or regular user based on toggle_role
        if user.toggle_role == "local_expert":
            # For users acting as experts: No payment check needed, only check contract status and itinerary
            if contract.status == "accepted":
                submit_itinerary = SubmitItineraryFeedback.objects.filter(contract=contract).order_by('-created_at').first()
                if submit_itinerary and submit_itinerary.status == "accepted":
                    return Response({"show_contract": True, "show_itinerary":False,"status":True}, status=200)
                return Response({"show_contract": False, "show_itinerary":True,"status":True}, status=200)
            else:
                # Contract pending/rejected, expert can still see contract options
                return Response({"show_contract": True, "show_itinerary":False,"status":True}, status=200)
        else:
            # For users (travelers): Contract cycle logic
            if contract.status == "accepted":
                if contract.is_paid:
                    # Payment completed, check itinerary status
                    submit_itinerary = SubmitItineraryFeedback.objects.filter(contract=contract).order_by('-created_at').first()
                    if submit_itinerary and submit_itinerary.status == "accepted":
                        # Itinerary completed, can create new contract
                        return Response({"show_contract": True, "show_itinerary":False,"status":True}, status=200)
                    else:
                        # Waiting for itinerary or itinerary pending
                        return Response({"show_contract": False, "show_itinerary":True,"status":True}, status=200)
                else:
                    # Contract accepted but not paid yet, show payment option
                    return Response({"show_contract": True, "show_itinerary":False,"status":True}, status=200)
            else:
                # Contract pending/rejected, can create new contract
                return Response({"show_contract": True, "show_itinerary":False,"status":True}, status=200)