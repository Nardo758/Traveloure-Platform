# TRAVELOURE EXPERT SYSTEM - CURRENT IMPLEMENTATION ANALYSIS
## Based on Actual Frontend Code Review

**Date**: January 2, 2026  
**Source**: Traveloure-Frontend-main codebase  
**Key Finding**: Expert services menu is under construction - system partially implemented

---

## CURRENT IMPLEMENTATION (What Exists Now)

### 1. **Expert Browsing Flow** (`/app/experts/page.jsx`)

**User Journey:**
```
Homepage → "Work with Expert" → /experts page → Expert List with Filters
                                                    ↓
                                          Click on Expert → Opens Chat
                                                    ↓
                                          Expert sends Contract with Service Details
                                                    ↓
                                          User Accepts → Payment → Service Booked
```

**Key Features Already Built:**
- ✅ Expert marketplace page at `/experts`
- ✅ Expert filtering by location
- ✅ Real-time chat system (WebSocket)
- ✅ Contract system (experts send service proposals)
- ✅ Payment integration for contracts
- ✅ Itinerary submission system
- ✅ Expert dashboard (`/local-expert/dashboard`)
- ✅ Communication system built-in

**NOT Built Yet:**
- ❌ Expert services menu (page exists but shows "Under Construction")
- ❌ Pre-defined service packages that users can select
- ❌ Self-service expert selection (currently requires chat first)

---

## HOW IT CURRENTLY WORKS

### Step 1: Browse Experts
**File**: `/app/experts/page.jsx`

Users see:
- List of verified local experts
- Filter by:
  - Location/Country
  - Language
  - Specialty
  - Rating
- Each expert shows:
  - Profile photo
  - Name
  - Rating (4.8/5.0 from staticExpertData)
  - Countries served
  - Languages spoken
  - Specialization
  - "Chat Now" button

### Step 2: Open Chat
When user clicks "Chat Now":
- Opens real-time chat interface
- WebSocket connection established
- User can send messages
- Expert can send messages back

### Step 3: Expert Sends Contract
**Key Component**: `ContractModal`

Expert (not user) creates a contract with:
- Contract title (e.g., "Paris Trip Planning - Full Service")
- Description of services
- Amount/Price
- Terms

Contract is sent through chat as special message type.

### Step 4: User Responds to Contract
**Component**: `ContractMessage`

User sees contract in chat and can:
- **Accept** → Redirects to payment
- **Reject** → Contract marked as rejected
- **Request changes** → Through chat

### Step 5: Payment (If Accepted)
- Contract acceptance generates payment URL
- User pays through Stripe
- Payment confirmation updates contract status
- Expert is notified

### Step 6: Expert Delivers Service
Expert can submit itinerary through:
- **Component**: `ItineraryMessage`
- Upload attachment (PDF, etc.)
- User can approve or request edits

---

## REDUX STATE STRUCTURE

### Local Expert Slice
```javascript
/redux-features/local-expert/localExpertSlice.js

Features:
- fetchLocalExpertDashboard
- fetchLocalExpertEarnings
- Expert authentication/verification
```

### Contract Slice
```javascript
/redux-features/contract/contractSlice.js

Actions:
- checkContractStatus
- updateContractStatus
- Handle contract accept/reject
- Payment URL management
```

### Chat System
```javascript
Custom hooks:
- useChat() - Real-time messaging
- useContract() - Contract management
- useItinerary() - Itinerary submissions
```

---

## CURRENT PAGES STRUCTURE

```
/experts - Browse all experts (MAIN ENTRY POINT)
/local-expert/dashboard - Expert's main dashboard
/local-expert/services - Services management (UNDER CONSTRUCTION)
/local-expert/bookings - View bookings
/local-expert/chats - Chat with travelers
/local-expert/earnings - Financial dashboard
/dashboard/expert-chats - Traveler's chat list
```

---

## THE "UNDER CONSTRUCTION" SERVICE MENU

**File**: `/local-expert/services/page.jsx`

Currently shows placeholder for:
```
Planned Features:
- Create and manage travel services
- Set pricing and availability
- Upload photos and descriptions
- Track service performance
```

This is where experts would define their service menu (e.g., Quick Call $29, Cart Review $49, Full Planning $249), but it's not yet implemented.

---

## RECOMMENDED WIREFRAME UPDATES

### Option A: Match Current Implementation (Easiest)

**Homepage:**
```
[Browse & Build DIY] [Work with Expert]
                             ↓
                    /experts page (list of experts)
                             ↓
                    Click expert → Opens chat
                             ↓
                    Expert sends contract with services
                             ↓
                    User accepts/rejects
```

**Pros:**
- Matches what's already built
- No new development needed
- Chat-first approach builds relationships

**Cons:**
- More friction (must chat before booking)
- No self-service expert selection
- Requires expert to be online/responsive

---

### Option B: Add Self-Service Layer (Recommended)

Keep current system BUT add self-service option:

**Updated Flow:**
```
Homepage → "Work with Expert" → /experts page
                                      ↓
                            Two paths split here:

PATH 1 (Current):                  PATH 2 (New):
Click "Chat Now"                   Click "View Services"
     ↓                                     ↓
Opens chat                         Expert Profile Page
     ↓                                     ↓
Expert sends contract              Browse service menu
     ↓                                     ↓
Accept/pay                         Select service & add to cart
                                          ↓
                                   Checkout (auto-creates contract)
```

**Expert Profile Page** (NEW):
```
┌────────────────────────────────────────────────────┐
│ [Photo] MARIA DUBOIS                               │
│ ⭐ 5.0 (247 reviews) • Paris Travel Expert         │
│                                                    │
│ About | Services | Reviews | Contact               │
├────────────────────────────────────────────────────┤
│                                                    │
│ SERVICES OFFERED:                                  │
│                                                    │
│ ┌──────────────────────────────────────────────┐  │
│ │ ☎️ QUICK CONSULTATION - $29                  │  │
│ │ 30-minute call to answer questions            │  │
│ │ [Select Service]                              │  │
│ └──────────────────────────────────────────────┘  │
│                                                    │
│ ┌──────────────────────────────────────────────┐  │
│ │ 📋 CART REVIEW - $49                         │  │
│ │ Review your trip cart & suggest improvements  │  │
│ │ [Select Service]                              │  │
│ └──────────────────────────────────────────────┘  │
│                                                    │
│ ┌──────────────────────────────────────────────┐  │
│ │ ⭐ FULL PLANNING - $249                      │  │
│ │ Complete trip planning from start to finish   │  │
│ │ [Select Service]                              │  │
│ └──────────────────────────────────────────────┘  │
│                                                    │
│ [Chat with Maria]                                  │
└────────────────────────────────────────────────────┘
```

**Backend Changes Needed:**
1. Build expert services CRUD in `/local-expert/services`
2. Allow experts to create service packages
3. When user selects service → Auto-generate contract
4. Send notification to expert about new booking

---

## INTEGRATION WITH EXISTING SYSTEMS

### With DIY Browse & Build:
Users building a cart could see:
```
Your Cart: $2,112
[Activities] [Hotels] [Services] [Experts ✓] [AI Optimization]

Under "Experts" tab:
┌──────────────────────────────────────────┐
│ 💡 ADD EXPERT REVIEW                     │
│                                          │
│ Get a Paris expert to review your cart   │
│ and suggest improvements                 │
│                                          │
│ [Photo] Maria - $49 Cart Review          │
│ [Add to Cart]                            │
└──────────────────────────────────────────┘
```

This becomes just another "service" they add to cart!

---

## TECHNICAL IMPLEMENTATION ROADMAP

### Phase 1: Expert Services CRUD (2-3 weeks)
**Backend:**
- Create Service model (title, description, price, duration, etc.)
- CRUD endpoints for expert services
- Link services to expert profiles

**Frontend:**
- Complete `/local-expert/services/page.jsx`
- Service creation form
- Service management dashboard

### Phase 2: Expert Profile Page (1-2 weeks)
**Frontend:**
- Create `/experts/[expertId]/page.jsx`
- Display expert info + services menu
- "Select Service" → Add to cart or trigger contract

### Phase 3: Self-Service Booking (1 week)
**Backend:**
- Auto-generate contracts when service selected
- Notification system for experts

**Frontend:**
- Service selection → Cart → Checkout flow
- Contract auto-creation on checkout

### Phase 4: Integration with DIY Flow (1 week)
**Frontend:**
- Add "Experts" tab to trip planning
- Show relevant experts in cart sidebar
- Allow adding expert services to existing cart

---

## IMMEDIATE WIREFRAME RECOMMENDATIONS

### Update Landing Page:
```
┌─────────────────────────┐  ┌─────────────────────────┐
│ 🛍️ BROWSE & BUILD      │  │ 👤 WORK WITH EXPERT     │
│                         │  │                         │
│ Browse activities,      │  │ Get help from verified  │
│ hotels, services        │  │ local experts           │
│                         │  │                         │
│ [Start Browsing →]      │  │ [Browse Experts →]      │
└─────────────────────────┘  └─────────────────────────┘

🌟 FEATURED EXPERTS
[Expert carousel showing top experts with "View Profile" and "Chat Now" buttons]
```

### Expert Marketplace Page:
```
/experts (existing)

Filters: Location | Language | Specialty | Price Range

Expert Card:
┌────────────────────────────────────────┐
│ [Photo] MARIA DUBOIS                   │
│ ⭐ 5.0 (247) • Paris Travel Expert     │
│                                        │
│ Services from: $29                     │
│ Specialties: Romantic, Food & Wine     │
│                                        │
│ [View Profile]  [Chat Now]             │
└────────────────────────────────────────┘
```

### Expert Profile Page (NEW):
Shows expert bio + services menu + reviews
Users can either:
- Select a service → Add to cart → Checkout
- Click "Chat Now" → Open chat (current flow)

---

## KEY INSIGHTS

1. **Chat-First vs Service-First**: Current system is chat-first (must chat before booking). Adding service-first option gives users choice.

2. **Contract System is Solid**: The existing contract/payment system works well. Just need to auto-generate contracts from service selection.

3. **Services Menu is Missing**: This is the main gap. Once built, everything else can plug into it.

4. **Dual-Path Works**: Can keep current chat-first flow AND add self-service path. Both funnel to same contract/payment system.

---

## RECOMMENDED APPROACH

**SHORT TERM (Match Current Code):**
Update wireframes to show chat-first approach since that's what's built now.

**MEDIUM TERM (Add Self-Service):**
1. Build expert services CRUD
2. Add expert profile pages
3. Allow service selection → auto-contract
4. Integrate with DIY cart flow

**LONG TERM (Unified Experience):**
Experts become another "content type" users can browse and add to cart, seamlessly integrated with activities/hotels/services.

---

This matches your actual implementation and provides a clear path forward!