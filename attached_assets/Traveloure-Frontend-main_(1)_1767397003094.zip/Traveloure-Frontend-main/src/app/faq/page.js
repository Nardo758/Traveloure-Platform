import React from 'react'

function page() {
  return (
    <div>
      faq page design
    </div>
  )
}

export default page
