# STEP-BY-STEP: HOW TO WORK WITH REPLIT AGENT
## Preserve Your UI While Adding Features

---

## 📋 BEFORE YOU START

### 1. Download These Files
- ✅ REPLIT_AGENT_INSTRUCTIONS.md
- ✅ DESIGN_REFERENCE.md
- ✅ QUICK_REFERENCE.md

### 2. Upload to Your Replit Project
```bash
# In your Replit project, create a folder:
/docs
  ├── REPLIT_AGENT_INSTRUCTIONS.md
  ├── DESIGN_REFERENCE.md
  └── QUICK_REFERENCE.md
```

---

## 🎯 STEP 1: INITIAL CONVERSATION

### Open Replit Agent and paste this:

```
Hi! I need your help implementing new features while preserving my existing UI/UX.

CRITICAL RULES:
❌ DO NOT modify app/(marketing)/page.tsx or any files in app/(marketing)/
❌ DO NOT change my design system (colors, fonts, spacing)
❌ DO NOT alter /components/ui/* (Shadcn components)

✅ DO reuse existing component patterns
✅ DO match existing styling exactly
✅ DO create new routes for new features
✅ DO ask before changing any existing files

I've uploaded reference documents to /docs/:
- REPLIT_AGENT_INSTRUCTIONS.md (read this first!)
- DESIGN_REFERENCE.md (styling patterns)
- QUICK_REFERENCE.md (copy/paste patterns)

Please read /docs/REPLIT_AGENT_INSTRUCTIONS.md and confirm you understand 
the constraints before we begin.
```

**Wait for Replit to confirm it's read the instructions.**

---

## 🎯 STEP 2: REQUEST IMPLEMENTATION PLAN

### Paste this:

```
Great! Now show me your implementation plan.

For EACH file you plan to work on, tell me:
1. File path
2. Action: [MODIFY] or [CREATE NEW]
3. Why you're changing it
4. Which design patterns you'll use (reference DESIGN_REFERENCE.md)

DO NOT start coding yet - just show me the plan.
```

**Review the plan carefully. Make sure it's NOT touching your landing page files!**

---

## 🎯 STEP 3: APPROVE OR ADJUST PLAN

### If the plan is good:

```
✅ Approved! 

But implement ONE feature at a time:
1. Start with backend schema changes
2. Show me the code BEFORE committing
3. Wait for my approval
4. Then move to the next feature

Begin with: Multi-event database schema
```

### If the plan touches landing page files:

```
❌ STOP! 

You listed these files for modification:
- app/(marketing)/page.tsx
- app/(marketing)/components/Hero.tsx

These are FORBIDDEN. Do NOT touch these files.

Revise your plan to only:
- Create NEW files in app/dashboard/ or other authenticated areas
- Modify backend/API files only
- Leave ALL marketing pages unchanged

Show me a revised plan.
```

---

## 🎯 STEP 4: ITERATIVE IMPLEMENTATION

For each feature, use this pattern:

```
Feature: [Name of feature]

1. Show me the code for [specific component]
2. Explain which pattern from DESIGN_REFERENCE.md you're using
3. Wait for my approval
4. Implement
5. Move to next component

Start with: [first component]
```

**Example:**

```
Feature: Multi-Event Selection

1. Show me the code for the event type selection component
2. Explain which card pattern you're using from DESIGN_REFERENCE.md
3. Wait for my approval

Don't implement yet - just show me the code.
```

---

## 🎯 STEP 5: CODE REVIEW CHECKLIST

When Replit shows you code, verify:

```markdown
## Code Review Checklist

- [ ] Uses components from /components/ui/ (Shadcn)
- [ ] Colors match palette (bg-primary, text-gray-600, etc.)
- [ ] Spacing uses scale (p-6, space-y-4, gap-6)
- [ ] Typography matches (text-xl, font-semibold)
- [ ] Has hover states
- [ ] Has focus states
- [ ] Responsive (md:, lg: breakpoints)
- [ ] No inline styles
- [ ] No custom colors (no bg-[#123456])
- [ ] No arbitrary values (no p-[17px])
```

### If code looks good:

```
✅ Looks good! Implement this component.

Next: Show me [next component name]
```

### If code has issues:

```
❌ Issues found:

1. Line 15: Using custom color bg-[#FF0000] - should use bg-red-500
2. Line 23: Using inline style - should use Tailwind classes
3. Line 30: Missing hover state - add hover:bg-primary-hover

Fix these and show me the updated code.
```

---

## 🎯 STEP 6: VERIFY LANDING PAGE UNCHANGED

After each implementation:

```
Great! Now verify:

1. Show me git diff for app/(marketing)/page.tsx
2. Confirm no changes to marketing components
3. Show me the new files created

If ANY marketing files changed, REVERT those changes.
```

---

## 🎯 STEP 7: TEST NEW FEATURES

```
Run the development server and let me test:

1. Landing page - should be IDENTICAL to before
2. Dashboard - should have new features
3. New routes - should work correctly
4. Styling - should match existing design

If anything looks different on the landing page, we need to fix it.
```

---

## 🔁 STEP 8: REPEAT FOR EACH FEATURE

For each new feature (AI assistant, Executive Assistant, etc.):

1. Request implementation plan
2. Review plan
3. Approve or adjust
4. Iterative code review
5. Verify landing page unchanged
6. Test
7. Move to next feature

---

## 🚨 EMERGENCY STOP PHRASES

If Replit is modifying the wrong files:

```
🛑 STOP IMMEDIATELY!

You're modifying files in app/(marketing)/ which is FORBIDDEN.

Revert all changes to:
- [list files that were modified]

These files must remain EXACTLY as they were.
```

---

## ✅ COMPLETION CHECKLIST

When all features are implemented:

```markdown
## Final Verification

Landing Page (MUST BE UNCHANGED):
- [ ] app/(marketing)/page.tsx - no changes
- [ ] Hero section - looks identical
- [ ] Navigation - looks identical
- [ ] All marketing components - no changes
- [ ] Colors - exactly the same
- [ ] Fonts - exactly the same
- [ ] Spacing - exactly the same

New Features (PROPERLY IMPLEMENTED):
- [ ] Multi-event support works
- [ ] AI assistant works
- [ ] Executive Assistant dashboard works
- [ ] All new features match existing design
- [ ] No console errors
- [ ] Responsive design works
- [ ] All forms functional
```

---

## 💡 TIPS FOR SUCCESS

### DO:
✅ Review every change before approving
✅ Test frequently
✅ Ask Replit to explain its choices
✅ Reference the design docs often
✅ Stop if anything looks wrong
✅ Request revisions multiple times if needed

### DON'T:
❌ Let Replit implement without showing code first
❌ Approve changes you haven't reviewed
❌ Continue if landing page changes
❌ Rush through the process
❌ Accept "I'll match the style" without seeing code

---

## 🎯 EXAMPLE FULL CONVERSATION

```
You: [Paste initial instructions from Step 1]

Replit: I've read the documents. I understand I must not modify 
        app/(marketing)/* and must use existing design patterns.

You: Show me your implementation plan for multi-event support.

Replit: [Shows plan]

You: ✅ Approved. Start with database schema. Show code first.

Replit: [Shows Prisma schema changes]

You: Looks good. Implement it. Next: Show event type selection component.

Replit: [Shows EventTypeSelection component code]

You: ❌ Line 12 uses custom color. Use bg-primary instead.

Replit: [Shows corrected code]

You: ✅ Perfect! Implement it. Verify no marketing files changed.

Replit: No changes to app/(marketing)/*. Created new file: 
        app/dashboard/events/create/components/EventTypeSelection.tsx

You: Excellent. Next feature: AI Assistant dashboard...

[Continue for each feature]
```

---

## 📞 NEED HELP?

If Replit Agent:
- Keeps modifying forbidden files → Use emergency stop phrase
- Isn't following design patterns → Point to specific section in DESIGN_REFERENCE.md
- Creates ugly/inconsistent UI → Show examples from QUICK_REFERENCE.md
- Won't listen → Restart conversation and be more explicit

**Remember: You're in control. Replit Agent should show you code, wait for approval, then implement. Never the other way around!**

---

**Now you're ready to work with Replit Agent successfully! 🚀**
