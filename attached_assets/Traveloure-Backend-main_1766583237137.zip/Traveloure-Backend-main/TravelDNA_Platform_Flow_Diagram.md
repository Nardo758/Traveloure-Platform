# TravelDNA Platform - Complete Flow Diagram & API Documentation

## Mermaid Flow Diagram

```mermaid
graph TB
    %% User Entry Points
    User[👤 User] --> Auth[🔐 Authentication System]
    
    %% Authentication Module
    Auth --> Register[📝 User Registration]
    Auth --> Login[🔑 User Login]
    Auth --> Social[📱 Social Login]
    
    Register --> EmailVerify[📧 Email Verification]
    Login --> JWT[🎫 JWT Token Generation]
    Social --> GoogleAuth[🔍 Google OAuth]
    Social --> FacebookAuth[📘 Facebook OAuth]
    
    %% User Types & Roles
    JWT --> UserTypes{👥 User Type}
    UserTypes --> RegularUser[👤 Regular User]
    UserTypes --> LocalExpert[🎯 Local Expert]
    UserTypes --> ServiceProvider[🏢 Service Provider]
    UserTypes --> Admin[👑 Admin]
    
    %% Profile Management
    RegularUser --> Profile[👤 Profile Management]
    Profile --> UpdateProfile[✏️ Update Profile]
    Profile --> TravelPrefs[🎒 Travel Preferences]
    Profile --> WeatherAPI[🌤️ Weather Information]
    
    %% Wallet & Payment System
    RegularUser --> Wallet[💰 Wallet System]
    Wallet --> WalletBalance[💳 Check Balance]
    Wallet --> WalletRecharge[💸 Recharge Wallet]
    Wallet --> WalletHistory[📊 Transaction History]
    Wallet --> StripePayment[💳 Stripe Integration]
    
    %% AI Itinerary Generation
    RegularUser --> AIItinerary[🤖 AI Itinerary System]
    AIItinerary --> CreateTrip[✈️ Create Trip]
    AIItinerary --> GenerateItinerary[🗺️ Generate AI Itinerary]
    AIItinerary --> MyItineraries[📋 My Itineraries]
    AIItinerary --> ShareItinerary[🔗 Share Itinerary]
    
    CreateTrip --> TripDetails[📝 Trip Details Input]
    TripDetails --> Destination[🏙️ Destination]
    TripDetails --> Dates[📅 Start/End Dates]
    TripDetails --> Travelers[👥 Number of Travelers]
    TripDetails --> Preferences[🎯 Travel Preferences]
    
    GenerateItinerary --> OpenAI[🧠 OpenAI Integration]
    GenerateItinerary --> PlaceDiscovery[🔍 Place Discovery]
    GenerateItinerary --> WeatherIntegration[🌤️ Weather Integration]
    GenerateItinerary --> AffiliateData[🔗 Affiliate Platform Data]
    
    %% Expert System
    LocalExpert --> ExpertDashboard[📊 Expert Dashboard]
    LocalExpert --> ExpertApplication[📝 Expert Application]
    LocalExpert --> ExpertStatus[✅ Application Status]
    LocalExpert --> ExpertItineraries[🗺️ Manage Itineraries]
    
    ExpertItineraries --> AssignedTrips[📋 Assigned Trips]
    ExpertItineraries --> UpdateItinerary[✏️ Update Itinerary]
    ExpertItineraries --> ExpertChat[💬 Chat with Users]
    
    %% Contract System
    RegularUser --> Contracts[📄 Contract System]
    LocalExpert --> Contracts
    Contracts --> CreateContract[📝 Create Contract]
    Contracts --> ContractDecision[✅ Accept/Reject Contract]
    Contracts --> ReleaseFunds[💰 Release Funds]
    Contracts --> ContractStatus[📊 Contract Status]
    
    %% Chat System
    RegularUser --> ChatSystem[💬 Chat System]
    LocalExpert --> ChatSystem
    ChatSystem --> UserExpertChat[👥 User-Expert Chat]
    ChatSystem --> MessageValidation[🔍 Message Validation]
    ChatSystem --> ChatHistory[📜 Chat History]
    ChatSystem --> WebSocket[🔌 Real-time WebSocket]
    
    %% Review System
    RegularUser --> Reviews[⭐ Review System]
    Reviews --> CreateReview[✍️ Create Review]
    Reviews --> ExpertReviews[📊 Expert Reviews]
    Reviews --> MyReviews[📝 My Written Reviews]
    
    %% Service Provider System
    ServiceProvider --> ServiceDashboard[📊 Service Dashboard]
    ServiceProvider --> ServiceApplication[📝 Service Provider Application]
    ServiceProvider --> ManageServices[🛠️ Manage Services]
    
    ManageServices --> CreateService[➕ Create Service]
    ManageServices --> UpdateService[✏️ Update Service]
    ManageServices --> ServiceStatus[📊 Service Status]
    ManageServices --> ServicePayment[💰 Service Payment]
    
    %% Public Services
    RegularUser --> PublicServices[🌐 Public Services]
    PublicServices --> BrowseServices[🔍 Browse Available Services]
    PublicServices --> PayForService[💳 Pay for Service]
    
    %% Preferences System
    RegularUser --> PreferencesSystem[🎯 Preferences System]
    PreferencesSystem --> TouristPrefs[🏖️ Tourist Preferences]
    PreferencesSystem --> ActivityPrefs[🎪 Activity Preferences]
    PreferencesSystem --> EventPrefs[🎉 Event Preferences]
    
    %% Affiliate Integration
    AIItinerary --> AffiliateSystem[🔗 Affiliate System]
    AffiliateSystem --> HotelBooking[🏨 Hotel Booking]
    AffiliateSystem --> FlightBooking[✈️ Flight Booking]
    AffiliateSystem --> CarRental[🚗 Car Rental]
    AffiliateSystem --> AffiliatePlatforms[🌐 Affiliate Platforms]
    
    %% Admin Functions
    Admin --> AdminPanel[👑 Admin Panel]
    AdminPanel --> ManageUsers[👥 Manage Users]
    AdminPanel --> ManageExperts[🎯 Manage Local Experts]
    AdminPanel --> ManageServiceProviders[🏢 Manage Service Providers]
    AdminPanel --> SystemSettings[⚙️ System Settings]
    
    %% API Usage Tracking
    Wallet --> APIUsage[📊 API Usage Tracking]
    APIUsage --> UsageHistory[📈 Usage History]
    APIUsage --> CreditSystem[🪙 Credit System]
    
    %% Feedback System
    RegularUser --> FeedbackSystem[📝 Feedback System]
    FeedbackSystem --> SubmitFeedback[📤 Submit Itinerary Feedback]
    FeedbackSystem --> FeedbackDecision[✅ Feedback Decision]
    
    %% External Integrations
    OpenAI --> GPT4[🧠 GPT-4 Mini]
    WeatherAPI --> WeatherService[🌤️ Weather Service API]
    StripePayment --> StripeWebhook[🔔 Stripe Webhook]
    
    %% Database Storage
    Profile --> Database[(🗄️ PostgreSQL Database)]
    Wallet --> Database
    AIItinerary --> Database
    Contracts --> Database
    ChatSystem --> Database
    Reviews --> Database
    ManageServices --> Database
    
    %% File Storage
    Profile --> FileStorage[📁 AWS S3 / Local Storage]
    ManageServices --> FileStorage
    
    %% Real-time Features
    ChatSystem --> Channels[🔌 Django Channels]
    Channels --> WebSocketConnection[🌐 WebSocket Connection]
    
    %% Security & Authentication
    JWT --> JWTRefresh[🔄 JWT Refresh Token]
    Auth --> PasswordReset[🔐 Password Reset]
    Auth --> ChangePassword[🔑 Change Password]
    
    style User fill:#e1f5fe
    style Auth fill:#f3e5f5
    style Wallet fill:#e8f5e8
    style AIItinerary fill:#fff3e0
    style LocalExpert fill:#fce4ec
    style ServiceProvider fill:#e0f2f1
    style Admin fill:#ffebee
    style Database fill:#f5f5f5
    style FileStorage fill:#f0f4c3
```

## Complete API Documentation

### 🔐 Authentication APIs (`/auth/`)

| Endpoint | Method | Description | Features |
|----------|--------|-------------|----------|
| `/register/` | POST | User registration | Email verification required |
| `/tokenverify/<token>/` | GET | Email verification | Token-based verification |
| `/login/` | POST | User login | JWT token generation, role-based access |
| `/logout/` | POST | User logout | Token blacklisting |
| `/refresh-token/` | POST | Refresh JWT token | Token rotation |
| `/resend-email/` | POST | Resend verification email | Rate limiting |
| `/forget-password/` | POST | Forgot password | Email-based reset |
| `/forget-reset-password/<uidb64>/<token>/` | POST | Reset password | Secure token validation |
| `/change-password/` | POST | Change password | Authenticated users |
| `/profile/` | GET | Get user profile | Complete user information |
| `/profile/<id>/` | PUT/PATCH | Update profile | Profile picture, preferences |
| `/travel-preference/<user_id>/` | GET/PUT | Travel preferences | Personalized settings |
| `/google-callback/` | POST | Google OAuth | Social authentication |
| `/facebook-login-success/` | POST | Facebook OAuth | Social authentication |
| `/facebook/token/` | POST | Facebook token exchange | Token management |
| `/weather/future/` | GET | Future weather data | Weather API integration |
| `/local-experts/` | GET | Search local experts | Filtering and search |

#### Local Expert Management
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/local-expert/create/` | POST | Apply as local expert |
| `/local-expert/status/` | GET | Check application status |
| `/local-expert/my-application/` | GET | View my application |
| `/local-expert/dashboard/` | GET | Expert dashboard |
| `/local-expert/view/<country>/` | GET | Experts by country |
| `/manage-localexpert/` | GET | Admin: List experts |
| `/manage-localexpert/<pk>/` | GET/PUT | Admin: Manage expert |

#### Service Provider Management
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/service-provider/create/` | POST | Apply as service provider |
| `/service-provider/status/` | GET | Check application status |
| `/service-provider/my-application/` | GET | View my application |
| `/service-provider/dashboard/` | GET | Provider dashboard |
| `/service-provider/view/<country>/` | GET | Providers by country |
| `/manage-serviceprovider/` | GET | Admin: List providers |
| `/manage-serviceprovider/<pk>/` | GET/PUT | Admin: Manage provider |

### 🤖 AI Itinerary APIs (`/ai/`)

#### Itinerary Management
| Endpoint | Method | Description | Features |
|----------|--------|-------------|----------|
| `/my-itineraries/` | GET | List user itineraries | Pagination, filtering |
| `/my-itineraries/<id>/` | GET | Get itinerary details | Complete itinerary data |
| `/itinerary/<trip_id>/` | PUT | Update itinerary | User modifications |
| `/share/<id>/` | GET | Share itinerary | Public sharing link |
| `/guide/create/trip/` | POST | Create guided trip | Step-by-step creation |
| `/generate-explore/` | POST | Generate AI itinerary | OpenAI integration |

#### Expert Collaboration
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/local-experts/` | GET | List available experts |
| `/expert-assigned/` | POST | Assign expert to trip |
| `/expert-invitation/` | POST | Expert decision on invitation |
| `/expert-itinerary/<trip_id>/` | GET/PUT | Expert itinerary management |
| `/save-itinerary/<id>/` | POST | Save expert modifications |

#### Reviews & Ratings
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/reviews/create/` | POST | Create expert review |
| `/reviews/expert/<expert_id>/` | GET | Get expert reviews |
| `/my-reviews/` | GET | My written reviews |

#### Discovery & Preferences
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/discover/` | GET | Discover places |
| `/categories/` | GET | Travel categories |
| `/preferences/` | GET/POST | Tourist preferences |
| `/preferences/delete/` | DELETE | Delete preferences |
| `/preferences/activity/` | GET/POST | Activity preferences |
| `/preferences/activity/<id>/` | DELETE | Delete activity preference |
| `/preferences/event/` | GET/POST | Event preferences |
| `/preferences/event/<id>/` | DELETE | Delete event preference |

#### Chat System
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/chats/` | GET | List user chats |
| `/chats/<receiver_id>/` | GET/POST | Chat with specific user |
| `/validate-message/` | POST | Validate message content |

#### Affiliate Integration
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/affiliate-platforms/bulk-create/` | POST | Bulk create affiliate data |
| `/affiliate-platforms/bulk-upsert/` | POST | Bulk upsert affiliate data |
| `/affiliate-explore/` | GET | Explore affiliate options |

#### Feedback System
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/submit-itinerary/` | POST | Submit itinerary feedback |
| `/submit-itinerary/<pk>/` | GET/PUT/DELETE | Manage feedback |
| `/submit-itinerary/<pk>/decision/` | POST | Feedback decision |

### 💰 Subscription & Wallet APIs (`/plan/`)

#### Wallet Management
| Endpoint | Method | Description | Features |
|----------|--------|-------------|----------|
| `/wallet/balance/` | GET | Get wallet balance | Credits and balance |
| `/wallet/recharge/` | POST | Recharge wallet | Stripe integration |
| `/wallet/transactions/` | GET | Transaction history | Pagination, filtering |
| `/wallet/api-usage/` | GET | API usage history | Usage tracking |
| `/webhook/stripe/` | POST | Stripe webhook | Payment processing |

#### Contract System
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/contracts/` | GET/POST | List/Create contracts |
| `/contract-status/check/` | GET | Check contract status |
| `/contracts/<pk>/` | GET/PUT/DELETE | Manage specific contract |
| `/contracts/decision/<pk>/` | POST | Accept/Reject contract |
| `/contracts/release/<pk>/` | POST | Release contract funds |

### 🛠️ Service Provider APIs (`/service/`)

| Endpoint | Method | Description | Features |
|----------|--------|-------------|----------|
| `/` | GET | List all available services | Public access |
| `/services/` | GET/POST | List/Create services | Provider only |
| `/services/<id>/` | GET/PUT/DELETE | Manage specific service | CRUD operations |
| `/services/update-status/` | POST | Update service status | Admin approval |
| `/dashboard/` | GET | Service provider dashboard | Analytics |
| `/pay/<service_id>/` | POST | Pay for service | Payment processing |

## 🔧 Key Features & Functionality

### 1. **User Management System**
- **Multi-role Authentication**: Regular users, Local experts, Service providers, Admins
- **Social Login**: Google OAuth2, Facebook OAuth2
- **Profile Management**: Complete user profiles with travel preferences
- **Email Verification**: Secure email-based account verification
- **Password Management**: Forgot password, change password functionality

### 2. **AI-Powered Itinerary Generation**
- **OpenAI Integration**: Uses GPT-4 Mini for intelligent itinerary creation
- **Place Discovery**: Automated tourist place discovery and recommendations
- **Weather Integration**: Real-time weather data for travel planning
- **Customizable Preferences**: User-specific travel style and preferences
- **Day-by-day Planning**: Detailed daily itineraries with activities

### 3. **Expert Collaboration System**
- **Local Expert Network**: Connect travelers with local experts
- **Expert Assignment**: Assign experts to specific trips
- **Collaborative Editing**: Experts can modify and improve itineraries
- **Real-time Chat**: WebSocket-based chat between users and experts
- **Review System**: Rate and review expert services

### 4. **Wallet & Payment System**
- **Credit-based System**: 1 USD = 2 credits for API usage
- **Stripe Integration**: Secure payment processing
- **Transaction History**: Complete payment and usage tracking
- **Wallet Recharge**: Easy wallet top-up functionality
- **API Usage Tracking**: Monitor API consumption and costs

### 5. **Service Provider Marketplace**
- **Service Listing**: Providers can list travel-related services
- **Service Management**: Complete CRUD operations for services
- **Payment Integration**: Direct payment for services
- **Status Management**: Admin approval workflow
- **Location-based Services**: Services filtered by location

### 6. **Contract Management System**
- **User-Expert Contracts**: Formal agreements between users and experts
- **Fund Escrow**: Secure fund holding until service completion
- **Contract Decisions**: Accept/reject contract proposals
- **Fund Release**: Automated fund release upon completion

### 7. **Real-time Communication**
- **Django Channels**: WebSocket support for real-time features
- **Chat System**: Direct messaging between users and experts
- **Message Validation**: Automatic validation of message content
- **Chat History**: Persistent chat history storage

### 8. **Affiliate Integration**
- **Hotel Booking**: Integration with hotel booking platforms
- **Flight Booking**: Flight search and booking capabilities
- **Car Rental**: Car rental service integration
- **Revenue Sharing**: Platform fee system for bookings

### 9. **Advanced Features**
- **Feedback System**: Comprehensive feedback collection and management
- **Preference Management**: Detailed travel preference system
- **Weather API**: Future weather forecasting for destinations
- **File Storage**: AWS S3 integration for file uploads
- **Admin Dashboard**: Complete admin panel for system management

### 10. **Security & Performance**
- **JWT Authentication**: Secure token-based authentication
- **CORS Configuration**: Proper cross-origin resource sharing
- **Rate Limiting**: API rate limiting and abuse prevention
- **Database Optimization**: Efficient database queries and indexing
- **Logging System**: Comprehensive logging for debugging and monitoring

## 🏗️ Technical Architecture

### **Backend Framework**
- **Django 5.1.6**: Modern Python web framework
- **Django REST Framework**: API development
- **Django Channels**: WebSocket support for real-time features
- **PostgreSQL**: Primary database
- **Redis**: Caching and session storage

### **External Integrations**
- **OpenAI API**: AI-powered itinerary generation
- **Stripe**: Payment processing
- **Weather API**: Weather data integration
- **Google OAuth2**: Social authentication
- **Facebook OAuth2**: Social authentication
- **AWS S3**: File storage (production)

### **Key Technologies**
- **JWT Authentication**: Secure token-based auth
- **WebSocket**: Real-time communication
- **Celery**: Asynchronous task processing
- **Docker**: Containerization
- **CORS**: Cross-origin resource sharing

This comprehensive platform provides end-to-end travel planning solutions with AI assistance, expert collaboration, and integrated booking capabilities, making it a complete travel ecosystem for users, experts, and service providers.
