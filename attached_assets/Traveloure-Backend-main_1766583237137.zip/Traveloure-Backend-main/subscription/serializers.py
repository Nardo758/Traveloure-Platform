from rest_framework import serializers
from decimal import Decimal
from authentication.models import User, Category, SubCategory
from .models import Wallet, WalletTransaction, APIUsage, CreatedBy, UserAndExpertContract
from authentication.serializers import CategorySerializer, SubCategorySerializer
from django.db.models import Q
# from .models import Wallet, WalletTransaction, APIUsage, UserAndExpertContract, CreatedBy, ContractTransaction
# OLD SUBSCRIPTION SYSTEM - COMMENTED OUT FOR PAY-AS-YOU-GO WALLET SYSTEM
# from .models import Plan

# class PlanSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Plan
#         fields = "__all__"

class WalletSerializer(serializers.ModelSerializer):
    class Meta:
        model = Wallet
        fields = ['balance', 'credits', 'created_at', 'updated_at']

class WalletTransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = WalletTransaction
        fields = ['transaction_type', 'amount', 'credits', 'description', 'created_at']

class APIUsageSerializer(serializers.ModelSerializer):
    class Meta:
        model = APIUsage
        fields = ['api_name', 'cost_per_call', 'created_at']

class WalletRechargeSerializer(serializers.Serializer):
    amount = serializers.DecimalField(max_digits=10, decimal_places=2, min_value=Decimal('5.00'))
    
    def validate_amount(self, value):
        if value < 5.00:
            raise serializers.ValidationError("Minimum recharge amount is $5.00")
        return value
    


class UserAndExpertContractSerializer(serializers.ModelSerializer):
    categories = CategorySerializer(many=True, read_only=True)
    subcategories = SubCategorySerializer(many=True, read_only=True)
    category_ids = serializers.ListField(
        child=serializers.UUIDField(),
        write_only=True,
        required=False
    )
    subcategory_ids = serializers.ListField(
        child=serializers.UUIDField(),
        write_only=True,
        required=False
    )
    class Meta:
        model = UserAndExpertContract
        fields = '__all__'
        read_only_fields = ['id', 'created_by', 'created_at', 'is_paid', 'status']
    
    def create(self, validated_data):
        category_ids = validated_data.pop("category_ids", [])
        subcategory_ids = validated_data.pop("subcategory_ids", [])

        contract = UserAndExpertContract.objects.create(**validated_data)

        if category_ids:
            contract.categories.set(Category.objects.filter(id__in=category_ids))

        if subcategory_ids:
            contract.subcategories.set(SubCategory.objects.filter(id__in=subcategory_ids))

        return contract
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)

        request = self.context.get('request')
        if instance.is_paid:
                representation.pop('payment_url', None)

        if request and hasattr(request, 'user'):
            if request.user.is_local_expert:
                representation.pop('payment_url', None)
        return representation

class ContractDecideSerializer(serializers.Serializer):
    status = serializers.CharField()
