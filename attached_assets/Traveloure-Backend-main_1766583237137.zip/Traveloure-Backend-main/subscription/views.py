import stripe
from django.conf import settings
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from .models import Wallet, WalletTransaction, APIUsage
from .serializers import WalletSerializer, WalletTransactionSerializer, WalletRechargeSerializer, APIUsageSerializer

stripe.api_key = settings.STRIPE_SECRET_KEY

import logging

logger = logging.getLogger(__name__)

class PaymentSuccessView(APIView):
    def get(self, request):
        session_id = request.GET.get('session_id')

        if not session_id:
            return Response({"error": "Session ID is missing"}, status=status.HTTP_400_BAD_REQUEST)

        return Response({"message": "Payment successful", "session_id": session_id}, status=status.HTTP_200_OK)


# Wallet System Views
class WalletBalanceView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """Get user's wallet balance and credits"""
        wallet, created = Wallet.objects.get_or_create(user=request.user)
        return Response({
            "balance": wallet.balance,
            "credits": wallet.credits,
            "has_sufficient_credits": wallet.has_sufficient_credits(),
            "created_at": wallet.created_at,
            "updated_at": wallet.updated_at
        }, status=status.HTTP_200_OK)


class WalletRechargeView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """Create Stripe checkout session for wallet recharge"""
        serializer = WalletRechargeSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        amount = serializer.validated_data['amount']
        user_email = request.user.email

        try:
            # Create Stripe Checkout Session for one-time payment
            checkout_session = stripe.checkout.Session.create(
                payment_method_types=["card"],
                mode="payment",  # One-time payment instead of subscription
                customer_email=user_email,
                line_items=[{
                    "price_data": {
                        "currency": "usd",
                        "product_data": {
                            "name": f"Wallet Recharge - ${amount}",
                            "description": f"Recharge wallet with ${amount}",
                        },
                        "unit_amount": int(amount * 100),  # Convert to cents
                    },
                    "quantity": 1,
                }],
                success_url=f"{settings.FRONTEND_URL}/Itinerary?session_id={{CHECKOUT_SESSION_ID}}",
                cancel_url=f"{settings.FRONTEND_URL}/payment",
                metadata={
                    "user_id": request.user.id,
                    "amount": str(amount),
                    "type": "wallet_recharge",
                    "email": user_email
                }
            )

            return Response({"checkout_url": checkout_session.url}, status=status.HTTP_200_OK)

        except stripe.error.StripeError as e:
            logger.error(f"Stripe Error in wallet recharge: {e}")
            return Response({"error": f"Stripe error: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.error(f"Unexpected Error in wallet recharge: {e}")
            return Response({"error": f"Unexpected error: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class WalletTransactionHistoryView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """Get user's wallet transaction history"""
        wallet, created = Wallet.objects.get_or_create(user=request.user)
        transactions = WalletTransaction.objects.filter(wallet=wallet).order_by('-created_at')
        serializer = WalletTransactionSerializer(transactions, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class APIUsageHistoryView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """Get user's API usage history"""
        usage_records = APIUsage.objects.filter(user=request.user).order_by('-created_at')
        serializer = APIUsageSerializer(usage_records, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


# Utility function for API usage tracking
def track_api_usage(user, api_name, cost_per_call=0.50):
    """
    Track API usage and deduct 1 credit
    Returns: (success, message, remaining_credits, remaining_balance)
    """
    from decimal import Decimal
    
    try:
        wallet, created = Wallet.objects.get_or_create(user=user)
        
        # Debug logging
        logger.info(f"User {user.email} has {wallet.get_credits()} credits and ${wallet.get_balance()} balance")
        
        # Check if user has sufficient credits
        if not wallet.has_sufficient_credits():
            logger.info(f"User {user.email} has insufficient credits: {wallet.get_credits()}")
            return False, "Insufficient credits. Please recharge your wallet.", wallet.get_credits(), float(wallet.get_balance())
        
        # Deduct 1 credit for each API call
        if wallet.deduct_credit():
            # Record the transaction
            WalletTransaction.objects.create(
                wallet=wallet,
                transaction_type='CREDIT_USAGE',
                amount=Decimal('0.50'),  # Keep for backward compatibility
                credits=1,
                description=f"Credit usage: {api_name} (1 credit)"
            )
            
            # Record API usage
            APIUsage.objects.create(
                user=user,
                api_name=api_name,
                cost_per_call=Decimal('0.50')  # Keep for backward compatibility
            )
            
            return True, "API usage tracked successfully", wallet.get_credits(), float(wallet.get_balance())
        else:
            return False, "Failed to deduct credit from wallet", wallet.get_credits(), float(wallet.get_balance())
            
    except Exception as e:
        logger.error(f"Error tracking API usage: {e}")
        return False, "Error tracking API usage", 0, 0.0