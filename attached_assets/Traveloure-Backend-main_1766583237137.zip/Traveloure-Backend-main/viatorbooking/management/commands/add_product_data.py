import json
import os
from django.core.management.base import BaseCommand
from django.conf import settings
from viatorbooking.models import ViatorProduct, ViatorDestination


class Command(BaseCommand):
    help = "Import Viator product and destination data from n.jsonl"

    def handle(self, *args, **options):

        jsonl_path = os.path.join(settings.BASE_DIR, "n.jsonl")

        if not os.path.exists(jsonl_path):
            self.stdout.write(self.style.ERROR(f"File not found: {jsonl_path}"))
            return

        self.stdout.write(self.style.SUCCESS(f"Reading: {jsonl_path}"))

        with open(jsonl_path, "r", encoding="utf-8") as f:
            for line_num, line in enumerate(f, start=1):

                line = line.strip()
                if not line:
                    continue

                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    self.stdout.write(f"Skipping invalid JSON at line {line_num}")
                    continue

                # -------------------------
                # ⭐ Create or update Product
                # -------------------------
                product, created = ViatorProduct.objects.update_or_create(
                    product_code=obj.get("productCode"),
                    defaults={
                        "title": obj.get("title", ""),
                        "status": obj.get("status",""),
                        "pricing_info": obj.get("pricingInfo") or {},
                        "images": obj.get("images") or [],
                        "time_zone": obj.get("timeZone",""),
                        "description": obj.get("description",""),
                        "inclusions": obj.get("inclusions") or [],
                        "exclusions": obj.get("exclusions") or [],
                        "additional_info": obj.get("additionalInfo") or [],
                        "itinerary": obj.get("itinerary") or {},
                        "product_options": obj.get("productOptions") or [],
                        "product_url": obj.get("productUrl"),
                    }
                )

                # -------------------------
                # ⭐ Create Destinations + link M2M
                # -------------------------
                destinations = obj.get("destinations", [])
                if not destinations:
                    continue
                for d in destinations:
                    if not d.get("ref"):
                        continue

                    dest = ViatorDestination.objects.get(destination_id=d.get("ref"))

                    # Link M2M using Django ORM
                    product.destinations.add(dest)
                product.save()

                if line_num % 500 == 0:
                    self.stdout.write(f"Processed {line_num} lines...")

        self.stdout.write(self.style.SUCCESS("Import finished successfully!"))
