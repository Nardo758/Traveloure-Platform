from rest_framework.response import Response
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.views import APIView
from ai_itinerary.models import *
from ai_itinerary.serializers import *
from django.shortcuts import get_object_or_404
from ai_itinerary.utils import *
from django.db import transaction
from django.utils import timezone



class LocalExpertListAPIView(generics.ListAPIView):
    """
    API endpoint to get list of all local experts
    """
    permission_classes = [AllowAny]
    serializer_class = LocalExpertListSerializer
    
    def get_queryset(self):
        from authentication.models import LocalExpertForm
        return LocalExpertForm.objects.filter(status='approved').select_related('user').order_by('-created_at')
    
    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        
        return Response({
            'status': 'success',
            'message': 'Local experts retrieved successfully',
            'count': queryset.count(),
            'data': serializer.data
        }, status=200)
    

class ItineraryAssigningToExpertAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        """Assign an itinerary to a local expert"""
        itinerary_id = request.data.get('trip_id')
        expert_id = request.data.get('expert_id')
        message = request.data.get('message', None)

        if not itinerary_id or not expert_id:
            return Response({'error': "Itinerary ID and Expert ID are required", 'status': False}, status=400)

        itinerary_instance = get_object_or_404(Trip, id=itinerary_id)
        expert_instance = get_object_or_404(User, id=expert_id, is_local_expert=True)

        try:
            with transaction.atomic():
                # Create TripExpertAdvisor
                TripExpertAdvisor.objects.create(
                    trip=itinerary_instance,
                    local_expert=expert_instance,
                    status='pending',
                    message=message or None
                )

                # Create ExpertUpdatedItinerary
                ExpertUpdatedItinerary.objects.create(
                    trip=itinerary_instance,
                    created_by=expert_instance,
                    status='pending',
                    message='Initial Itinerary'
                )

        except Exception as e:
            return Response({
                'error': 'Assignment failed due to unique constraint violation or database error.',
                'details': str(e),
                'status': False
            }, status=400)

        return Response({
            'message': "Trip has been successfully assigned to the local expert",
            'status': True
        }, status=200)
    

class ExpertItineraryDecisionAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        user = request.user
        advisor_instances = TripExpertAdvisor.objects.filter(local_expert=user).order_by('-assigned_at')

        data = []
        for advisor in advisor_instances:
            itinerary = advisor.trip
            data.append({
                "advisor_id": advisor.id,
                "itinerary_title": itinerary.title,
                "itinerary_id": itinerary.id,
                "created_by": itinerary.user.username,
                "created_at": itinerary.created_at,
                "status": advisor.status,
                "assigned_at": advisor.assigned_at
            })

        return Response({"message": "Data Fetched Successfully", "data": data, "status": True}, status=200)

    def post(self, request, *args, **kwargs):
        advisor_id = request.data.get('advisor_id')
        decision = request.data.get('decision')

        advisor = get_object_or_404(TripExpertAdvisor, id=advisor_id, local_expert=request.user)

        if decision not in ['accepted', 'rejected']:
            return Response({'error': 'Invalid decision', 'status': False}, status=400)

        advisor.status = decision
        advisor.save()

        return Response({'message': f'Invitation {decision} successfully', 'status': True}, status=200)


class ExpertUpdatedItineraryView(APIView):
    def get(self, request, trip_id):
        trip = get_object_or_404(Trip, id=trip_id)

        expert_assignment = TripExpertAdvisor.objects.filter(trip=trip, status='accepted').first()

        if request.user != trip.user and (not expert_assignment or request.user != expert_assignment.local_expert):
            return Response({'message': "Permission denied", 'status': False}, status=403)

        itineraries = ExpertUpdatedItinerary.objects.filter(trip=trip).order_by('-created_at')
        serializer = ExpertUpdatedItinerarySerializer(itineraries, many=True)
        return Response({'data': serializer.data, 'status': True}, status=200)

    def patch(self, request, trip_id):
        trip = get_object_or_404(Trip, id=trip_id)

        # Ensure the user is the assigned expert
        expert_assignment = TripExpertAdvisor.objects.filter(
            trip=trip,
            local_expert=request.user,
            status='accepted'
        ).first()

        if not expert_assignment:
            return Response({'message': "Only the assigned local expert can update the itinerary", 'status': False}, status=403)

        message = request.data.get("message")
        if not message:
            return Response({'message': "Message is required", 'status': False}, status=400)

        # Get the existing ExpertUpdatedItinerary
        itinerary_instance = ExpertUpdatedItinerary.objects.filter(
            trip=trip,
            created_by=request.user
        ).first()

        if not itinerary_instance:
            return Response({'message': "No existing itinerary found to update", 'status': False}, status=404)

        serializer = ExpertUpdatedItinerarySerializer(
            itinerary_instance,
            data=request.data,
            partial=True  # PATCH allows partial update
        )

        if serializer.is_valid():
            try:
                with transaction.atomic():
                    serializer.save(
                        trip=trip,
                        created_by=request.user,
                        status='pending'
                    )
                return Response({'message': "Itinerary updated", 'data': serializer.data, 'status': True}, status=200)
            except Exception as e:
                return Response({'message': "Update failed", 'error': str(e), 'status': False}, status=500)

        return Response({'message': "Validation failed", 'errors': serializer.errors, 'status': False}, status=400)

class DecisionExpertUpdatedItineraryAPIView(APIView):
    def patch(self, request, id):
        status = request.data.get('status')
        if status not in ['accepted', 'rejected']:
            return Response({'message': "Invalid status", 'status': False}, status=400)

        try:
            expert_itinerary = ExpertUpdatedItinerary.objects.get(id=id)
        except ExpertUpdatedItinerary.DoesNotExist:
            return Response({'message': "Expert itinerary not found", 'status': False}, status=404)

        trip = expert_itinerary.trip
        generated_itinerary = getattr(trip, 'generated_itinerary', None)

        if not generated_itinerary:
            return Response({'message': "Generated itinerary does not exist for this trip", 'status': False}, status=404)
        if request.user != generated_itinerary.trip.user:
            return Response({'message': "Permission denied", 'status': False}, status=403)
        message = None
        if status == 'accepted':
            generated_itinerary.itinerary_data = expert_itinerary.itinerary_data
            generated_itinerary.status = 'completed'
            generated_itinerary.error_message = ''
            generated_itinerary.updated_at = timezone.now()
            expert_itinerary.status = 'accepted'
            generated_itinerary.save()
            message = "Generated itinerary updated from expert successfully"
        else:
            expert_itinerary.itinerary_data = generated_itinerary.itinerary_data
            expert_itinerary.status = 'rejected'
            expert_itinerary.save()
            message = "Expert Itinerary is rejected."

        return Response({'message': message, 'status': True}, status=200)