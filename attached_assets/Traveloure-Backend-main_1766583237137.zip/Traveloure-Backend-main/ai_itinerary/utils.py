import requests
import re
from django.conf import settings
from rest_framework.response import Response
from rest_framework.pagination import PageNumberPagination


def get_weather_forecast(city, country, start_date, end_date):
    """
    Fetch weather forecast data for a city between start_date and end_date.
    
    Args:
        city (str): City name
        country (str): Country name
        start_date (str): Start date in YYYY-MM-DD format
        end_date (str): End date in YYYY-MM-DD format
        
    Returns:
        dict: Dictionary with weather data for each day
    """
    try:
        # Format location with country for better accuracy
        location = f"{city},{country}"
        
        # Fetch weather data for the entire date range
        url = f"https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/{location}/{start_date}/{end_date}?unitGroup=metric&key={settings.WEATHER_API_KEY}&include=days"
        
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        
        # Extract daily forecasts
        weather_data = {}
        if "days" in data:
            for day in data["days"]:
                date = day["datetime"]
                weather_data[date] = {
                    "temp_min": day.get("tempmin", 0),
                    "temp_max": day.get("tempmax", 0),
                    "conditions": day.get("conditions", "Unknown"),
                    "precip_prob": day.get("precipprob", 0),
                    "precip_amount": day.get("precip", 0),
                    "humidity": day.get("humidity", 0),
                    "wind_speed": day.get("windspeed", 0),
                    "description": day.get("description", "")
                }
        
        return weather_data
    
    except Exception as e:
        # Return empty dict if weather data can't be fetched
        return {}

def get_weather_summary(weather_data):
    """
    Generate a summary of weather conditions for the entire trip.
    
    Args:
        weather_data (dict): Dictionary with weather data for each day
        
    Returns:
        str: Summary of weather conditions
    """
    if not weather_data:
        return "Weather data not available for this location and date range."
    
    # Count days with different conditions
    conditions_count = {}
    for date, data in weather_data.items():
        condition = data["conditions"]
        if condition in conditions_count:
            conditions_count[condition] += 1
        else:
            conditions_count[condition] = 1
    
    # Calculate average temperatures
    total_min = sum(data["temp_min"] for data in weather_data.values())
    total_max = sum(data["temp_max"] for data in weather_data.values())
    avg_min = total_min / len(weather_data)
    avg_max = total_max / len(weather_data)
    
    # Generate summary
    summary = f"Weather Summary: {len(weather_data)} days\n"
    summary += f"Temperature Range: {avg_min:.1f}°C to {avg_max:.1f}°C\n"
    summary += "Conditions: "
    
    for condition, count in conditions_count.items():
        percentage = (count / len(weather_data)) * 100
        summary += f"{condition} ({percentage:.0f}%), "
    
    # Check for rain probability
    rainy_days = sum(1 for data in weather_data.values() if data["precip_prob"] > 30)
    if rainy_days > 0:
        summary += f"\nRain expected on {rainy_days} days."
    
    return summary 
def fetch_live_events(location: str, year: int, serp_api_key: str):
    """
    Fetch live events from Google Events API using SerpAPI and add image thumbnails via image search.
    """
    query = f"Events in {location}"
    params = {
        "engine": "google_events",
        "q": query,
        "location": location,
        "hl": "en",
        "gl": "us",
        "api_key": serp_api_key,
        "no_cache": "true"  # Force fresh results
    }

    try:
        response = requests.get("https://serpapi.com/search", params=params)
        
        if response.status_code == 200:
            data = response.json()
            events = data.get("events_results", [])

            for event in events:
                if not event.get("thumbnail"):
                    search_query = f"{event.get('title', '')} event in {location}"
                    image_results = fetch_images_via_serp_api(search_query, serp_api_key)
                    if image_results:
                        event["thumbnail"] = image_results # Assign first image

            return events
        else:
            return []
    except Exception as e:
        return []
    
def fetch_images_via_serp_api(query, api_key, max_images=3):
        serp_url = "https://serpapi.com/search.json"
        params = {
            "q": query,
            "tbm": "isch",  # image search
            "api_key": api_key
        }
        response = requests.get(serp_url, params=params)
        data = response.json()

        thumbnails = []
        suggested = data.get("images_results", [])
        for item in suggested:
            thumb = item.get("original")
            if thumb:
                thumbnails.append(thumb)

        return thumbnails[:5]


def validate_personal_information(message):
    """
    Validate message for personal information and return error if found.
    
    Args:
        message (str): Message text to validate
        
    Returns:
        dict: {'is_valid': bool, 'error': str or None}
    """
    if not message:
        return {'is_valid': True, 'error': None}
    
    # Convert message to lowercase for pattern matching
    message_lower = message.lower()
    
    # Email patterns (comprehensive)
    email_patterns = [
        r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',  # Standard email
        r'[a-zA-Z0-9._%+-]+\s*at\s*the\s*rate\s*[a-zA-Z0-9.-]+\s*dot\s*[a-zA-Z]{2,}',  # "user at the rate gmail dot com"
        r'[a-zA-Z0-9._%+-]+\s*at\s*[a-zA-Z0-9.-]+\s*dot\s*[a-zA-Z]{2,}',  # "user at gmail dot com"
        r'[a-zA-Z0-9._%+-]+\s*@\s*[a-zA-Z0-9.-]+\s*\.\s*[a-zA-Z]{2,}',  # Spaced email
        r'[a-zA-Z0-9._%+-]+[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',  # Missing @ symbol like vipangmail.com
        r'\b[a-zA-Z0-9._%+-]+gmail\.com\b',  # Specifically catch gmail variations
        r'\b[a-zA-Z0-9._%+-]+yahoo\.com\b',  # Yahoo variations
        r'\b[a-zA-Z0-9._%+-]+hotmail\.com\b',  # Hotmail variations
        r'\b[a-zA-Z0-9._%+-]+outlook\.com\b',  # Outlook variations
    ]
    
    # Phone number patterns (comprehensive)
    phone_patterns = [
        r'\b\d{10}\b',  # 9876543210
        r'\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b',  # 123-456-7890, 123.456.7890, 123 456 7890
        r'\+\d{1,3}[-.\s]?\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b',  # +1-123-456-7890
        r'\(\d{3}\)[-.\s]?\d{3}[-.\s]?\d{4}\b',  # (123)456-7890
        r'\b\d{3}[-.\s]?\d{4}[-.\s]?\d{3}\b',  # Alternative format
        r'\b9\d{9}\b',  # Indian mobile pattern starting with 9
        r'\b8\d{9}\b',  # Indian mobile pattern starting with 8
        r'\b7\d{9}\b',  # Indian mobile pattern starting with 7
        r'\b6\d{9}\b',  # Indian mobile pattern starting with 6
    ]
    
    # Written phone number patterns (spelled out numbers)
    written_phone_patterns = [
        r'\b(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)',
        r'\b(zero|one|two|three|four|five|six|seven|eight|nine)\s+(zero|one|two|three|four|five|six|seven|eight|nine)\s+(zero|one|two|three|four|five|six|seven|eight|nine)\s+(zero|one|two|three|four|five|six|seven|eight|nine)\s+(zero|one|two|three|four|five|six|seven|eight|nine)\s+(zero|one|two|three|four|five|six|seven|eight|nine)\s+(zero|one|two|three|four|five|six|seven|eight|nine)\s+(zero|one|two|three|four|five|six|seven|eight|nine)\s+(zero|one|two|three|four|five|six|seven|eight|nine)\s+(zero|one|two|three|four|five|six|seven|eight|nine)',
    ]
    
    # Credit card patterns
    credit_card_patterns = [
        r'\b\d{4}[-.\s]?\d{4}[-.\s]?\d{4}[-.\s]?\d{4}\b',  # 1234-5678-9012-3456
        r'\b\d{16}\b',  # 16 continuous digits
    ]
    
    # Social security patterns
    ssn_patterns = [
        r'\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b',  # 123-45-6789
    ]
    
    # Aadhaar card patterns (Indian)
    aadhaar_patterns = [
        r'\b\d{4}[-.\s]?\d{4}[-.\s]?\d{4}\b',  # 1234-5678-9012
        r'\b\d{12}\b',  # 12 continuous digits
    ]
    
    # PAN card patterns (Indian)
    pan_patterns = [
        r'\b[A-Z]{5}\d{4}[A-Z]\b',  # ABCDE1234F
    ]
    
    # Check for emails
    for pattern in email_patterns:
        if re.search(pattern, message, re.IGNORECASE):
            return {'is_valid': False, 'error': 'Message cannot contain email addresses'}
    
    # Check for phone numbers
    for pattern in phone_patterns:
        if re.search(pattern, message):
            return {'is_valid': False, 'error': 'Message cannot contain phone numbers'}
    
    # Check for written phone numbers
    for pattern in written_phone_patterns:
        if re.search(pattern, message_lower):
            return {'is_valid': False, 'error': 'Message cannot contain phone numbers'}
    
    # Check for credit card numbers
    for pattern in credit_card_patterns:
        if re.search(pattern, message):
            # Additional validation: check if it's actually a credit card (not just any 16-digit number)
            digits_only = re.sub(r'[-.\s]', '', re.search(pattern, message).group())
            if len(digits_only) == 16:
                return {'is_valid': False, 'error': 'Message cannot contain credit card numbers'}
    
    # Check for social security numbers
    for pattern in ssn_patterns:
        if re.search(pattern, message):
            return {'is_valid': False, 'error': 'Message cannot contain social security numbers'}
    
    # Check for Aadhaar numbers
    for pattern in aadhaar_patterns:
        if re.search(pattern, message):
            digits_only = re.sub(r'[-.\s]', '', re.search(pattern, message).group())
            if len(digits_only) == 12:
                return {'is_valid': False, 'error': 'Message cannot contain Aadhaar numbers'}
    
    # Check for PAN numbers
    for pattern in pan_patterns:
        if re.search(pattern, message, re.IGNORECASE):
            return {'is_valid': False, 'error': 'Message cannot contain PAN card numbers'}
    
    # Additional checks for common personal info keywords
    personal_info_keywords = [
        r'\b(my\s+)?(phone|mobile|number|contact)\s*(is|:)?\s*\d',
        r'\b(my\s+)?(email|mail)\s*(is|:)?\s*\w+@?',
        r'\b(my\s+)?(email|mail)\s*(is|:)?\s*\w+\s*(gmail|yahoo|hotmail|outlook)',
        r'\b(my\s+)?(whatsapp|telegram)\s*(is|:)?\s*\d',
        r'\b(call\s+me|contact\s+me)\s*(at|on)?\s*\d',
        r'\b(contact|reach)\s*(me\s*)?(on|at)\s*(my\s*)?(email|phone|number)',
        r'\b(contact|reach)\s*(me\s*)?(on|at)\s*(this|my)\s*(number|phone)',
        r'\bcontant\s+me\s+on\s+',  # Common typo "contant"
        r'\bemail\s+me\s+at\s+',
        r'\bmessage\s+me\s+on\s+',
    ]
    
    for pattern in personal_info_keywords:
        if re.search(pattern, message_lower):
            return {'is_valid': False, 'error': 'Message cannot contain personal contact information'}
    
    return {'is_valid': True, 'error': None}


class ChatPagination(PageNumberPagination):
    page_size = 50
    page_size_query_param = 'limit'
    max_page_size = 100

    def get_paginated_response(self, data):
        return Response({
            'count':self.page.paginator.count,
            'total_pages':self.page.paginator.num_pages,
            'data': data,
            'status': True
        })