from django.db import models
from authentication.models import User, get_dynamic_storage
import uuid
from serviceproviderapp.models import AllService
from authentication.models import Category, SubCategory

class Wallet(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    balance = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)  # Keep for backward compatibility
    credits = models.IntegerField(default=0)  # New credit system
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.email} - ${self.balance} - {self.credits} credits"

    def add_credits(self, amount_dollars):
        """Add credits based on dollar amount (1$ = 2 credits)"""
        # Convert to float first to handle both Decimal and float inputs
        amount_float = float(amount_dollars)
        credits_to_add = int(amount_float * 2)
        self.credits += credits_to_add
        self.save()
        return credits_to_add

    def deduct_credit(self):
        """Deduct 1 credit for each search"""
        if self.credits >= 1:
            self.credits -= 1
            self.save()
            return True
        return False

    def get_credits(self):
        return self.credits

    def has_sufficient_credits(self):
        return self.credits >= 1

    # Keep old methods for backward compatibility
    def add_balance(self, amount):
        """Add amount to wallet balance"""
        # Convert to Decimal for consistency
        from decimal import Decimal
        if isinstance(amount, float):
            amount = Decimal(str(amount))
        self.balance += amount
        self.save()

    def deduct_balance(self, amount):
        """Deduct amount from wallet balance"""
        if self.balance >= amount:
            self.balance -= amount
            self.save()
            return True
        return False

    def get_balance(self):
        """Get current wallet balance"""
        return self.balance


class WalletTransaction(models.Model):
    TRANSACTION_TYPES = [
        ('RECHARGE', 'Recharge'),
        ('API_USAGE', 'API Usage'),
        ('REFUND', 'Refund'),
        ('CREDIT_RECHARGE', 'Credit Recharge'),
        ('CREDIT_USAGE', 'Credit Usage'),
    ]

    wallet = models.ForeignKey(Wallet, on_delete=models.CASCADE)
    transaction_type = models.CharField(max_length=20, choices=TRANSACTION_TYPES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    credits = models.IntegerField(default=0)  # Track credits
    description = models.TextField(blank=True, null=True)
    stripe_payment_intent_id = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.wallet.user.email} - {self.transaction_type} - ${self.amount} - {self.credits} credits"


class APIUsage(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    api_name = models.CharField(max_length=100)  # e.g., 'itinerary_generation', 'hotel_search'
    cost_per_call = models.DecimalField(max_digits=5, decimal_places=2, default=0.50)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.email} - {self.api_name} - ${self.cost_per_call}"


class AnonymousAPIUsage(models.Model):
    ip_address = models.GenericIPAddressField()
    api_name = models.CharField(max_length=100)
    used_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['ip_address', 'api_name']
    
    def __str__(self):
        return f"{self.ip_address} - {self.api_name} - {self.used_at}"


# --- ENUM CLASS USED IN DJANGO ---
class CreatedBy(models.TextChoices):
    USER = 'user', "User"
    EXPERT = 'expert', "Expert"

# --- OFFER CREATION MODEL BY USER AND EXPERT ---
class UserAndExpertContract(models.Model):
    id = models.UUIDField(primary_key=True, db_index=True, default=uuid.uuid4, editable=False)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name="contract_creatd_by")
    created_for = models.ForeignKey(User, on_delete=models.CASCADE, related_name="contract_created_for")
    title = models.CharField(max_length=255, null=False, blank=False)
    trip_to = models.CharField(max_length=200,null=False, blank=False)
    description = models.TextField(null=False, blank=False)
    attachment = models.FileField(upload_to='user_Expert_contract/',storage=get_dynamic_storage(), null=True)
    status = models.CharField(default="pending")
    amount = models.DecimalField(null=False, max_digits = 20, decimal_places=2)
    is_paid = models.BooleanField(default=False)
    payment_url = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    categories = models.ManyToManyField(Category, related_name="contracts", blank=True)
    subcategories = models.ManyToManyField(SubCategory, related_name="contracts", blank=True)


class PaymentStatus(models.TextChoices):
    REQUIRES_PAYMENT_METHOD = "requires_payment_method", "Requires Payment Method"
    REQUIRES_CONFIRMATION = "requires_confirmation", "Requires Confirmation"
    REQUIRES_ACTION = "requires_action", "Requires Action"
    PROCESSING = "processing", "Processing"
    REQUIRES_CAPTURE = "requires_capture", "Requires Capture"
    CANCELED = "canceled", "Canceled"
    SUCCEEDED = "succeeded", "Succeeded"


class TransactionType(models.TextChoices):
    RECHARGE = "recharge", "Recharge"
    API_USAGE = "api_usage", "API Usage"
    REFUND = "refund", "Refund"
    CREDIT_RECHARGE = "credit_recharge", "Credit Recharge"
    CREDIT_USAGE = "credit_usage", "Credit Usage"
    CONTRACT_TRANSACTION = "contract_transaction", "Contract Transaction"


class ContractTransaction(models.Model):
    id = models.UUIDField(primary_key=True, null=False, default=uuid.uuid4, db_index=True)
    contract_id = models.ForeignKey(UserAndExpertContract, on_delete=models.CASCADE, related_name="contract_transaction_contract_id_key")
    user_id = models.ForeignKey(User, on_delete=models.CASCADE, related_name="contract_transaction_user_id_key")
    expert_id = models.ForeignKey(User, on_delete=models.CASCADE, related_name="contract_transaction_expert_id_key")
    amount = models.DecimalField(null=False, max_digits = 20, decimal_places=2)
    transaction_id = models.CharField(max_length=150)
    stripe_charge_id = models.CharField(null=True, max_length=255, blank=True)
    transaction_type = models.CharField(max_length=50, choices=TransactionType)
    payment_status = models.CharField(max_length=60, choices=PaymentStatus)
    is_succeeded = models.BooleanField()
    paid_to_expert = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

class ServiceTransaction(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='purchased_services')
    service = models.ForeignKey(AllService, on_delete=models.CASCADE, related_name='transactions')
    seller = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sold_services')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, default='usd')
    payment_intent_id = models.CharField(max_length=255, null=True, blank=True)
    status = models.CharField(
        max_length=50,
        choices=[
            ('pending', 'Pending'),
            ('succeeded', 'Succeeded'),
            ('failed', 'Failed'),
            ('refunded', 'Refunded'),
        ],
        default='pending'
    )
    created_at = models.DateTimeField(auto_now_add=True)

