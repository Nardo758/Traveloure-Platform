from django.contrib import admin
from .models import (
    Wallet, WalletTransaction, APIUsage, AnonymousAPIUsage,
    UserAndExpertContract, ContractTransaction, ServiceTransaction
)

# Register all models
admin.site.register(Wallet)
admin.site.register(WalletTransaction)
admin.site.register(APIUsage)
admin.site.register(AnonymousAPIUsage)
admin.site.register(UserAndExpertContract)
admin.site.register(ContractTransaction)
admin.site.register(ServiceTransaction)