from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.conf import settings
from ai_itinerary.models import *
from ai_itinerary.serializers import *
import json
from ai_itinerary.utils import *
from django.utils.dateparse import parse_date
from openai import OpenAI



class GenerateItineraryView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        start_date = parse_date(request.data.get("start_date"))
        end_date = parse_date(request.data.get("end_date"))
        place_ids = request.data.get("place_ids", [])

        if not place_ids or not isinstance(place_ids, list):
            return Response({"error": "place_ids must be a list of IDs."}, status=status.HTTP_400_BAD_REQUEST)
        
        if not start_date or not end_date or end_date <= start_date:
            return Response({"error": "Invalid start or end date."}, status=status.HTTP_400_BAD_REQUEST)

        tourist_places = TouristPlaceResults.objects.filter(id__in=place_ids)

        if tourist_places.count() != len(place_ids):
            return Response({"error": "Some place IDs are invalid."}, status=status.HTTP_400_BAD_REQUEST)

        # Ensure all places are from the same country
        country_set = set(tourist_places.values_list("country", flat=True))
        if len(country_set) != 1:
            return Response({"error": "All selected places must be from the same country."}, status=status.HTTP_400_BAD_REQUEST)

        total_days = (end_date - start_date).days
        categories = {
            "Nightlife": [],
            "Religious": [],
            "Food": [],
            "Adventure": []
        }

        prompt = self.build_prompt(tourist_places, start_date, end_date, total_days, categories)
        try:
            client = OpenAI(api_key=settings.OPENAI_API_KEY)
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a professional travel planner. Respond strictly in valid JSON format as requested."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7
            )
            raw_result = response.choices[0].message.content.strip()
            itinerary_data = self.extract_json(raw_result)
            inclusive = ", ".join(itinerary_data.get("inclusive", []))
            exclusive = ", ".join(itinerary_data.get("exclusive", []))
            places = itinerary_data.get("places", [])
            day_by_day_plan = itinerary_data.get("day_by_day_plan", {})

            summary_description = f"Trip from {itinerary_data.get('start_point')} to {itinerary_data.get('end_point')} over {itinerary_data.get('number_of_days')} days."

            trip = HelpGuideTrip.objects.create(
                user=user,
                country=tourist_places.first().country,
                state="",
                city=tourist_places.first().city,
                title=f"Trip to {tourist_places.first().city}",
                description=summary_description,
                highlights=", ".join([p["highlights"] for p in places if "highlights" in p]),
                days=itinerary_data.get("number_of_days", total_days),
                nights=itinerary_data.get("number_of_nights", total_days - 1),
                price=itinerary_data.get("price", []),
                old_price=itinerary_data.get("old_price", []),
                start_date=start_date,
                end_date=end_date,
                inclusive=inclusive,
                exclusive=exclusive,
                metadata={
                    "places": places,
                    "day_by_day_plan": day_by_day_plan
                }
            )

            serializer = HelpGuideTripSerializer(trip)
            return Response({
                "message": "Itinerary created successfully.", 
                "trip_id": str(trip.id),
                "data": serializer.data
            }, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def build_prompt(self, places, start_date, end_date, days, categories):
        place_summaries = ""
        for p in places:
            place_summaries += (
                f"\n- {p.place} ({p.category}) in {p.city}: {p.description}. "
                f"Activities: {', '.join(p.activities or [])}. Festivals: {', '.join(p.festivals or [])}."
            )

        format_description = """
Return the itinerary in the following JSON format:
{
  "start_point": "City name",
  "end_point": "City name",
  "number_of_days": 5,
  "number_of_nights": 4,
  "price":x.00, (THe Price will be the estimated cost of the whole trip in Dollars)
  "old_price":x.00, (Old Price will be slight less than the Actual Price.)
  "places": [
    {
      "name": "Place Name",
      "city": "City",
      "category": "e.g. Religious / Food / Adventure / Nightlife",
      "highlights": "Short highlight of this place",
      "day": 1
    },
    ...
  ],
  "inclusive": ["Hotels", "Sightseeing", "Transportation"],
  "exclusive": ["Flights", "Personal expenses"],
  "day_by_day_plan": {
    "Day 1": "Visit X, Y, Z...",
    "Day 2": "...",
    ...
  }
}
"""

        prompt = f"""
I am planning a trip from {start_date} to {end_date}, which is {days} days long.

Here are the selected tourist places:{place_summaries}

Please generate a realistic, exciting, and balanced itinerary in valid JSON using this structure:
{format_description}

The itinerary should include categories such as nightlife, religious, food, and adventure. Assign them accordingly. Choose a start_point and end_point from the cities involved.
Include a list of what's inclusive and exclusive, and provide a clear day-by-day plan for the whole trip.
"""
        return prompt
    
    def extract_json(self, text):
        import re, json

        # Remove ```json ... ``` wrapper if present
        text = re.sub(r"```json|```", "", text).strip()

        # Extract ONLY JSON object
        start = text.find("{")
        end = text.rfind("}")

        if start == -1 or end == -1:
            raise ValueError("Model did not return JSON")

        cleaned = text[start:end + 1]

        return json.loads(cleaned)
