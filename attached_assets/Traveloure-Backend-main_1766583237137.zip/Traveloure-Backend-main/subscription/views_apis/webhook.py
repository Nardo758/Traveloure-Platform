import stripe
from decimal import Decimal
from django.conf import settings
from subscription.models import Wallet, WalletTransaction, TransactionType, PaymentStatus, UserAndExpertContract,ContractTransaction, ServiceTransaction
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from authentication.models import User
from serviceproviderapp.models import AllService



stripe.api_key = settings.STRIPE_SECRET_KEY

import logging

logger = logging.getLogger(__name__)


@csrf_exempt
def stripe_webhook(request):
    payload = request.body
    sig_header = request.META.get("HTTP_STRIPE_SIGNATURE")
    endpoint_secret = settings.STRIPE_WEBHOOK_SECRET

    try:
        event = stripe.Webhook.construct_event(payload, sig_header, endpoint_secret)
        print(f"Received event: {event['type']}")
    except ValueError as e:
        print("Error: Invalid payload", e)
        return JsonResponse({"error": "Invalid payload"}, status=400)
    except stripe.error.SignatureVerificationError as e:
        print("Error: Invalid signature", e)
        return JsonResponse({"error": "Invalid signature"}, status=400)
    if event['type'] == 'account.updated':
        account = event['data']['object']
        stripe_account_id = account['id']
        # Check if the account is fully onboarded
        charges_enabled = account.get('charges_enabled', False)
        payouts_enabled = account.get('payouts_enabled', False)
        details_submitted = account.get('details_submitted', False)

        print(f"Account updated: {stripe_account_id}")
        print(f"Charges enabled: {charges_enabled}, Payouts enabled: {payouts_enabled}, Details submitted: {details_submitted}")

        # Consider onboarding complete if charges and payouts are enabled
        onboarding_complete = charges_enabled and payouts_enabled and details_submitted

        try:
            # Find the user with the matching stripe_account_id
            user = User.objects.get(stripe_account_id=stripe_account_id)
            user.stripe_onboarding_complete = onboarding_complete
            user.save()
            print(f"Updated user {user.email} onboarding status: {onboarding_complete}")
        except User.DoesNotExist:
            print(f"No user found with stripe_account_id: {stripe_account_id}")

    if event['type'] == 'connect account.application.authorized':
        print("Connect account application authorized")
        # This event is fired when a Connect account is authorized
        # You might want to handle this event as well
        pass

    if event["type"] == "checkout.session.completed":
        print("Checkout Session Completed")

        session = event["data"]["object"]
        user_email = session.get("customer_email", None)
        transaction_id = session.get("id")
        metadata = session.get("metadata", {})
        payment_type = metadata.get("type")

        if payment_type != TransactionType.CONTRACT_TRANSACTION:
            if not user_email:
                print("Error: Missing user email")
                return JsonResponse({"error": "Missing user email"}, status=400)

            try:
                user = User.objects.get(email=user_email)
            except User.DoesNotExist:
                print(f"Error: User with email {user_email} not found")
                return JsonResponse({"error": "User not found"}, status=400)
        
        if payment_type == "service_payment":
            service_id = metadata.get("service_id")
            seller_id = metadata.get("seller_id")
            amount = metadata.get("amount")
            try:
                service = AllService.objects.get(id=service_id)
            except AllService.DoesNotExist:
                print(f"Error: Service with id {service_id} not found")
                return JsonResponse({"error": "Service not found"}, status=400)

            try:
                seller = User.objects.get(id=seller_id)
            except User.DoesNotExist:
                print(f"Error: Seller with id {seller_id} not found")
                return JsonResponse({"error": "Seller not found"}, status=400)

            # Create ServiceTransaction record with seller
            ServiceTransaction.objects.create(
                buyer=user,
                service=service,
                seller=seller,
                amount=float("amount"),
                currency='usd',
                payment_intent_id=transaction_id,
                status='succeeded' if session.get("payment_status") == "paid" else 'pending'
            )

            print(f"Service transaction created for {user.email}: ${amount} for service {service.service_name} to seller {seller.username}")
            return JsonResponse({"status": "success"}, status=200)
        
        # Handle wallet recharge
        if payment_type == "wallet_recharge":
            amount = float(metadata.get("amount", 0))
            
            if amount > 0:
                wallet, created = Wallet.objects.get_or_create(user=user)
                # Convert float to Decimal for consistency
                amount_decimal = Decimal(str(amount))
                
                # Add credits based on dollar amount (1$ = 2 credits)
                credits_added = wallet.add_credits(amount)
                
                # Record the transaction
                WalletTransaction.objects.create(
                    wallet=wallet,
                    transaction_type='CREDIT_RECHARGE',
                    amount=amount_decimal,
                    credits=credits_added,
                    description=f"Credit recharge via Stripe: ${amount} = {credits_added} credits",
                    stripe_payment_intent_id=transaction_id
                )
                
                print(f"Credits recharged for {user.email}: ${amount} = {credits_added} credits")
                return JsonResponse({"status": "success"}, status=200)

        # Handle subscription payments (existing logic) - COMMENTED OUT FOR WALLET SYSTEM
        # elif payment_type != "wallet_recharge":
        #     stripe_subscription_id = session.get("subscription")

        #     if not stripe_subscription_id:
        #         print("Error: Missing subscription ID for subscription payment")
        #         return JsonResponse({"error": "Missing subscription ID"}, status=400)

        #     # Fetch line items separately
        #     try:
        #         line_items = stripe.checkout.Session.list_line_items(session["id"])
        #         if not line_items["data"]:
        #             print("Error: No line items found")
        #             return JsonResponse({"error": "No line items found"}, status=400)

        #         price_id = line_items["data"][0]["price"]["id"]
        #         amount_paid = line_items["data"][0]["amount_total"] / 100  # Convert cents to dollars
        #     except Exception as e:
        #         print("Error fetching line items:", e)
        #         return JsonResponse({"error": "Failed to retrieve line items"}, status=400)

        #     # Get subscription details from Stripe
        #     try:
        #         stripe_subscription = stripe.Subscription.retrieve(stripe_subscription_id)
        #         current_period_end = stripe_subscription.get("current_period_end")  # UNIX timestamp
        #         expire_date = make_aware(datetime.fromtimestamp(current_period_end))
        #     except Exception as e:
        #         print("Error retrieving subscription details:", e)
        #         return JsonResponse({"error": "Failed to retrieve subscription details"}, status=400)

        #     # Find plan
        #     try:
        #         plan = Plan.objects.get(stripe_price_id=price_id)
        #     except Plan.DoesNotExist:
        #         print(f"Error: Plan with price ID {price_id} not found")
        #         return JsonResponse({"error": "Plan not found"}, status=400)

        #     # Update existing subscription (if any) instead of creating a new one
        #     existing_subscription = Subscription.objects.filter(user=user, is_active=True).first()

        #     if existing_subscription:
        #         existing_subscription.plan = plan
        #         existing_subscription.stripe_subscription_id = stripe_subscription_id
        #         existing_subscription.status = "active"
        #         existing_subscription.expire_date = expire_date
        #         existing_subscription.is_active = True
        #         existing_subscription.save()
        #         subscription_instance = existing_subscription
        #         print(f"Updated existing subscription for {user.email} to {plan.plan_name}")

        #     else:
        #         subscription_instance = Subscription.objects.create(
        #         user=user,
        #         plan=plan,
        #         stripe_subscription_id=stripe_subscription_id,
        #         status="active",
        #         expire_date=expire_date,
        #         is_active=True,
        #     )
        #         print(f"Created new subscription for {user.email}")

        #     # Save payment details
        #     Payment.objects.create(
        #         user=user,
        #         subscription=subscription_instance,
        #         transaction_id=transaction_id,
        #         amount_paid=amount_paid,
        #         payment_status="Completed",
        #     )
        #         print(f"Payment record created for {user.email}, Amount: {amount_paid}")

        if payment_type == TransactionType.CONTRACT_TRANSACTION:
            print("Event Data: ", event["data"])
            print("Handling CONTRACT_TRANSACTION payment type...")

            contract_id = metadata.get("contract_id")
            print(f"Looking up contract with ID: {contract_id}")

            contract_instance = UserAndExpertContract.objects.filter(id=contract_id).first()

            if not contract_instance:
                print(f"[ERROR] Contract with ID {contract_id} not found.")
                return

            print(f"Contract found: ID={contract_instance.id}, Title={contract_instance.title}")

            payment_status = session.get("payment_status")
            session_status = session.get("status")

            print(f"Received payment status: {payment_status}, session status: {session_status}")

            payment_succeeded = (payment_status == "paid" and session_status == "complete")

            if payment_succeeded:
                contract_instance.is_paid = True
                contract_instance.save()
                print(f"[SUCCESS] Contract {contract_instance.id} marked as PAID.")
            else:
                print(f"[INFO] Contract {contract_instance.id} NOT marked as paid - Payment status: {payment_status}, Status: {session_status}")

            # Get user and expert for transaction
            user_id = metadata.get("user_id")
            expert_id = metadata.get("expert_id")

            user = User.objects.filter(id=user_id).first()
            expert = User.objects.filter(id=expert_id).first()

            print(f"User ID from metadata: {user_id} -> User found: {bool(user)}")
            print(f"Expert ID from metadata: {expert_id} -> Expert found: {bool(expert)}")

            amount_total = session.get("amount_total")
            print(f"Amount received from session: {amount_total} cents (${amount_total / 100})")
            payment_intent_id = session.get("payment_intent")
            charge_id = None
            if payment_intent_id:
                payment_intent = stripe.PaymentIntent.retrieve(payment_intent_id)
                charge_id = payment_intent.get("latest_charge")  # Use latest_charge instead of charges.data
                if not charge_id:
                    print(f"[WARNING] No latest_charge found in PaymentIntent {payment_intent_id}. Charge ID not available yet.")
            else:
                print("[WARNING] No payment_intent ID in session.")
            contract_transaction_instance = ContractTransaction.objects.create(
                contract_id=contract_instance,
                user_id=user,
                expert_id=expert,
                transaction_id=transaction_id,
                transaction_type=TransactionType.CONTRACT_TRANSACTION,
                payment_status=PaymentStatus.SUCCEEDED if payment_succeeded else PaymentStatus.REQUIRES_CONFIRMATION,
                is_succeeded=payment_succeeded,
                stripe_charge_id=charge_id,
                paid_to_expert=False,
                amount=amount_total / 100
            )

            print(f"[INFO] ContractTransaction created for contract {contract_instance.id}, transaction ID: {transaction_id}")
            from asgiref.sync import async_to_sync
            from channels.layers import get_channel_layer

            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                f"user_{user.id}",
                {
                    "type": "contract_payment_success",
                    "payload": {
                        "contract_id": str(contract_instance.id),
                        "title": contract_instance.title,
                        "amount": amount_total / 100,
                        "message": "Contract payment completed successfully",
                        "created_at": contract_transaction_instance.created_at.isoformat(),
                    }
                }
            )
            async_to_sync(channel_layer.group_send)(
                f"user_{expert.id}",
                {
                    "type": "contract_payment_success",
                    "payload": {
                        "contract_id": str(contract_instance.id),
                        "title": contract_instance.title,
                        "amount": amount_total / 100,
                        "message": "Contract payment completed successfully",
                        "created_at": contract_transaction_instance.created_at.isoformat(),
                    }
                }
            )
    return JsonResponse({"status": "success"}, status=200)

