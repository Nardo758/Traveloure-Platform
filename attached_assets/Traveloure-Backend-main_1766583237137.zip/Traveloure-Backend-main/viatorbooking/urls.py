from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ViatorDestinationViewSet, TripAPIView,ViatorProductViewSet

router = DefaultRouter()
# router.register(r'destination',ViatorDestinationViewSet , basename='destination')

urlpatterns = [
    # path('', include(router.urls)),
    path('destination', ViatorDestinationViewSet.as_view(), name='destination'),
    path('place', ViatorProductViewSet.as_view(), name='place_destination'),

    path("search",TripAPIView.as_view(),name="viator_trip_view")
   
]
