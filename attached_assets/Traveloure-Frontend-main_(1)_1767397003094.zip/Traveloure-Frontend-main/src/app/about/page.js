import React from 'react'

function page() {
  return (
    <div>
      about us page
    </div>
  )
}

export default page
