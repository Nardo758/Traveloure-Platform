import requests
from django.core.management.base import BaseCommand
from viatorbooking.models import ViatorDestination
from django.conf import settings

class Command(BaseCommand):
    help = "Fetch Viator destinations from API and store them in the database."

    VIATOR_DESTINATION_API_URL = settings.VIATOR_DESTINATION_API_URL if hasattr(settings, 'VIATOR_DESTINATION_API_URL') else None
    API_KEY = settings.VIATOR_API_KEY if hasattr(settings, 'VIATOR_API_KEY') else None

    def handle(self, *args, **options):
        if not self.API_KEY or not self.VIATOR_DESTINATION_API_URL:
            self.stderr.write("VIATOR_API_KEY and VIATOR_DESTINATION_API_URL must be set in settings.")
            return
        headers = {
            "exp-api-key": self.API_KEY,
            "Accept": "application/json;version=2.0",
            "Accept-Language": "en-US",
        }

        self.stdout.write(self.style.NOTICE("Fetching destinations from Viator API..."))
        response = requests.get(self.VIATOR_DESTINATION_API_URL, headers=headers)

        if response.status_code != 200:
            self.stderr.write(
                self.style.ERROR(
                f"Failed to fetch data: {response.status_code} {response.text}"
            ))
            return

        data = response.json()
        destinations = data.get("destinations", [])

        self.stdout.write(
            self.style.SUCCESS(f"Retrieved {len(destinations)} destinations"))

        created, updated = 0, 0
        self.stdout.write(
            self.style.WARNING(
                f"Seeding Process Started. Please Wait for a while..."
            )
        )
        for item in destinations:
            center = item.get("center", {})

            obj, was_created = ViatorDestination.objects.update_or_create(
                destination_id=item.get("destinationId"),
                defaults={
                    "name": item.get("name"),
                    "type": item.get("type"),
                    "parent_destination_id": item.get("parentDestinationId"),
                    "lookup_id": item.get("lookupId"),
                    "destination_url": item.get("destinationUrl"),
                    "default_currency_code": item.get("defaultCurrencyCode"),
                    "time_zone": item.get("timeZone"),
                    "country_calling_code": item.get("countryCallingCode"),
                    "languages": item.get("languages", []),
                    "latitude": center.get("latitude"),
                    "longitude": center.get("longitude"),
                },
            )

            if was_created:
                created += 1
            else:
                updated += 1

        self.stdout.write(
            self.style.SUCCESS(
                f"Import complete: {created} created, {updated} updated."
            )
        )
