from rest_framework import status, generics, mixins
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from ai_itinerary.models import *
from ai_itinerary.serializers import *
import os
from dotenv import load_dotenv
from ai_itinerary.utils import *

load_dotenv()
SERP_API_KEY = os.getenv('SERP_API_KEY')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')



class TouristPreferenceListCreateAPIView(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = TouristPreferenceSerializer

    def get_queryset(self):
        return TouristPreferences.objects.filter(user=self.request.user)
    def list(self,request,*args,**kwargs):
        instances = self.get_queryset()
        serializer = TouristPreferenceSerializer(instances,many=True)
        return Response({'message':"Fetched Successfully","data":serializer.data,"status":True}, status=200)
    def create(self, request, *args, **kwargs):
        place_id = request.data.get('place_id')
        if not place_id:
            return Response({"error": "place_id is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            place = TouristPlaceResults.objects.get(id=place_id)
        except TouristPlaceResults.DoesNotExist:
            return Response({"error": "Tourist place not found","status":False}, status=status.HTTP_404_NOT_FOUND)

        pref, created = TouristPreferences.objects.get_or_create(
            user=request.user, preference=place
        )

        if not created:
            return Response({"message": "Already in preferences","status":True}, status=status.HTTP_200_OK)

        serializer = self.get_serializer(pref)
        return Response({"message":"Preference added Successfully","status":True}, status=status.HTTP_201_CREATED)


class TouristPreferenceDestroyAPIView(mixins.DestroyModelMixin,
                                      generics.GenericAPIView):
    permission_classes = [IsAuthenticated]
    queryset = TouristPreferences.objects.all()
    serializer_class = TouristPreferenceSerializer

    def delete(self, request, *args, **kwargs):
        place_id = request.data.get('place_id')
        if not place_id:
            return Response({"error": "place_id is required","status":False}, status=status.HTTP_400_BAD_REQUEST)
        try:
            pref = self.get_queryset().get(user=request.user, preference_id=place_id)
            pref.delete()
            return Response({"message": "Preference removed","status":True}, status=status.HTTP_200_OK)
        except TouristPreferences.DoesNotExist:
            return Response({"error": "Preference not found","status":False}, status=status.HTTP_404_NOT_FOUND)
        

class TouristPreferenceActivityListCreateAPIView(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = TouristPlaceActivitySerializer

    def get_queryset(self):
        return TouristHelpMeGuideActivities.objects.filter(user=self.request.user)
    
    def list(self,request,*args,**kwargs):
        instances = self.get_queryset()
        serializer = TouristPlaceActivitySerializer(instances,many=True)
        return Response({'message':"Fetched Successfully","data":serializer.data,"status":True}, status=200)
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)

        if serializer.is_valid():
            serializer.save(user=request.user)
            return Response({"message":"Acttivity Preference added Successfully","status":True}, status=status.HTTP_201_CREATED)


class TouristPreferenceActivityDestroyAPIView(mixins.DestroyModelMixin, generics.GenericAPIView):
    permission_classes = [IsAuthenticated]
    queryset = TouristHelpMeGuideActivities.objects.all()
    serializer_class = TouristPlaceActivitySerializer

    def delete(self, request, *args, **kwargs):
        activity_id = self.kwargs.get('activity_id')
        if not activity_id:
            return Response({"error": "Preference not found","status":False}, status=status.HTTP_404_NOT_FOUND)
        pref = self.get_queryset().get(user=request.user,id=activity_id)
        pref.delete()
        return Response({"message": "Activity Preference removed","status":True}, status=status.HTTP_200_OK)
    
class TouristPreferenceEventListCreateAPIView(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = TouristHelpMeGuideEventSerializer

    def get_queryset(self):
        return TouristHelpMeGuideEvents.objects.filter(user=self.request.user)
    
    def list(self,request,*args,**kwargs):
        instances = self.get_queryset()
        serializer = TouristHelpMeGuideEventSerializer(instances,many=True)
        return Response({'message':"Fetched Successfully","data":serializer.data,"status":True}, status=200)
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)

        if serializer.is_valid():
            serializer.save(user=request.user)
            return Response({"message":"Event Preference added Successfully","status":True}, status=status.HTTP_201_CREATED)


class TouristPreferenceEventDestroyAPIView(mixins.DestroyModelMixin, generics.GenericAPIView):
    permission_classes = [IsAuthenticated]
    queryset = TouristHelpMeGuideEvents.objects.all()
    serializer_class = TouristHelpMeGuideEventSerializer

    def delete(self, request, *args, **kwargs):
        event_id = self.kwargs.get('event_id')
        if not event_id:
            return Response({"error": "Event Preference not found","status":False}, status=status.HTTP_404_NOT_FOUND)
        pref = self.get_queryset().get(user=request.user,id=event_id)
        pref.delete()
        return Response({"message": "Event Preference removed","status":True}, status=status.HTTP_200_OK)
    
