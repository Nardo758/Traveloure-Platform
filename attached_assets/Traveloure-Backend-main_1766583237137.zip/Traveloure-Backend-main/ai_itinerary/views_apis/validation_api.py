from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny
from ai_itinerary.utils import validate_personal_information
from rest_framework import serializers
import re


class MessageValidationSerializer(serializers.Serializer):
    """Serializer for message validation request"""
    message = serializers.CharField(required=True, allow_blank=False)
    
    def validate_message(self, value):
        """Basic validation for message field"""
        if len(value.strip()) == 0:
            raise serializers.ValidationError("Message cannot be empty")
        if len(value) > 5000:  # Reasonable limit
            raise serializers.ValidationError("Message too long (max 5000 characters)")
        return value


class PersonalInfoValidationAPIView(APIView):
    """
    API endpoint to validate text messages for personal information.
    
    POST /api/ai-itinerary/validate-message/
    
    Request Body:
    {
        "message": "Your text message here"
    }
    
    Response:
    {
        "status": true/false,
        "reason": null or "description of why validation failed",
        "data": {
            "message": "original message",
            "is_safe": true/false,
            "detected_patterns": ["email", "phone"] // if any
        }
    }
    """
    
    permission_classes = [AllowAny]  # You can change this based on your auth requirements
    
    def post(self, request):
        """Validate message for personal information"""
        try:
            # Validate input using serializer
            serializer = MessageValidationSerializer(data=request.data)
            if not serializer.is_valid():
                return Response({
                    "status": False,
                    "reason": "Invalid input: " + str(serializer.errors),
                    "data": None
                }, status=status.HTTP_400_BAD_REQUEST)
            
            message = serializer.validated_data['message']
            
            # Perform personal information validation
            validation_result = validate_personal_information(message)
            
            # Determine detected patterns for detailed response
            detected_patterns = self._get_detected_patterns(message)
            
            if validation_result['is_valid']:
                # Message is safe
                return Response({
                    "status": True,
                    "reason": None,
                    "data": {
                        "message": message,
                        "is_safe": True,
                        "detected_patterns": []
                    }
                }, status=status.HTTP_200_OK)
            else:
                # Message contains personal information - single generic reason
                return Response({
                    "status": False,
                    "reason": "You cannot share personal information in messages. Please remove any contact details like email addresses, phone numbers, or other personal data before sending.",
                    "data": {
                        "message": message,
                        "is_safe": False,
                        "detected_patterns": detected_patterns,
                        "specific_error": validation_result['error']
                    }
                }, status=status.HTTP_200_OK)
                
        except Exception as e:
            return Response({
                "status": False,
                "reason": f"Internal server error: {str(e)}",
                "data": None
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def _get_detected_patterns(self, message):
        """
        Detect what types of personal information patterns were found
        """
        import re
        detected = []
        
        # Email patterns
        email_patterns = [
            r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            r'[a-zA-Z0-9._%+-]+\s*at\s*[a-zA-Z0-9.-]+\s*dot\s*[a-zA-Z]{2,}',
        ]
        
        # Phone patterns
        phone_patterns = [
            r'\b\d{10}\b',
            r'\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b',
            r'\+\d{1,3}[-.\s]?\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b',
            r'\(\d{3}\)[-.\s]?\d{3}[-.\s]?\d{4}\b',
            r'\b9\d{9}\b', r'\b8\d{9}\b', r'\b7\d{9}\b', r'\b6\d{9}\b',
        ]
        
        # Credit card patterns
        credit_card_patterns = [
            r'\b\d{4}[-.\s]?\d{4}[-.\s]?\d{4}[-.\s]?\d{4}\b',
            r'\b\d{16}\b',
        ]
        
        # SSN patterns
        ssn_patterns = [
            r'\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b',
        ]
        
        # Aadhaar patterns
        aadhaar_patterns = [
            r'\b\d{4}[-.\s]?\d{4}[-.\s]?\d{4}\b',
            r'\b\d{12}\b',
        ]
        
        # PAN patterns
        pan_patterns = [
            r'\b[A-Z]{5}\d{4}[A-Z]\b',
        ]
        
        # Check each pattern type
        for pattern in email_patterns:
            if re.search(pattern, message, re.IGNORECASE):
                detected.append("email")
                break
                
        for pattern in phone_patterns:
            if re.search(pattern, message):
                detected.append("phone")
                break
                
        # Check written phone patterns
        written_phone_patterns = [
            r'\b(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)[\s\-]*(zero|one|two|three|four|five|six|seven|eight|nine)',
        ]
        
        for pattern in written_phone_patterns:
            if re.search(pattern, message.lower()):
                detected.append("phone")
                break
                
        for pattern in credit_card_patterns:
            if re.search(pattern, message):
                detected.append("credit_card")
                break
                
        for pattern in ssn_patterns:
            if re.search(pattern, message):
                detected.append("ssn")
                break
                
        for pattern in aadhaar_patterns:
            if re.search(pattern, message):
                digits_only = re.sub(r'[-.\s]', '', re.search(pattern, message).group())
                if len(digits_only) == 12:
                    detected.append("aadhaar")
                    break
                    
        for pattern in pan_patterns:
            if re.search(pattern, message, re.IGNORECASE):
                detected.append("pan")
                break
        
        return detected



