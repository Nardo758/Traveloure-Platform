from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.views import APIView
from django.conf import settings
from .models import *
from .serializers import *
import os
from dotenv import load_dotenv
from subscription.wallet_utils import check_wallet_balance
import json
from .utils import *
from collections import Counter
import random
from .tourist_places import fetch_travel_data_agentic
from openai import OpenAI
from .utils import fetch_live_events,fetch_images_via_serp_api
from datetime import datetime
import demjson3
from subscription.views import track_api_usage
import logging

logger = logging.getLogger(__name__)

load_dotenv()
SERP_API_KEY = os.getenv('SERP_API_KEY')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')

class DiscoverPlacesAPIView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        query = request.GET.get("search", "").strip()
        location = query.title() if query else None
        places = None
        search_obj = None
        events = []
        gpt_error = None

        if query:
            search_obj = TouristPlacesSearches.objects.filter(search__iexact=query).first()

            if search_obj:
                places = TouristPlaceResults.objects.filter(search=search_obj)
            else:
                data_list = fetch_travel_data_agentic(f"Top Tourist Attraction Places to visit in {query}?")

                if not data_list or "places" not in data_list or not data_list["places"]:
                    gpt_error = data_list.get("error") if data_list else "No response from OpenAI"
                else:
                    search_obj = TouristPlacesSearches.objects.create(search=query)

                    for item in data_list["places"]:
                        try:
                            country = item.get("country", "").strip()
                            city = item.get("city", "").strip()
                            place_name = item.get("place", "").strip()

                            search_query = f"beautiful and attractive images of {place_name} in {country}"
                            images = fetch_images_via_serp_api(search_query, SERP_API_KEY)
                            

                            if not TouristPlaceResults.objects.filter(
                                country__iexact=country,
                                city__iexact=city,
                                place__iexact=place_name
                            ).exists():
                                TouristPlaceResults.objects.create(
                                    search=search_obj,
                                    country=country,
                                    city=city,
                                    place=place_name,
                                    description=item.get("description", ""),
                                    activities=item.get("activities", []),
                                    festivals=item.get("festivals", []),
                                    latitude=item.get("latitude"),
                                    longitude=item.get("longitude"),
                                    category=item.get("category", ""),
                                    best_months=item.get("best_months", ""),
                                    image_url=images
                                )
                        except Exception as e:
                            logger.error(f"Error saving place: {e} - {item}")

                    places = TouristPlaceResults.objects.filter(search=search_obj)

            try:
                events_data = fetch_live_events(query, datetime.now().year, SERP_API_KEY)
                events = [
                    {
                        "title": event.get("title", ""),
                        "start_date": event.get("date", {}).get("start_date", ""),
                        "address": event.get("address", ""),
                        "link": event.get("link", ""),
                        "image_url": event.get("thumbnail", ""),
                        "venue": event.get("venue", ""),
                        "ticket_info": event.get("ticket_info", "")
                    }
                    for event in events_data
                ]
            except Exception as e:
                events = []

        else:
            all_searches = TouristPlacesSearches.objects.all()
            if not all_searches.exists():
                return Response({"error": "No cached searches found."}, status=status.HTTP_404_NOT_FOUND)

            # Get all searches that have places with data
            searches_with_data = []
            for search in all_searches:
                places = TouristPlaceResults.objects.filter(search=search)
                if places.exists():
                    searches_with_data.append(search)
            
            if not searches_with_data:
                return Response({"error": "No places with data found."}, status=status.HTTP_404_NOT_FOUND)

            search_obj = random.choice(searches_with_data)
            location = search_obj.search
            places = TouristPlaceResults.objects.filter(search=search_obj)
            events = []

        if not places or not places.exists():
            # Build response without empty arrays
            response_data = {
                "location": location,
                "gpt_error": gpt_error,
                "error": "No places found."
            }
            
            # Only include live_events if it has data
            if events:
                response_data["live_events"] = events
                
            return Response(response_data, status=status.HTTP_404_NOT_FOUND)

        categories = TouristPlaceCategory.objects.all().values_list('name', flat=True)

        activity_counter = Counter()
        for place in places:
            if isinstance(place.activities, list):
                activity_counter.update(place.activities)

        popular_activities = [
            {"name": name, "count": count}
            for name, count in activity_counter.most_common()
        ]

        # Filter places that have meaningful data in must_go_places
        must_go_places = []
        for p in places:
            # Check if place has meaningful data (not empty/null)
            if (p.place and p.place.strip() and 
                p.city and p.city.strip() and 
                p.description and p.description.strip()):
                
                must_go_places.append({
                    "id": p.id,
                    "place": p.place,
                    "city": p.city,
                    "category": p.category,
                    "image_url": p.image_url,
                    "description": p.description,
                    "latitude": p.latitude,
                    "longitude": p.longitude,
                })

        # If no meaningful must_go_places found, return error
        if not must_go_places:
            response_data = {
                "location": location,
                "gpt_error": gpt_error,
                "error": "No places found."
            }
            
            # Only include live_events if it has data
            if events:
                response_data["live_events"] = events
                
            return Response(response_data, status=status.HTTP_404_NOT_FOUND)

        # Build response with conditional fields
        response_data = {
            "location": location,
            "gpt_error": gpt_error
        }
        
        # Only include categories if they exist
        if categories:
            response_data["categories"] = list(categories)
            
        # Only include popular_activities if they exist
        if popular_activities:
            response_data["popular_activities"] = popular_activities
            
        # Include must_go_places (we already filtered for meaningful data)
        response_data["must_go_places"] = must_go_places
            
        # Only include live_events if they exist
        if events:
            response_data["live_events"] = events

        return Response(response_data)
   
class CategoryListAPIView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request, *args, **kwargs):
        categories = TouristPlaceCategory.objects.all().order_by('name')
        category_list = [
            {
                "id": category.id,
                "name": category.name,
                "created_at": category.created_at,
                "updated_at": category.updated_at
            }
            for category in categories
        ]
        
        return Response({
            "categories": category_list,
            "count": len(category_list)
        })

class TripSubmitView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        # Check wallet balance first
        user = request.user
        
        has_credits, message, current_credits, current_balance = check_wallet_balance(user, 0.50)
        if not has_credits:
            return Response({
                "error": message,
                "remaining_credits": current_credits,
                "remaining_balance": current_balance,
                "required_credits": 1,
                "api_name": "generate_explore"
            }, status=402)
        
        # Deduct from wallet
        
        success, message, remaining_credits, remaining_balance = track_api_usage(user, "generate_explore", 0.50)
        if not success:
            return Response({
                "error": message,
                "remaining_credits": remaining_credits,
                "remaining_balance": remaining_balance,
                "required_credits": 1,
                "api_name": "generate_explore"
            }, status=402)
        trip_id = request.data.get('trip_id')
        places = request.data.get('places', [])
        hotels = request.data.get('hotels', [])
        services = request.data.get('services', [])
        other_services = request.data.get('other_services', [])
        flights = request.data.get('flights', [])  # Add flights
        notes = request.data.get('notes',[])
        
        # Get affiliate data if provided
        affiliate_hotels = request.data.get('hotels', [])  # This will be affiliate data
        affiliate_cars = request.data.get('cars', [])      # This will be affiliate data
        affiliate_flights = request.data.get('flights', []) # This will be affiliate data

        if not trip_id:
            return Response({'error': 'Missing trip_id'}, status=400)

        try:
            # Only fetch the trip, no related model queries
            trip = Trip.objects.get(id=trip_id)
            
            # If user is authenticated and trip doesn't have a user, associate it
            if request.user.is_authenticated and not trip.user:
                trip.user = request.user
                trip.save()


            for place in places:
                TripSelectedPlace.objects.create(
                    trip=trip,
                    place_id=place.get('place_id', ''),
                    name=place.get('name', ''),
                    description=place.get('description', ''),
                    address=place.get('address', ''),
                    rating=place.get('rating', None),
                    image_url=place.get('image_url', ''),
                    website_url=place.get('website_url', ''),
                    metadata=place.get('metadata', {})
                )

            for hotel in hotels:
                TripSelectedHotel.objects.create(
                    trip=trip,
                    hotel_id=hotel.get('hotel_id', ''),
                    name=hotel.get('name', ''),
                    description=hotel.get('description', ''),
                    address=hotel.get('address', ''),
                    rating=hotel.get('rating', None),
                    price_range=hotel.get('price_range', ''),
                    image_url=hotel.get('image_url', ''),
                    website_url=hotel.get('website_url', ''),
                    metadata=hotel.get('metadata', {})
                )

            for service in services:
                TripSelectedService.objects.create(
                    trip=trip,
                    service_id=service.get('service_id', ''),
                    name=service.get('name', ''),
                    description=service.get('description', ''),
                    service_type=service.get('service_type', ''),
                    price_range=service.get('price_range', ''),
                    image_url=service.get('image_url', ''),
                    website_url=service.get('website_url', ''),
                    metadata=service.get('metadata', {})
                )
            if other_services:
                for service in other_services:

                    TripOtherService.objects.create(
                        trip=trip,
                        other_service=service
                    )

            for flight in flights:
                TripSelectedFlight.objects.create(
                    trip=trip,
                    flight_id=flight.get('flight_id', ''),
                    name=flight.get('name', ''),
                    description=flight.get('description', ''),
                    origin=flight.get('origin', ''),
                    destination=flight.get('destination', ''),
                    departure_date=flight.get('departure_date'),
                    return_date=flight.get('return_date'),
                    price_range=flight.get('price_range', ''),
                    image_url=flight.get('image_url', ''),
                    website_url=flight.get('website_url', ''),
                    metadata=flight.get('metadata', {})
                )
            # --- End save logic ---

            # Clean up service metadata (in-memory only)
            for service in services:
                if isinstance(service.get('metadata'), str):
                    try:
                        service['metadata'] = json.loads(service['metadata'])
                    except:
                        service['metadata'] = {}

            duration = (trip.end_date - trip.start_date).days + 1

            # Use in-memory provided data
            trip_data_for_prompt = self._build_trip_data(trip, places, hotels, services,other_services)

            prompt = self._build_prompt(trip, duration, trip_data_for_prompt,notes)

            client = OpenAI(api_key=settings.OPENAI_API_KEY)
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a travel itinerary expert."},
                    {"role": "user", "content": prompt}
                ]
            )

            raw_response = response.choices[0].message.content

            # Extract JSON from markdown-style block or fallback
            match = re.search(r"```json(.*?)```", raw_response, re.DOTALL)
            json_str = match.group(1).strip() if match else raw_response.strip()
            try:
                itinerary = demjson3.decode(json_str)
            except demjson3.JSONDecodeError as e:
                return Response({'error': f'Invalid itinerary JSON: {str(e)}'}, status=500)


            # Enrich with in-memory data
            self._enrich_metadata(itinerary, places, hotels, services)

            itinerary_obj, created = GeneratedItinerary.objects.update_or_create(
                trip=trip,
                defaults={'itinerary_data': itinerary, 'status': 'completed'}
            )
            trip.status = 'confirmed'
            trip.save()

            # Prepare response with affiliate data
            response_data = {
                'message': 'Trip created and itinerary generated',
                'trip_id': str(trip.id),
                'itinerary_id': str(itinerary_obj.id),
                'itinerary': itinerary,
                'wallet_info': {
                    'api_used': 'generate_explore',
                    'credits_deducted': 1,
                    'remaining_credits': remaining_credits,
                    'remaining_balance': remaining_balance,
                    'cost_deducted': 0.50  # Keep for backward compatibility
                }
            }
            
            # Add affiliate data if provided
            if affiliate_hotels:
                response_data['hotels'] = affiliate_hotels
            if affiliate_cars:
                response_data['cars'] = affiliate_cars
            if affiliate_flights:
                response_data['flights'] = affiliate_flights
                
            return Response(response_data)

        except Exception as e:
            return Response({'error': str(e)}, status=500)
        
    def _save_service(self, data, trip):
        try:
            defaults = {
                'service_id': f"service_{random.randint(10000, 99999)}",
                'name': "Unnamed Service",
                'service_type': "other",
                'description': "",
                'price_range': "",
                'image_url': "",
                'website_url': "",
                'notes': "",
                'metadata': {},
                'trip': trip.id
            }
            for key, val in defaults.items():
                if not data.get(key):
                    data[key] = val

            if isinstance(data['metadata'], str):
                try:
                    data['metadata'] = json.loads(data['metadata'])
                except json.JSONDecodeError:
                    data['metadata'] = {}

            serializer = SelectedServiceSerializer(data=data)
            if serializer.is_valid():
                serializer.save(trip=trip)
        except Exception as e:
            logger.error(f"Exception saving service: {str(e)}")

    def _build_trip_data(self, trip, places, hotels, services,other_services):
        data = {
            'destination': trip.destination,
            'start_date': trip.start_date.strftime('%Y-%m-%d'),
            'end_date': trip.end_date.strftime('%Y-%m-%d'),
            'preferences': getattr(trip, 'preferences', []),
            'places': [
                {
                    'name': p.get('name', ''),
                    'description': p.get('description', ''),
                    'address': p.get('address', ''),
                    'rating': p.get('rating', 0),
                    'visit_date': p.get('visit_date'),
                    'visit_time': p.get('visit_time'),
                    'metadata': p.get('metadata', {})
                } for p in places
            ],
            'hotels': [
                {
                    'name': h.get('name', ''),
                    'address': h.get('address', ''),
                    'check_in_date': h.get('check_in_date'),
                    'check_out_date': h.get('check_out_date'),
                    'check_in_time': h.get('metadata', {}).get('check_in_time', ''),
                    'check_out_time': h.get('metadata', {}).get('check_out_time', ''),
                    'metadata': h.get('metadata', {})
                } for h in hotels
            ],
            'services': [
                {
                    'name': s.get('name', ''),
                    'type': s.get('service_type', ''),
                    'service_date': s.get('service_date'),
                    'service_time': s.get('service_time'),
                    'metadata': s.get('metadata', {})
                } for s in services
            ],
            'other_services': other_services
        }
        return data

    def _build_prompt(self, trip, duration, trip_data,notes):
        return f"""
Expert planner for {trip.destination}. Build a {duration}-day itinerary (Maximum for a week) from:
{json.dumps(trip_data, indent=2)}
User notes: {notes}
Return ONLY a JSON block like:

**Respond ONLY with JSON in this format:**

```json
{{
  "title": "Detailed {duration}-Day Itinerary for {trip.destination}",
  "description": "Comprehensive travel plan including selected and recommended activities",
  "city": "{trip.destination.split(',')[0].strip()}",
  "state": "State if available",
  "country": "Country if available",
  "price": "Total budget with profit",
  "highlights": "Key attractions and experiences",
  "inclusive": [
    "All selected hotel accommodations",
    "All selected transport services",
    "Entry tickets to selected attractions",
    "Professional guide services where specified",
    "24/7 trip support",
    "Daily breakfast at hotels",
    "All taxes and service charges"
  ],
  "exclusive": [
    "International flights",
    "Travel insurance",
    "Personal expenses",
    "Meals not specified",
    "Optional activities",
    "Tips and gratuities"
  ],
  "start_point": "Starting location",
  "end_point": "Ending location",
  "start_date": "{trip.start_date.strftime('%Y-%m-%d')}",
  "end_date": "{trip.end_date.strftime('%Y-%m-%d')}",
  "preferences": {json.dumps(trip.preferences)},
  "itinerary": [
    {{
      "day_number": 1,
      "title": "Day title",
      "description": "Day description",
      "activities": [
        {{
          "time": "HH:MM",
          "activity": "Description",
          "location": "Place name",
          "duration": "X hours",
          "notes": "e.g. travel time, tips, potential issues",
          "type": "place/hotel/service/suggestion",
          "metadata": {{
            "booking_required": true,
            "estimated_cost": "X USD",
            "transport_mode": "walk/car/public transport",
            "transport_service": "service name if applicable",
            "image_url": "URL from selected place/hotel/service",
            "website_url": "URL from selected place/hotel/service",
            "rating": "Rating if available",
            "address": "Full address",
            "phone": "Contact number if available"
          }}
        }}
      ]
    }}
  ],
  "summary": {{
    "total_places": X,
    "total_hotels": X,
    "total_services": X,
    "hotel_coverage": "Fully covered / Missing nights / Overbooked",
    "service_coverage": "All services assigned / Unused / Missing slots",
    "recommendations": [
      "Add another hotel for night 2",
      "Swap Day 3 activities due to weather",
      "Too many places on Day 4 – consider splitting",
      "Additional activities suggestions based on preferences"
    ],
    "weather_impact": "How the weather affected the plan",
    "transport_plan": "Summary of transport services usage",
    "budget_breakdown": {{
      "total_cost": "X USD",
      "hotel_costs": "X USD",
      "transport_costs": "X USD",
      "activity_costs": "X USD",
      "meal_costs": "X USD",
      "trip_planner_profit": "X USD (15% of total cost)",
      "total_with_profit": "X USD"
    }},
    "important_notes": [
      "Booking requirements for specific attractions",
      "Weather-related recommendations",
      "Local customs and etiquette",
      "Emergency contact information"
    ]
  }}
}}"""

    def _enrich_metadata(self, itinerary, places, hotels, services):
        for day in itinerary.get('itinerary', []):
            for act in day.get('activities', []):
                obj = None
    
                if act['type'] == 'place':
                    obj = next((p for p in places if p.get('name') == act['location']), None)
                elif act['type'] == 'hotel':
                    obj = next((h for h in hotels if h.get('name') == act['location']), None)
                elif act['type'] == 'service':
                    obj = next((s for s in services if s.get('name') == act['location']), None)
    
                if obj:
                    metadata = obj.get('metadata', {}) if isinstance(obj, dict) else getattr(obj, 'metadata', {})
                    act['metadata'].update({
                        'image_url': obj.get('image_url', '') if isinstance(obj, dict) else getattr(obj, 'image_url',   ''),
                        'website_url': obj.get('website_url', '') if isinstance(obj, dict) else getattr(obj,    'website_url', ''),
                        'rating': obj.get('rating', '') if isinstance(obj, dict) else getattr(obj, 'rating', ''),
                        'address': obj.get('address', '') if isinstance(obj, dict) else getattr(obj, 'address', ''),
                        'phone': metadata.get('phone', '') if isinstance(metadata, dict) else ''
                    })