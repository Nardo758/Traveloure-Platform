from rest_framework import status, generics, mixins, viewsets
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.views import APIView
from django.conf import settings
from ai_itinerary.models import *
from ai_itinerary.serializers import *
import requests
import os
from dotenv import load_dotenv
import json
from django.shortcuts import get_object_or_404
from ai_itinerary.utils import *


class ReviewCreateAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        data = request.data.copy()
        serializer = ReviewRatingSerializer(data=data, context={'request': request})

        if serializer.is_valid():
            local_expert = serializer.validated_data['local_expert']
            reviewer = request.user

            if ReviewRating.objects.filter(local_expert=local_expert, reviewer=reviewer).exists():
                return Response(
                    {"detail": "You have already reviewed this expert."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            serializer.save(reviewer=reviewer)
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class PublicExpertReviewListAPIView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, expert_id):
        try:
            expert = User.objects.get(id=expert_id, is_local_expert=True)
        except User.DoesNotExist:
            return Response({'detail': 'Local expert not found.'}, status=status.HTTP_404_NOT_FOUND)

        reviews = ReviewRating.objects.filter(local_expert=expert)
        serializer = ReviewRatingSerializer(reviews, many=True)
        return Response(serializer.data)
    
class MyWrittenReviewsAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        reviews = ReviewRating.objects.filter(reviewer=user)
        serializer = ReviewRatingSerializer(reviews, many=True)
        return Response(serializer.data)