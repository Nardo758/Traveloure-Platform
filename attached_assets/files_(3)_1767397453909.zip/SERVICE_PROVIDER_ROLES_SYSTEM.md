# TRAVELOURE SERVICE PROVIDER ROLES - COMPLETE SYSTEM
## Expanded Marketplace with Flexible Role Categories

**Version**: 9.0 - Multi-Role Service Provider System  
**Last Updated**: January 2, 2026  
**Purpose**: Define service provider categories, role management, and marketplace expansion

---

## TABLE OF CONTENTS

### PART I: SYSTEM ARCHITECTURE
1. [Service Provider vs Local Expert](#service-provider-vs-local-expert)
2. [Role Category System](#role-category-system)
3. [Multi-Role Support](#multi-role-support)
4. [Dynamic Role Creation](#dynamic-role-creation)

### PART II: SERVICE PROVIDER CATEGORIES
5. [Core Service Provider Roles](#core-service-provider-roles)
6. [Services by Category](#services-by-category)
7. [Role-Specific Requirements](#role-specific-requirements)

### PART III: IMPLEMENTATION
8. [Admin Role Management](#admin-role-management)
9. [Provider Registration Flow](#provider-registration-flow)
10. [Traveler Discovery Experience](#traveler-discovery-experience)
11. [Integration with Existing Systems](#integration-with-existing-systems)

---

## SERVICE PROVIDER VS LOCAL EXPERT

### Understanding the Distinction

```
┌─────────────────────────────────────────────────────────────────┐
│ LOCAL EXPERT                                                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ Role: Knowledge & Planning Provider                             │
│                                                                 │
│ What they do:                                                   │
│ • Trip planning & itinerary creation                            │
│ • Consultation & advice                                         │
│ • Cart reviews & optimization                                   │
│ • Cultural interpretation                                       │
│ • Insider recommendations                                       │
│                                                                 │
│ Deliverable: Knowledge, Plans, Guidance                         │
│ Location: Can be remote or local                                │
│ Example: Maria who plans Paris trips                            │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ SERVICE PROVIDER                                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ Role: Service Execution & Delivery                              │
│                                                                 │
│ What they do:                                                   │
│ • Perform specific services                                     │
│ • Execute tasks                                                 │
│ • Provide physical/in-person services                           │
│ • Deliver tangible results                                      │
│                                                                 │
│ Deliverable: Physical Service, Completed Task                   │
│ Location: Must be local to destination                          │
│ Example: Pierre who does photoshoots in Paris                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ HYBRID (Can be both)                                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ • Travel guide who both plans AND leads tours                   │
│ • Photographer who also consults on photo locations             │
│ • Chef who plans food tours AND teaches cooking classes         │
│                                                                 │
│ System allows: One person, multiple roles                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## ROLE CATEGORY SYSTEM

### Database Schema

```javascript
// Service Provider Role Categories
{
  id: UUID,
  name: "Photographer",
  slug: "photographer",
  description: "Professional photography services",
  icon: "📸",
  category_type: "service_provider", // or "local_expert" or "hybrid"
  is_active: true,
  created_by: "admin" | "system",
  verification_required: true,
  required_documents: ["portfolio", "insurance"],
  custom_fields: {
    // Category-specific profile fields
    equipment: "text",
    photography_styles: "multi-select",
    years_experience: "number"
  },
  service_templates: [
    // Pre-defined service templates for this role
  ],
  created_at: timestamp,
  updated_at: timestamp
}

// Provider to Role Mapping (Many-to-Many)
{
  provider_id: UUID,
  role_category_id: UUID,
  verification_status: "pending" | "approved" | "rejected",
  verification_documents: [],
  is_primary_role: boolean,
  approved_at: timestamp,
  approved_by: admin_id
}
```

---

## CORE SERVICE PROVIDER ROLES

### Pre-Defined Categories

```
┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 1: PHOTOGRAPHY & VIDEOGRAPHY                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 📸 PHOTOGRAPHER                                                 │
│ • Portrait photography                                          │
│ • Event photography                                             │
│ • Engagement/proposal shoots                                    │
│ • Family vacation photos                                        │
│ • Solo traveler shoots                                          │
│ • Architectural/landmark photography                            │
│                                                                 │
│ Verification: Portfolio, insurance, equipment list              │
│ Typical pricing: $150-500 per session                           │
│                                                                 │
│ 🎬 VIDEOGRAPHER                                                 │
│ • Travel video packages                                         │
│ • Event videography                                             │
│ • Drone footage                                                 │
│ • Documentary-style travel films                                │
│ • Social media content creation                                 │
│                                                                 │
│ Verification: Portfolio reel, drone license (if applicable)    │
│ Typical pricing: $300-1000 per day                              │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 2: TRANSPORTATION & LOGISTICS                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 🚗 PRIVATE DRIVER                                               │
│ • Airport transfers                                             │
│ • Day trip transportation                                       │
│ • Multi-day chauffeur service                                   │
│ • City tours by car                                             │
│                                                                 │
│ Verification: Driver's license, insurance, vehicle registration │
│ Typical pricing: $50-150 per hour, $400-800 per day            │
│                                                                 │
│ 🚙 CAR RENTAL WITH DRIVER                                       │
│ • Self-drive rentals                                            │
│ • Luxury vehicle rentals                                        │
│ • Van/group transportation                                      │
│                                                                 │
│ 🚁 SPECIALTY TRANSPORT                                          │
│ • Helicopter tours                                              │
│ • Boat charters                                                 │
│ • Bicycle tours                                                 │
│ • Motorcycle rentals                                            │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 3: FOOD & CULINARY                                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 👨‍🍳 PRIVATE CHEF                                                │
│ • In-villa/apartment cooking                                    │
│ • Private dinner parties                                        │
│ • Cooking lessons                                               │
│ • Meal prep for week-long stays                                 │
│ • Special dietary accommodations                                │
│                                                                 │
│ Verification: Culinary credentials, food handler's license      │
│ Typical pricing: $200-600 per meal/session                      │
│                                                                 │
│ 🍷 SOMMELIER / WINE GUIDE                                       │
│ • Wine tasting tours                                            │
│ • Wine education sessions                                       │
│ • Wine pairing dinners                                          │
│ • Vineyard access & tours                                       │
│                                                                 │
│ 🍜 FOOD TOUR GUIDE                                              │
│ • Street food tours                                             │
│ • Market tours                                                  │
│ • Restaurant crawls                                             │
│ • Culinary neighborhood exploration                             │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 4: CHILDCARE & FAMILY                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 👶 BABYSITTER / NANNY                                           │
│ • Hourly babysitting                                            │
│ • Overnight care                                                │
│ • Multi-day nanny service                                       │
│ • Newborn care specialists                                      │
│                                                                 │
│ Verification: Background check, CPR certified, references       │
│ Typical pricing: $20-50 per hour                                │
│                                                                 │
│ 🎭 KIDS ACTIVITY COORDINATOR                                    │
│ • Kid-friendly tours                                            │
│ • Children's entertainment                                      │
│ • Educational activities                                        │
│ • Teen group activities                                         │
│                                                                 │
│ 👨‍👩‍👧‍👦 FAMILY ASSISTANT                                              │
│ • Family logistics coordination                                 │
│ • Kid transportation                                            │
│ • Activity booking & coordination                               │
│ • Emergency childcare backup                                    │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 5: TOURS & EXPERIENCES                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 🎯 TOUR GUIDE                                                   │
│ • Walking tours                                                 │
│ • Museum/gallery tours                                          │
│ • Historical site tours                                         │
│ • Neighborhood exploration                                      │
│ • Multi-day guided trips                                        │
│                                                                 │
│ Verification: Tour guide license, insurance                     │
│ Typical pricing: $100-300 per tour                              │
│                                                                 │
│ 🏃 ADVENTURE GUIDE                                              │
│ • Hiking guides                                                 │
│ • Climbing instructors                                          │
│ • Water sports guides                                           │
│ • Extreme sports coordination                                   │
│                                                                 │
│ 🎨 CULTURAL EXPERIENCE HOST                                     │
│ • Art workshops                                                 │
│ • Craft classes                                                 │
│ • Cultural ceremonies                                           │
│ • Traditional experiences                                       │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 6: PERSONAL ASSISTANCE                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 🤝 TRAVEL COMPANION                                             │
│ • Solo traveler companion                                       │
│ • Elderly travel assistance                                     │
│ • Accessibility companion                                       │
│ • Language assistance                                           │
│ • Safety companion                                              │
│                                                                 │
│ Verification: Background check, references, first aid certified │
│ Typical pricing: $100-300 per day                               │
│                                                                 │
│ 🏨 PERSONAL CONCIERGE                                           │
│ • Restaurant reservations                                       │
│ • Event ticket procurement                                      │
│ • Personal shopping                                             │
│ • Errand running                                                │
│ • General assistance                                            │
│                                                                 │
│ 💼 EXECUTIVE ASSISTANT                                          │
│ • Business travel support                                       │
│ • Meeting coordination                                          │
│ • Professional services                                         │
│ • Corporate event assistance                                    │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 7: TASKRABBIT-STYLE SERVICES                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 🔧 HANDYMAN / FIXER                                             │
│ • Vacation rental repairs                                       │
│ • Setup assistance (wifi, TV, etc.)                            │
│ • Assembly services                                             │
│ • Minor fixes                                                   │
│                                                                 │
│ 📦 DELIVERY & PICKUP                                            │
│ • Grocery delivery                                              │
│ • Restaurant takeout pickup                                     │
│ • Shopping delivery                                             │
│ • Package receiving                                             │
│                                                                 │
│ 🧹 CLEANING SERVICE                                             │
│ • Vacation rental cleaning                                      │
│ • Laundry service                                               │
│ • Deep cleaning                                                 │
│ • Organization services                                         │
│                                                                 │
│ 🔑 PROPERTY MANAGEMENT                                          │
│ • Check-in coordination                                         │
│ • Key exchange                                                  │
│ • Property walkthrough                                          │
│ • Issue resolution                                              │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 8: HEALTH & WELLNESS                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 🧘 FITNESS INSTRUCTOR                                           │
│ • Personal training sessions                                    │
│ • Yoga classes                                                  │
│ • Running/cycling guides                                        │
│ • Beach workouts                                                │
│                                                                 │
│ 💆 MASSAGE THERAPIST                                            │
│ • In-room massages                                              │
│ • Couples massages                                              │
│ • Sports massage                                                │
│ • Wellness treatments                                           │
│                                                                 │
│ Verification: License, insurance, certifications                │
│                                                                 │
│ 🏥 MEDICAL ASSISTANT                                            │
│ • Medical appointment coordination                              │
│ • Prescription assistance                                       │
│ • Medical translation                                           │
│ • Health tourism support                                        │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 9: BEAUTY & STYLING                                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 💇 HAIR & MAKEUP                                                │
│ • Wedding hair & makeup                                         │
│ • Photoshoot styling                                            │
│ • Event preparation                                             │
│ • Beauty tutorials                                              │
│                                                                 │
│ 👗 PERSONAL STYLIST                                             │
│ • Shopping assistance                                           │
│ • Outfit coordination                                           │
│ • Wardrobe consulting                                           │
│ • Local fashion guidance                                        │
│                                                                 │
│ Verification: Portfolio, certifications                         │
│ Typical pricing: $100-400 per session                           │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 10: PETS & ANIMALS                                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 🐕 PET SITTER                                                   │
│ • Dog walking                                                   │
│ • Pet sitting (home or theirs)                                 │
│ • Overnight pet care                                            │
│ • Pet transportation                                            │
│                                                                 │
│ 🐴 ANIMAL EXPERIENCE GUIDE                                      │
│ • Horseback riding tours                                        │
│ • Wildlife tours                                                │
│ • Farm visits                                                   │
│ • Ethical animal encounters                                     │
│                                                                 │
│ Verification: Experience, references, insurance                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 11: EVENTS & CELEBRATIONS                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 🎉 EVENT COORDINATOR                                            │
│ • Birthday party planning                                       │
│ • Anniversary coordination                                      │
│ • Proposal setup                                                │
│ • Corporate events                                              │
│                                                                 │
│ 💐 FLORIST                                                      │
│ • Bouquet delivery                                              │
│ • Event flowers                                                 │
│ • Special occasion arrangements                                 │
│                                                                 │
│ 🎂 BAKER / PASTRY CHEF                                          │
│ • Custom cakes                                                  │
│ • Dessert catering                                              │
│ • Baking classes                                                │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 12: TECHNOLOGY & CONNECTIVITY                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 💻 TECH SUPPORT                                                 │
│ • Device setup                                                  │
│ • WiFi troubleshooting                                          │
│ • Smart home assistance                                         │
│ • Tech rental (phones, tablets, wifi devices)                  │
│                                                                 │
│ 📱 SOCIAL MEDIA MANAGER                                         │
│ • Content creation                                              │
│ • Photo/video editing                                           │
│ • Story management                                              │
│ • Travel influencer support                                     │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 13: LANGUAGE & TRANSLATION                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 🗣️ TRANSLATOR / INTERPRETER                                    │
│ • Real-time translation                                         │
│ • Medical translation                                           │
│ • Business meeting interpretation                               │
│ • Document translation                                          │
│                                                                 │
│ 📚 LANGUAGE TUTOR                                               │
│ • Quick language lessons                                        │
│ • Conversation practice                                         │
│ • Cultural language immersion                                   │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 14: SPECIALTY SERVICES                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ 👰 WEDDING COORDINATOR                                          │
│ • Destination wedding planning                                  │
│ • Vendor coordination                                           │
│ • Day-of coordination                                           │
│ • Legal requirements assistance                                 │
│                                                                 │
│ 🎓 EDUCATION GUIDE                                              │
│ • Student travel coordination                                   │
│ • Study abroad assistance                                       │
│ • Educational tours                                             │
│                                                                 │
│ 🏠 RELOCATION SPECIALIST                                        │
│ • Apartment hunting                                             │
│ • Moving coordination                                           │
│ • Utility setup                                                 │
│ • Neighborhood orientation                                      │
│                                                                 │
│ ⚖️ LEGAL / VISA ASSISTANT                                      │
│ • Visa application help                                         │
│ • Document preparation                                          │
│ • Immigration guidance                                          │
│ • Legal translation                                             │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ CATEGORY 15: CUSTOM / OTHER                                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ ⭐ CUSTOM SERVICE PROVIDER                                      │
│ • Unique, one-of-a-kind services                                │
│ • Niche specializations                                         │
│ • Emerging service categories                                   │
│                                                                 │
│ Allows providers to define their own category                   │
│ Admin approval required                                         │
└─────────────────────────────────────────────────────────────────┘
```

---

## MULTI-ROLE SUPPORT

### Providers Can Have Multiple Roles

```
┌────────────────────────────────────────────────────────────────────┐
│ EXAMPLE: Pierre's Service Provider Profile                        │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ [Profile Photo] PIERRE DUBOIS                                      │
│                Paris, France                                       │
│                ⭐ 4.9 (243 reviews)                                 │
│                                                                    │
│ MY ROLES:                                                          │
│ • 📸 Photographer (Primary) ✓ Verified                            │
│ • 🎬 Videographer ✓ Verified                                      │
│ • 🗣️ Tour Guide ✓ Verified                                        │
│                                                                    │
│ SERVICES OFFERED:                                                  │
│                                                                    │
│ Photography Services:                                              │
│ • Portrait Sessions - $200                                         │
│ • Wedding Photography - $1,200                                     │
│ • Engagement Shoots - $300                                         │
│                                                                    │
│ Videography Services:                                              │
│ • Travel Video Package - $500                                      │
│ • Drone Footage - $300                                             │
│                                                                    │
│ Tour Guide Services:                                               │
│ • Photography Walking Tour - $150                                  │
│ • Best Photo Spots Tour - $120                                     │
│                                                                    │
│ [View All Services]  [Book Now]  [Chat]                           │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

**Benefits of Multi-Role:**
- More booking opportunities
- Cross-selling services
- Higher average order value
- Showcase full skill set
- Competitive advantage

---

## DYNAMIC ROLE CREATION

### Admin Can Add New Categories

```
┌────────────────────────────────────────────────────────────────────┐
│ ADMIN: CREATE SERVICE PROVIDER ROLE CATEGORY                      │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ Category Name: *                                                   │
│ [Sommelier                                                    ]   │
│                                                                    │
│ URL Slug: (auto-generated)                                         │
│ [sommelier                                                    ]   │
│                                                                    │
│ Icon/Emoji:                                                        │
│ [🍷] [Choose Icon]                                                 │
│                                                                    │
│ Category Type:                                                     │
│ ● Service Provider                                                 │
│ ○ Local Expert                                                     │
│ ○ Hybrid (can be both)                                            │
│                                                                    │
│ Short Description:                                                 │
│ [Wine experts offering tastings, tours, and education         ]   │
│                                                                    │
│ Detailed Description:                                              │
│ [                                                             ]   │
│ [                                                             ]   │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ VERIFICATION REQUIREMENTS                                          │
│                                                                    │
│ ☑ Verification required for this category                         │
│                                                                    │
│ Required Documents:                                                │
│ ☑ Portfolio / Work samples                                        │
│ ☑ Professional certification                                      │
│ ☑ Proof of insurance                                              │
│ ☐ Background check                                                │
│ ☐ License (specify): [_____________]                              │
│ ☑ Custom: [WSET Certification or equivalent]                     │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ CUSTOM PROFILE FIELDS                                              │
│                                                                    │
│ Add fields specific to this category:                              │
│                                                                    │
│ Field 1: [Wine Regions Specialized In    ] Type: [Multi-select ▼]│
│ Field 2: [Years of Experience             ] Type: [Number      ▼]│
│ Field 3: [Certifications                  ] Type: [Text        ▼]│
│                                                                    │
│ [+ Add Custom Field]                                               │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ SERVICE TEMPLATES                                                  │
│                                                                    │
│ Pre-define common services for this category:                     │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────┐   │
│ │ Template 1: Wine Tasting Experience                        │   │
│ │ Price Range: $50-150                                       │   │
│ │ Description: [Pre-filled template...]                      │   │
│ │ [Edit] [Remove]                                            │   │
│ └────────────────────────────────────────────────────────────┘   │
│                                                                    │
│ ┌────────────────────────────────────────────────────────────┐   │
│ │ Template 2: Vineyard Tour                                  │   │
│ │ Price Range: $100-300                                      │   │
│ │ Description: [Pre-filled template...]                      │   │
│ │ [Edit] [Remove]                                            │   │
│ └────────────────────────────────────────────────────────────┘   │
│                                                                    │
│ [+ Add Service Template]                                           │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ CATEGORY SETTINGS                                                  │
│                                                                    │
│ Display Order: [15] (higher = shows first in lists)               │
│                                                                    │
│ ☑ Active (visible to users)                                       │
│ ☐ Featured category (promoted on homepage)                        │
│ ☑ Allow multiple services per provider                            │
│ ☐ Limit to verified providers only                                │
│                                                                    │
│                         [Cancel]  [Create Category]               │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

---

## ADMIN ROLE MANAGEMENT

### Managing Service Provider Categories

```
┌────────────────────────────────────────────────────────────────────┐
│ ADMIN DASHBOARD - SERVICE PROVIDER CATEGORIES                      │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ [Create New Category]                                              │
│                                                                    │
│ Search: [________________] Filter: [All ▼] Sort: [Popular ▼]      │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ ACTIVE CATEGORIES (28)                                             │
│                                                                    │
│ ┌──────────────────────────────────────────────────────────────┐ │
│ │ 📸 PHOTOGRAPHER                                              │ │
│ │ Type: Service Provider • Created: 2025-01-15                 │ │
│ │                                                              │ │
│ │ Stats:                                                        │ │
│ │ • 847 verified providers                                      │ │
│ │ • 12,432 bookings this month                                  │ │
│ │ • $1.2M GMV                                                   │ │
│ │                                                              │ │
│ │ [Edit] [View Providers] [Service Templates] [Deactivate]    │ │
│ └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│ ┌──────────────────────────────────────────────────────────────┐ │
│ │ 🤝 TRAVEL COMPANION                                          │ │
│ │ Type: Service Provider • Created: 2025-12-01                 │ │
│ │                                                              │ │
│ │ Stats:                                                        │ │
│ │ • 143 verified providers                                      │ │
│ │ • 892 bookings this month                                     │ │
│ │ • $89K GMV                                                    │ │
│ │                                                              │ │
│ │ [Edit] [View Providers] [Service Templates] [Deactivate]    │ │
│ └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│ ┌──────────────────────────────────────────────────────────────┐ │
│ │ 👶 BABYSITTER                                                │ │
│ │ Type: Service Provider • Created: 2026-01-02                 │ │
│ │                                                              │ │
│ │ Stats:                                                        │ │
│ │ • 234 verified providers                                      │ │
│ │ • 1,543 bookings this month                                   │ │
│ │ • $77K GMV                                                    │ │
│ │ ⚠️ 12 pending verification requests                          │ │
│ │                                                              │ │
│ │ [Edit] [View Providers] [Service Templates] [Deactivate]    │ │
│ └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│ [Load More Categories...]                                          │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ PENDING CUSTOM CATEGORIES (3)                                      │
│                                                                    │
│ ┌──────────────────────────────────────────────────────────────┐ │
│ │ 🎸 MUSIC TEACHER                                             │ │
│ │ Requested by: User #8473 • Date: 2026-01-01                 │ │
│ │                                                              │ │
│ │ Reason: "I teach guitar/ukulele to travelers during their   │ │
│ │ stay in Hawaii. Many tourists want to learn."                │ │
│ │                                                              │ │
│ │ [Approve & Create Category] [Reject] [Request More Info]    │ │
│ └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

---

## PROVIDER REGISTRATION FLOW

### How Service Providers Join & Get Verified

```
┌────────────────────────────────────────────────────────────────────┐
│ BECOME A SERVICE PROVIDER                              Step 1 of 5 │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ WHAT SERVICES DO YOU PROVIDE?                                      │
│                                                                    │
│ Select all that apply (you can add more later):                    │
│                                                                    │
│ Photography & Video:                                               │
│ ☑ Photographer                                                     │
│ ☐ Videographer                                                     │
│                                                                    │
│ Transportation:                                                    │
│ ☐ Private Driver                                                   │
│ ☐ Car Rental with Driver                                          │
│                                                                    │
│ Food & Culinary:                                                   │
│ ☑ Private Chef                                                     │
│ ☐ Sommelier / Wine Guide                                          │
│ ☐ Food Tour Guide                                                  │
│                                                                    │
│ Childcare & Family:                                                │
│ ☐ Babysitter / Nanny                                              │
│ ☐ Kids Activity Coordinator                                       │
│                                                                    │
│ Personal Assistance:                                               │
│ ☐ Travel Companion                                                 │
│ ☐ Personal Concierge                                               │
│                                                                    │
│ [Show More Categories...]                                          │
│                                                                    │
│ Don't see your service?                                            │
│ [Request New Category]                                             │
│                                                                    │
│                                  [Cancel]  [Continue →]            │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

                    ↓ User selects Photographer & Private Chef

┌────────────────────────────────────────────────────────────────────┐
│ BECOME A SERVICE PROVIDER                              Step 2 of 5 │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ BASIC INFORMATION                                                  │
│                                                                    │
│ Business/Professional Name: *                                      │
│ [Pierre's Photography & Culinary Services                     ]   │
│                                                                    │
│ Primary Role: (What you do most)                                   │
│ ● Photographer                                                     │
│ ○ Private Chef                                                     │
│                                                                    │
│ Location: *                                                        │
│ [Paris, France                                                ]   │
│                                                                    │
│ Service Radius:                                                    │
│ [15] km from Paris city center                                     │
│ ☑ Willing to travel farther for premium booking                   │
│                                                                    │
│ Languages Spoken: *                                                │
│ ☑ French  ☑ English  ☐ Spanish  ☐ Other: [_______]               │
│                                                                    │
│ Bio / About You:                                                   │
│ [I'm a professional photographer and chef based in Paris...   ]   │
│ [                                                             ]   │
│ [                                                             ]   │
│                                                                    │
│ Profile Photo: *                                                   │
│ [Upload Photo] Recommended: Professional headshot                  │
│                                                                    │
│                         [← Back]  [Cancel]  [Continue →]          │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

                    ↓

┌────────────────────────────────────────────────────────────────────┐
│ BECOME A SERVICE PROVIDER                              Step 3 of 5 │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ ROLE-SPECIFIC DETAILS                                              │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ 📸 PHOTOGRAPHER                                                    │
│                                                                    │
│ Photography Styles: (select all that apply)                        │
│ ☑ Portrait  ☑ Event  ☑ Landscape  ☑ Street  ☐ Product           │
│                                                                    │
│ Equipment:                                                         │
│ Camera: [Canon EOS R5                                        ]   │
│ Lenses: [24-70mm, 70-200mm, 50mm                             ]   │
│ ☑ Drone available  ☑ Lighting equipment  ☑ Backup camera         │
│                                                                    │
│ Years of Experience: [8] years                                     │
│                                                                    │
│ Portfolio Website: (optional)                                      │
│ [https://pierrephotos.com                                     ]   │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ 👨‍🍳 PRIVATE CHEF                                                   │
│                                                                    │
│ Cuisine Specialties: (select all that apply)                       │
│ ☑ French  ☑ Italian  ☐ Asian  ☐ Mediterranean  ☑ Pastry         │
│                                                                    │
│ Dietary Accommodations:                                            │
│ ☑ Vegan  ☑ Vegetarian  ☑ Gluten-free  ☑ Kosher  ☐ Halal         │
│                                                                    │
│ Culinary Training/Certifications:                                  │
│ [Le Cordon Bleu Paris - 2012                                  ]   │
│ [Food Handler's License - Valid through 2027                  ]   │
│                                                                    │
│ Years of Experience: [12] years                                    │
│                                                                    │
│                         [← Back]  [Cancel]  [Continue →]          │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

                    ↓

┌────────────────────────────────────────────────────────────────────┐
│ BECOME A SERVICE PROVIDER                              Step 4 of 5 │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ VERIFICATION DOCUMENTS                                             │
│                                                                    │
│ Upload required documents for verification:                        │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ FOR PHOTOGRAPHER ROLE:                                             │
│                                                                    │
│ ✓ Portfolio / Work Samples (Required)                             │
│   [photography_portfolio.pdf] ✓ Uploaded                          │
│   [View] [Replace]                                                 │
│                                                                    │
│ ✓ Proof of Insurance (Required)                                   │
│   [insurance_certificate.pdf] ✓ Uploaded                          │
│   [View] [Replace]                                                 │
│                                                                    │
│ Equipment List (Optional)                                          │
│   [Upload Document]                                                │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ FOR PRIVATE CHEF ROLE:                                             │
│                                                                    │
│ ✓ Culinary Certification (Required)                               │
│   [cordon_bleu_diploma.pdf] ✓ Uploaded                            │
│   [View] [Replace]                                                 │
│                                                                    │
│ ✓ Food Handler's License (Required)                               │
│   [food_license.pdf] ✓ Uploaded                                   │
│   [View] [Replace]                                                 │
│                                                                    │
│ ☐ Liability Insurance (Recommended)                               │
│   [Upload Document]                                                │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ GENERAL VERIFICATION:                                              │
│                                                                    │
│ ☐ Government ID (Required for all providers)                      │
│   [Upload Document]                                                │
│                                                                    │
│ ☐ Background Check (Required for childcare, companions)           │
│   [Upload Document or Request Traveloure to Run]                  │
│                                                                    │
│ 💡 Verification typically takes 2-3 business days                  │
│                                                                    │
│                         [← Back]  [Cancel]  [Continue →]          │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

                    ↓

┌────────────────────────────────────────────────────────────────────┐
│ BECOME A SERVICE PROVIDER                              Step 5 of 5 │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ PAYMENT & LEGAL                                                    │
│                                                                    │
│ PAYOUT INFORMATION                                                 │
│                                                                    │
│ How would you like to receive payments?                            │
│                                                                    │
│ Bank Account:                                                      │
│ Account Holder: [Pierre Dubois                               ]   │
│ IBAN: [FR76 **** **** **** **** **45                         ]   │
│ Bank Name: [BNP Paribas                                      ]   │
│                                                                    │
│ OR                                                                 │
│                                                                    │
│ PayPal Email: [pierre@example.com                            ]   │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ TAX INFORMATION                                                    │
│                                                                    │
│ Are you a business entity?                                         │
│ ● Individual / Sole Proprietor                                    │
│ ○ Business / Company                                              │
│                                                                    │
│ Tax ID / VAT Number: (if applicable)                               │
│ [FR12345678901                                               ]   │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ TERMS & CONDITIONS                                                 │
│                                                                    │
│ ☑ I agree to Traveloure's Service Provider Terms                  │
│ ☑ I understand the 20% platform fee structure                     │
│ ☑ I agree to maintain current insurance & certifications          │
│ ☑ I will provide quality service to travelers                     │
│                                                                    │
│ Platform Fee: 20% per booking                                      │
│ Payout Schedule: Weekly (Fridays)                                 │
│ Minimum Payout: $50                                                │
│                                                                    │
│                    [← Back]  [Cancel]  [Submit Application]       │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

                    ↓ After submission

┌────────────────────────────────────────────────────────────────────┐
│ ✅ APPLICATION SUBMITTED!                                          │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ Thank you for applying to be a Traveloure Service Provider!        │
│                                                                    │
│ WHAT HAPPENS NEXT:                                                 │
│                                                                    │
│ 1. ⏱️ Document Review (1-2 business days)                         │
│    Our team will verify your credentials and documents             │
│                                                                    │
│ 2. ✅ Verification Process (1-2 business days)                     │
│    - Background check (if applicable)                              │
│    - Insurance verification                                        │
│    - Portfolio review                                              │
│                                                                    │
│ 3. 🎉 Approval & Profile Goes Live                                │
│    Once approved, you can start creating services and              │
│    accepting bookings!                                             │
│                                                                    │
│ Expected timeline: 3-5 business days                               │
│                                                                    │
│ You'll receive email updates at: pierre@example.com                │
│                                                                    │
│ WHILE YOU WAIT:                                                    │
│                                                                    │
│ ☐ Watch our Service Provider Tutorial Videos                      │
│ ☐ Join our Provider Community Forum                               │
│ ☐ Download the Provider Mobile App                                │
│ ☐ Read Best Practices Guide                                       │
│                                                                    │
│ Questions? Contact support@traveloure.com                          │
│                                                                    │
│ [View Application Status]  [Return to Homepage]                   │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

---

## TRAVELER DISCOVERY EXPERIENCE

### How Travelers Find Service Providers

```
┌────────────────────────────────────────────────────────────────────┐
│ FIND SERVICE PROVIDERS                                             │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ WHERE & WHAT?                                                      │
│                                                                    │
│ 📍 Location: [Paris, France                                   ▼]  │
│ 📅 Dates: [Jan 15 - Jan 22, 2026                              ]   │
│                                                                    │
│ BROWSE BY CATEGORY:                                                │
│                                                                    │
│ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐     │
│ │   📸    │ │   🚗    │ │   👨‍🍳    │ │   👶    │ │   🤝    │     │
│ │  Photo  │ │ Transport│ │  Chef   │ │ Childcare│ │Companion│     │
│ │  (847)  │ │  (234)  │ │  (156)  │ │  (98)   │ │  (143)  │     │
│ └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘     │
│                                                                    │
│ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐     │
│ │   🎭    │ │   💆    │ │   🐕    │ │   🎉    │ │   🗣️   │     │
│ │  Tours  │ │ Wellness│ │  Pets   │ │  Events │ │Language │     │
│ │  (423)  │ │  (187)  │ │  (67)   │ │  (112)  │ │  (201)  │     │
│ └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘     │
│                                                                    │
│ [View All 15 Categories]                                           │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ OR SEARCH FOR SPECIFIC SERVICE:                                    │
│                                                                    │
│ [🔍 What service do you need?                                 ]   │
│     Examples: "wedding photographer", "babysitter for 3 hours",   │
│     "private chef vegan dinner", "tour guide Louvre"              │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

                    ↓ User clicks "Photo (847)"

┌────────────────────────────────────────────────────────────────────┐
│ PHOTOGRAPHERS IN PARIS                                             │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│ Filters:                                                           │
│ Price: [Any ▼] | Availability: [Jan 15-22 ▼] | Rating: [4+ ⭐]   │
│ Style: [All ▼] | Language: [Any ▼]                                │
│                                                                    │
│ Sort by: [Recommended ▼]                                           │
│                                                                    │
│ Showing 847 photographers in Paris                                 │
│                                                                    │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                                                                    │
│ ┌──────────────────────────────────────────────────────────────┐ │
│ │ 🏆 TOP RATED                                                 │ │
│ ├──────────────────────────────────────────────────────────────┤ │
│ │                                                              │ │
│ │ [Photo]  PIERRE DUBOIS                                       │ │
│ │          Photographer • Private Chef                         │ │
│ │          ⭐ 4.9 (243 reviews)                                 │ │
│ │                                                              │ │
│ │          📸 Specializes in: Portrait, Event, Street          │ │
│ │          💬 Speaks: French, English                          │ │
│ │          📍 15km radius from Paris center                    │ │
│ │                                                              │ │
│ │          Services from: $150                                 │ │
│ │          • Portrait Session - $200                           │ │
│ │          • Engagement Shoot - $300                           │ │
│ │          • Wedding Photography - $1,200                      │ │
│ │                                                              │ │
│ │          ✓ Available Jan 15-22                               │ │
│ │          ✓ Verified • ✓ Background Checked • ✓ Insured      │ │
│ │                                                              │ │
│ │          [View Profile]  [View Services]  [Book Now]         │ │
│ │                                                              │ │
│ └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│ ┌──────────────────────────────────────────────────────────────┐ │
│ │ [Photo]  SOPHIE MARTIN                                       │ │
│ │          Photographer                                        │ │
│ │          ⭐ 5.0 (127 reviews)                                 │ │
│ │                                                              │ │
│ │          📸 Specializes in: Wedding, Couples, Engagement     │ │
│ │          💬 Speaks: French, English, Spanish                 │ │
│ │                                                              │ │
│ │          Services from: $180                                 │ │
│ │          • Couples Session - $250                            │ │
│ │          • Full Day Wedding - $1,500                         │ │
│ │                                                              │ │
│ │          ✓ Available Jan 18-22 only                          │ │
│ │                                                              │ │
│ │          [View Profile]  [View Services]  [Book Now]         │ │
│ └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
│ [Load More...]                                                     │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

---

## INTEGRATION WITH EXISTING SYSTEMS

### How Service Providers Plug Into Current Infrastructure

```
┌─────────────────────────────────────────────────────────────────┐
│ SYSTEM INTEGRATION OVERVIEW                                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ SERVICE PROVIDERS use the SAME infrastructure as Local Experts: │
│                                                                 │
│ 1. CONTRACT SYSTEM                                              │
│    • Service selection → Auto-generate contract                 │
│    • Same ContractMessage component                             │
│    • Same payment flow (Stripe)                                 │
│    • Same status tracking                                       │
│                                                                 │
│ 2. CHAT SYSTEM                                                  │
│    • Same WebSocket infrastructure                              │
│    • Same ChatInterface component                               │
│    • Same message types                                         │
│    • Real-time communication                                    │
│                                                                 │
│ 3. BOOKING FLOW                                                 │
│    • Browse providers → View profile → Select service           │
│    • Add to cart OR instant booking                             │
│    • Payment → Contract generated → Chat opens                  │
│    • Provider notified → Service delivered                      │
│                                                                 │
│ 4. DASHBOARD                                                    │
│    • Similar to /local-expert/dashboard                         │
│    • Service management                                         │
│    • Bookings calendar                                          │
│    • Earnings tracking                                          │
│    • Chat with travelers                                        │
│                                                                 │
│ 5. VERIFICATION SYSTEM                                          │
│    • Document upload                                            │
│    • Admin review                                               │
│    • Background checks (where required)                         │
│    • Badge system (Verified, Background Checked, Insured)      │
└─────────────────────────────────────────────────────────────────┘
```

### Database Extensions Needed

```sql
-- New Tables

CREATE TABLE service_provider_categories (
  id UUID PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(100) UNIQUE NOT NULL,
  description TEXT,
  icon VARCHAR(10),
  category_type VARCHAR(20), -- 'service_provider', 'local_expert', 'hybrid'
  is_active BOOLEAN DEFAULT true,
  verification_required BOOLEAN DEFAULT true,
  required_documents JSONB, -- Array of required doc types
  custom_fields JSONB, -- Category-specific profile fields
  service_templates JSONB, -- Pre-defined service templates
  display_order INT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE provider_roles (
  id UUID PRIMARY KEY,
  provider_id UUID REFERENCES users(id),
  category_id UUID REFERENCES service_provider_categories(id),
  verification_status VARCHAR(20), -- 'pending', 'approved', 'rejected'
  verification_documents JSONB,
  custom_field_values JSONB, -- Category-specific data
  is_primary_role BOOLEAN DEFAULT false,
  approved_at TIMESTAMP,
  approved_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_provider_roles_provider ON provider_roles(provider_id);
CREATE INDEX idx_provider_roles_category ON provider_roles(category_id);

-- Extend existing services table
ALTER TABLE services ADD COLUMN category_id UUID REFERENCES service_provider_categories(id);
ALTER TABLE services ADD COLUMN is_featured BOOLEAN DEFAULT false;
```

---

This creates a **flexible, scalable service provider system** that supports unlimited role types while maintaining the same proven infrastructure for contracts, payments, and communication. Admins can add new categories as the marketplace evolves, and providers can offer multiple types of services under one profile.

Would you like me to continue with specific implementation details for any particular category, or create the React components for the admin category management interface?
