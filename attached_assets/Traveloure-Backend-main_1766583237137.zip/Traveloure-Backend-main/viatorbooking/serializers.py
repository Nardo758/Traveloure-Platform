from rest_framework import serializers
from .models import ViatorDestination, ViatorProduct

class ViatorDestinationSerializer(serializers.ModelSerializer):
    class Meta:
        model = ViatorDestination
        fields = '__all__'

class ViatorProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = ViatorProduct
        fields = '__all__'