from ai_itinerary.service_utils import get_booking_hotels, get_car_rentals
from rest_framework import status, generics
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework.views import APIView
from ai_itinerary.models import *
from ai_itinerary.serializers import *
import requests
from ai_itinerary.utils import *
from datetime import datetime
import os
from dotenv import load_dotenv
import urllib.parse
from subscription.wallet_utils import get_client_ip, check_anonymous_api_usage, track_anonymous_api_usage
from subscription.wallet_utils import check_wallet_balance
from subscription.views import track_api_usage
from serviceproviderapp.models import AllService
from serviceproviderapp.serializers import AllServiceSerializer
from viatorbooking.models import ViatorProduct

load_dotenv()

SERP_API_KEY = os.getenv('SERP_API_KEY')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')

class AffiliateTripExploreAPIView(generics.CreateAPIView):
    queryset = Trip.objects.all()
    permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):

        client_ip = get_client_ip(request)

        if request.user.is_authenticated:
            user = request.user
            
            has_credits, message, current_credits, current_balance = check_wallet_balance(user, 0.50)
            if not has_credits:
                return Response({
                    "error": message,
                    "remaining_credits": current_credits,
                    "remaining_balance": current_balance,
                    "required_credits": 1,
                    "api_name": "affiliate_explore",
                    "user_type": "authenticated",
                    "recharge_url": "/plan/wallet/recharge/"
                }, status=402)
            
            # Deduct from wallet
            success, message, remaining_credits, remaining_balance = track_api_usage(user, "affiliate_explore", 0.50)
            if not success:
                return Response({
                    "error": message,
                    "remaining_credits": remaining_credits,
                    "remaining_balance": remaining_balance,
                    "required_credits": 1,
                    "api_name": "affiliate_explore",
                    "user_type": "authenticated",
                    "recharge_url": "/plan/wallet/recharge/"
                }, status=402)
            
            user_type = "authenticated"
            wallet_info = {
                'api_used': 'affiliate_explore',
                'credits_deducted': 1,
                'remaining_credits': remaining_credits,
                'remaining_balance': remaining_balance,
                'cost_deducted': 0.50,  # Keep for backward compatibility
                'user_type': 'authenticated'
            }
        else:
            # Anonymous user - check IP-based usage
            can_use, message = check_anonymous_api_usage(client_ip, "affiliate_explore")
            if not can_use:
                return Response({
                    "error": message,
                    "user_type": "anonymous",
                    "api_name": "affiliate_explore"
                }, status=429)  # Too Many Requests
            
            # Track anonymous usage
            success, message = track_anonymous_api_usage(client_ip, "affiliate_explore")
            if not success:
                return Response({
                    "error": "Error tracking API usage",
                    "user_type": "anonymous",
                    "api_name": "affiliate_explore"
                }, status=500)
            
            user_type = "anonymous"
            wallet_info = {
                'api_used': 'affiliate_explore',
                'cost_deducted': 0.00,
                'remaining_credits': None,
                'remaining_balance': None,
                'user_type': 'anonymous',
                'message': 'Free trial usage. Login to continue using our services.'
            }
        destination_id = request.data.get('destination_id')
        start_date = request.data.get('start_date')
        end_date = request.data.get('end_date')
        destination = request.data.get('destination')
        preferences = request.data.get('preferences', {})

        if not all([start_date, end_date, destination]):
            return Response({'error': 'start_date, end_date, and destination are required'}, status=400)

        user = request.user if request.user.is_authenticated else None

        trip = Trip.objects.create(
            user=user,
            start_date=start_date,
            end_date=end_date,
            destination=destination,
            preferences=preferences
        )

        # After trip creation
        places = []
        if destination_id:
            products = ViatorProduct.objects.filter(destinations__destination_id=destination_id).all()[:15]
            places = self.parse_viator_data(products)
        if not destination_id or not places:
            search_query = f"top tourist attractions in {destination}"
            places_params = {
                "engine": "google_maps",
                "q": search_query,
                "hl": "en",
                "gl": "in",
                "api_key": SERP_API_KEY,
            }

            try:
                place_data_raw = requests.get("https://serpapi.com/search", params=places_params).json()
                places = self.parse_places(place_data_raw)
            except Exception as e:
                place_data_raw = {'error': str(e)}
                places = []

        hotel_data = get_booking_hotels(city=destination,check_in_date=start_date,check_out_date=end_date)

        service_data = get_car_rentals(city=destination)

        AffiliateTrip.objects.create(
            trip=trip,
            place_data=places,
            hotel_data=hotel_data,
            service_data=service_data
        )
        services = AllService.objects.filter(location__icontains=destination, form_status='approved')
        other_services = None
        if services:
            other_services = AllServiceSerializer(services, many=True).data

        data = {
            "trip_id": trip.id,
            'places': places,
            'hotels': hotel_data,
            'services': service_data,
            'wallet_info': wallet_info,
            "other_services": other_services if other_services else []
        }

        return Response({'message': "Fetched Successfully", 'data': data, 'status': True}, status=200)
    
    def parse_places(self, data):
        results = []
        for p in data.get("local_results", []):
            if p.get('thumbnail') and p.get('website'):
                results.append({
                    'place_id': p.get('place_id'),
                    'name': p.get('title'),
                    'description': p.get('snippet', ''),
                    'address': p.get('address', ''),
                    'rating': p.get('rating', 0),
                    'image_url': p.get('thumbnail'),
                    'website_url': p.get('website'),
                    'metadata': {
                        'reviews_count': p.get('reviews', 0),
                        'hours': p.get('hours', {}),
                        'phone': p.get('phone', '')
                    }
                })
        return results
    def parse_viator_data(self, data):
        results = []
        for p in data:
            results.append({
            'place_id': p.id,
            'name': p.title,
            'description': p.description or '',
            'address': [{'latitude': d.latitude, 'longitude': d.longitude, 'name': d.name} for d in p.destinations.all()],
            'rating': getattr(p, 'rating', 0),  # if you add a rating field
            'image_url': p.images or '',
            'website_url': p.product_url or '',
            'metadata': {
                'pricing_info': p.pricing_info or {},
                'inclusions': p.inclusions or [],
                'exclusions': p.exclusions or [],
                'additional_info': p.additional_info or [],
                'itinerary': p.itinerary or {},
                'product_options': p.product_options or [],
            }
        })
        return results

class AffiliatePlatformBulkCreateAPIView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        serializer = AffiliatePlatformSerializer(data=request.data, many=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class AffiliatePlatformExploreAPIView(APIView):
    permission_classes = []  # Allow both authenticated and anonymous users
    """
    POST: expects {destination, start_date, end_date, origin (for flights, optional)}
    Returns: trip_id, places (from SERP/DB), hotels/cars/flights (from DB, with dynamic affiliate links)
    
    For Anonymous Users: Free, but only 1 time per IP address
    For Authenticated Users: $0.50 per API call from wallet
    """
    def post(self, request):
        
        # Get client IP
        client_ip = get_client_ip(request)
        
        # Check if user is authenticated
        if request.user.is_authenticated:
            # Authenticated user - use wallet system
            user = request.user
            
            has_credits, message, current_credits, current_balance = check_wallet_balance(user, 0.50)
            if not has_credits:
                return Response({
                    "error": message,
                    "remaining_credits": current_credits,
                    "remaining_balance": current_balance,
                    "required_credits": 1,
                    "api_name": "affiliate_explore",
                    "user_type": "authenticated",
                    "recharge_url": "/plan/wallet/recharge/"
                }, status=402)
            
            # Deduct from wallet
            success, message, remaining_credits, remaining_balance = track_api_usage(user, "affiliate_explore", 0.50)
            if not success:
                return Response({
                    "error": message,
                    "remaining_credits": remaining_credits,
                    "remaining_balance": remaining_balance,
                    "required_credits": 1,
                    "api_name": "affiliate_explore",
                    "user_type": "authenticated",
                    "recharge_url": "/plan/wallet/recharge/"
                }, status=402)
            
            user_type = "authenticated"
            wallet_info = {
                'api_used': 'affiliate_explore',
                'credits_deducted': 1,
                'remaining_credits': remaining_credits,
                'remaining_balance': remaining_balance,
                'cost_deducted': 0.50,  # Keep for backward compatibility
                'user_type': 'authenticated'
            }
        else:
            # Anonymous user - check IP-based usage
            can_use, message = check_anonymous_api_usage(client_ip, "affiliate_explore")
            if not can_use:
                return Response({
                    "error": message,
                    "user_type": "anonymous",
                    "api_name": "affiliate_explore"
                }, status=429)  # Too Many Requests
            
            # Track anonymous usage
            success, message = track_anonymous_api_usage(client_ip, "affiliate_explore")
            if not success:
                return Response({
                    "error": "Error tracking API usage",
                    "user_type": "anonymous",
                    "api_name": "affiliate_explore"
                }, status=500)
            
            user_type = "anonymous"
            wallet_info = {
                'api_used': 'affiliate_explore',
                'cost_deducted': 0.00,
                'remaining_credits': None,
                'remaining_balance': None,
                'user_type': 'anonymous',
                'message': 'Free trial usage. Login to continue using our services.'
            }
        destination = request.data.get('destination')
        start_date = request.data.get('start_date')
        end_date = request.data.get('end_date')
        origin = request.data.get('origin', 'Delhi')  # Default to 'Delhi' if not provided
        if not destination or not start_date or not end_date:
            return Response({'error': 'destination, start_date, end_date required'}, status=400)

        # 1. CREATE TRIP
        trip_data = {
            'title': f"Trip to {destination}",
            'start_date': datetime.strptime(start_date, '%Y-%m-%d').date(),
            'end_date': datetime.strptime(end_date, '%Y-%m-%d').date(),
            'destination': destination,
            'status': 'draft'
        }
        
        # Set user if request is authenticated
        if request.user.is_authenticated:
            trip_data['user'] = request.user
            
        trip = Trip.objects.create(**trip_data)

        # 2. CHECK FOR EXISTING PLACES IN DB
        existing_places = TripSelectedPlace.objects.filter(
            trip__destination__iexact=destination
        ).values('place_id', 'name', 'description', 'address', 'rating', 'image_url', 'website_url', 'metadata')
        
        if existing_places.exists():
            # Use existing places from DB
            places = []
            for place in existing_places:
                places.append({
                    'place_id': place['place_id'],
                    'name': place['name'],
                    'description': place['description'] or '',
                    'address': place['address'] or '',
                    'rating': place['rating'] or 0,
                    'image_url': place['image_url'] or '',
                    'website_url': place['website_url'] or '',
                    'metadata': place['metadata'] or {}
                })
        else:
            # 3. FETCH PLACES from SERP API
            search_query = f"top tourist attractions in {destination}"
            places_params = {
                "engine": "google_maps",
                "q": search_query,
                "hl": "en",
                "gl": "in",
                "api_key": SERP_API_KEY,
                "location": destination
            }
            try:
                place_data_raw = requests.get("https://serpapi.com/search", params=places_params).json()
                places = self.parse_places(place_data_raw)
                
                # 4. SAVE PLACES TO DB for future use
                for place in places:
                    TripSelectedPlace.objects.create(
                        trip=trip,
                        place_id=place['place_id'],
                        name=place['name'],
                        description=place['description'],
                        address=place['address'],
                        rating=place['rating'],
                        image_url=place['image_url'],
                        website_url=place['website_url'],
                        metadata=place['metadata']
                    )
            except Exception as e:
                places = []

        # 5. HOTELS from DB
        hotels = self.get_affiliate_results('hotel', destination, start_date, end_date)
        # 6. CARS from DB
        cars = self.get_affiliate_results('car', destination, start_date, end_date)
        # 7. FLIGHTS from DB (needs origin)
        flights = []
        if origin:
            flights = self.get_affiliate_results('flight', destination, start_date, end_date, origin=origin)

        services = AllService.objects.filter(location__icontains=destination, form_status='approved')
        if services:
            other_services = AllServiceSerializer(services, many=True).data
        else:
            other_services = [
        {
            "id": "dddffdb4-5bab-41b9-89ec-223a403b89f6",
            "user": {
                "id": "My ID",
                "username": "My Username",
                "first_name": "Service",
                "last_name": "Provider",
                "image": None,
                "about_me": None
            },
            "location": "india",
            "service_file": None,
            "service_name": "Baby Sitting",
            "service_type": "Baby",
            "price": "100",
            "price_based_on": "per day",
            "description": "Baby Lover",
            "availability": [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday"
            ],
            "created_at": "2025-09-15T16:41:25.663840Z",
            "form_status": "approved"
        }
    ]


        return Response({
            'trip_id': str(trip.id),
            'places': places,
            'hotels': hotels,
            'cars': cars,
            'flights': flights,
            'wallet_info': wallet_info,
            "other_services": other_services
        }, status=200)

    def parse_places(self, data):
        results = []
        for p in data.get("local_results", []):
            if p.get('thumbnail') and p.get('website'):
                results.append({
                    'place_id': p.get('place_id'),
                    'name': p.get('title'),
                    'description': p.get('snippet', ''),
                    'address': p.get('address', ''),
                    'rating': p.get('rating', 0),
                    'image_url': p.get('thumbnail'),
                    'website_url': p.get('website'),
                    'metadata': {
                        'reviews_count': p.get('reviews', 0),
                        'hours': p.get('hours', {}),
                        'phone': p.get('phone', '')
                    }
                })
        return results

    def get_affiliate_results(self, platform, destination, start_date, end_date, origin=None):
        qs = AffiliatePlatform.objects.filter(platform=platform)
        results = []
        for plat in qs:
            affiliate_link = self.generate_affiliate_link(plat, platform, destination, start_date, end_date, origin)
            if affiliate_link is not None:  # Only include results with valid affiliate links
                results.append({
                    'title': plat.title,
                    'image_url': plat.image_url,
                    'platform': plat.platform,
                    'affiliate_link': affiliate_link
                })
        return results

    def generate_affiliate_link(self, plat, platform, destination, start_date, end_date, origin=None):

        awin_mid = "6776"
        awin_aff_id = "1525451"
        url = plat.base_url

        # Static airport mapping (expand as needed)
        airports = {
            "delhi": "Delhi (DEL - Indira Gandhi Intl.)",
            "goa": "Goa (GOI - All Airports)"
            # Add more as needed
        }

        # Helper function to safely format URL with fallback parameters
        def safe_format_url(template, **kwargs):
            try:
                return template.format(**kwargs)
            except KeyError as e:
                # If a key is missing, try with a subset of parameters
                missing_key = str(e).strip("'")
                # Remove the problematic key from kwargs and try again
                kwargs_copy = kwargs.copy()
                if missing_key in kwargs_copy:
                    del kwargs_copy[missing_key]
                try:
                    return template.format(**kwargs_copy)
                except KeyError:
                    # If still failing, return None
                    return None

        if platform == 'car':
            if "expedia" in plat.title.lower():
                pickup_date = datetime.strptime(start_date, "%Y-%m-%d").strftime("%m%%2F%d%%2F%Y")
                return_date = datetime.strptime(end_date, "%Y-%m-%d").strftime("%m%%2F%d%%2F%Y")
                url = f"https://www.expedia.com/carsearch?date1={pickup_date}&date2={return_date}&time1=1030AM&time2=1230PM&locn={urllib.parse.quote_plus(destination)}"
            elif "rentalcars" in plat.title.lower():
                # Build RentalCars URL manually like in zzz.py
                pickup_date_str = datetime.strptime(start_date, "%Y-%m-%d").strftime("%Y-%m-%d")
                return_date_str = datetime.strptime(end_date, "%Y-%m-%d").strftime("%Y-%m-%d")
                url = f"https://www.rentalcars.com/search?locationName={urllib.parse.quote_plus(destination)}&pickUpDate={pickup_date_str}&pickUpTime=10%3A30&dropOffDate={return_date_str}&dropOffTime=12%3A30&driverAge=30"
            elif "booking" in plat.title.lower():
                pickup_date_str = datetime.strptime(start_date, "%Y-%m-%d").strftime("%Y-%m-%d")
                return_date_str = datetime.strptime(end_date, "%Y-%m-%d").strftime("%Y-%m-%d")
                url = f"https://www.booking.com/cars/index.html?ss={urllib.parse.quote(destination)}&pickup_date={pickup_date_str}&pickup_time=10%3A30&dropoff_date={return_date_str}&dropoff_time=12%3A30&age=30"
            else:
                # Fallback to template formatting
                url = safe_format_url(url,
                    pickup_date=start_date,
                    return_date=end_date,
                    city=urllib.parse.quote_plus(destination),
                    pickup_date_formatted=start_date,
                    return_date_formatted=end_date
                )

        elif platform == 'flight' and origin:
            origin_full = airports.get(origin.lower(), origin)
            destination_full = airports.get(destination.lower(), destination)
            
            if "expedia" in plat.title.lower():
                expedia_date = datetime.strptime(start_date, "%Y-%m-%d").strftime("%m/%d/%Y")
                # Build Expedia URL manually like in zzz.py
                url = (
                    f"https://www.expedia.com/Flights-Search?"
                    f"leg1=from:{urllib.parse.quote(origin_full)},"
                    f"to:{urllib.parse.quote(destination_full)},"
                    f"departure:{expedia_date}TANYT,fromType:A,toType:M"
                    f"&mode=search&options=carrier:,cabinclass:,maxhops:1,nopenalty:N"
                    f"&pageId=0&passengers=adults:1,children:0,infantinlap:N"
                    f"&trip=oneway"
                )
            elif "booking" in plat.title.lower():
                dep_date_str = datetime.strptime(start_date, "%Y-%m-%d").strftime("%Y-%m-%d")
                # Build Booking.com URL manually like in zzz.py
                url = f"https://flights.booking.com/flights/{origin.lower()}.AIRPORT-{destination.lower()}.AIRPORT/?type=ONEWAY&adults=1&cabinClass=ECONOMY&from={origin.lower()}.AIRPORT&to={destination.lower()}.AIRPORT&depart={dep_date_str}&sort=BEST&travelPurpose=leisure"
            elif "kiwi" in plat.title.lower():
                # Build Kiwi.com URL manually like in zzz.py but use actual destination
                # Extract country from destination or use a default
                country_suffix = "-india-1"  # Default fallback
                if destination.lower() in ["oakland", "san francisco", "los angeles", "new york"]:
                    country_suffix = "-united-states-1"
                elif destination.lower() in ["london", "manchester"]:
                    country_suffix = "-united-kingdom-1"
                elif destination.lower() in ["paris", "lyon"]:
                    country_suffix = "-france-1"
                elif destination.lower() in ["berlin", "munich"]:
                    country_suffix = "-germany-1"
                elif destination.lower() in ["toronto", "vancouver"]:
                    country_suffix = "-canada-1"
                
                # Determine origin country suffix
                origin_country_suffix = "-india-1"  # Default fallback
                if origin.lower() in ["oakland", "san francisco", "los angeles", "new york"]:
                    origin_country_suffix = "-united-states-1"
                elif origin.lower() in ["london", "manchester"]:
                    origin_country_suffix = "-united-kingdom-1"
                elif origin.lower() in ["paris", "lyon"]:
                    origin_country_suffix = "-france-1"
                elif origin.lower() in ["berlin", "munich"]:
                    origin_country_suffix = "-germany-1"
                elif origin.lower() in ["toronto", "vancouver"]:
                    origin_country_suffix = "-canada-1"
                
                url = f"https://www.kiwi.com/en/?origin={origin.lower()}{origin_country_suffix}&destination={destination.lower()}{country_suffix}&outboundDate=anytime&inboundDate=no-return"
            else:
                # Fallback to template formatting
                url = safe_format_url(url,
                    origin=origin,
                    destination=destination,
                    depart=start_date,
                    origin_name=origin,
                    destination_name=destination
                )

        elif platform == 'hotel':
            if "booking" in plat.title.lower():
                url = f"https://www.booking.com/searchresults.html?ss={urllib.parse.quote(destination)}&checkin={start_date}&checkout={end_date}&group_adults=2&no_rooms=1&sb_travel_purpose=leisure"
            elif "expedia" in plat.title.lower():
                url = f"https://www.expedia.com/Hotel-Search?destination={urllib.parse.quote_plus(destination)}&startDate={start_date}&endDate={end_date}&rooms=1&adults=2"
            elif "hotels" in plat.title.lower():
                url = f"https://www.hotels.com/Hotel-Search?destination={urllib.parse.quote_plus(destination)}&d1={start_date}&d2={end_date}&adults=2&rooms=1"
            else:
                # Fallback to template formatting
                url = safe_format_url(url,
                city=urllib.parse.quote_plus(destination),
                checkin=start_date,
                    checkout=end_date,
                    city_name=urllib.parse.quote_plus(destination),
                    checkin_date=start_date,
                    checkout_date=end_date
            )

        if url is None:
            return None
            
        try:
            encoded_url = urllib.parse.quote(url, safe='')
            affiliate_link = f"https://www.awin1.com/cread.php?awinmid={awin_mid}&awinaffid={awin_aff_id}&p={encoded_url}"
            return affiliate_link
        except Exception as e:
            # Log the error and return a fallback URL
            return None

class AffiliatePlatformBulkUpsertAPIView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        data = request.data
        if not isinstance(data, list):
            return Response({'error': 'Payload must be a list'}, status=400)
        results = []
        for item in data:
            title = item.get('title')
            platform = item.get('platform')
            if not title or not platform:
                continue
            obj, created = AffiliatePlatform.objects.update_or_create(
                title=title, platform=platform,
                defaults={
                    'image_url': item.get('image_url', ''),
                    'base_url': item.get('base_url', '')
                }
            )
            results.append({
                'id': str(obj.id),
                'title': obj.title,
                'image_url': obj.image_url,
                'platform': obj.platform,
                'base_url': obj.base_url,
                'created_at': obj.created_at
            })
        return Response({'results': results}, status=200)
