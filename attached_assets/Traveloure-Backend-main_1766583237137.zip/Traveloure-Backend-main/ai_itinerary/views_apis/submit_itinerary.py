from rest_framework import generics, permissions
from ai_itinerary.models import SubmitItineraryFeedback,  UserAndExpertChat
from ai_itinerary.serializers import SubmitItineraryFeedbackSerializer, UserAndExpertChatSerializer
from rest_framework.exceptions import PermissionDenied
from subscription.models import UserAndExpertContract
from rest_framework.response import Response
from django.db.models import Q
from rest_framework import status
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.utils import timezone
import logging

logger = logging.getLogger(__name__)

class SubmitItineraryFeedbackCreateView(generics.CreateAPIView):
    serializer_class = SubmitItineraryFeedbackSerializer
    permission_classes = [permissions.IsAuthenticated]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        if not self.request.user.is_local_expert:
            return Response({"message": "Only Local experts can submit itinerary","status":False}, status=status.HTTP_400_BAD_REQUEST)
        user = self.request.user
        contract = (
            UserAndExpertContract.objects
            .filter(Q(created_by=user) | Q(created_for=user))
            .order_by('-created_at')
            .first()
        )
        if not contract:
            return Response({"message": "No valid contract found.","status":False}, status=status.HTTP_400_BAD_REQUEST)

        if not contract.is_paid or contract.status != 'accepted':
            return Response({"message": "Contract must be paid and accepted.","status":False}, status=status.HTTP_400_BAD_REQUEST)

        # Proceed to create the feedback, associating it with the contract
        instance = serializer.save(expert=user, contract=contract)
        chat_obj = UserAndExpertChat.objects.create(sender=user, receiver=contract.created_by if contract.created_for == user else contract.created_for, itinerary_submit = instance)

        self.broadcast_new_itienrart_submit(chat_obj=chat_obj, request=request)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    
    def chat_group_name(self, a_id, b_id) -> str:
        a, b = sorted([str(a_id), str(b_id)])
        return f"chat_{a}_{b}"

    def broadcast_new_itienrart_submit(self, chat_obj, request):
        try:
            channel_layer = get_channel_layer()
            if channel_layer is None:
                logger.error("Channel layer is None, cannot send WebSocket message")
                return
                
            # Pass request context to serializer for proper URL building
            data = UserAndExpertChatSerializer(chat_obj, context={'request': request}).data
            sender_id = chat_obj.sender_id
            receiver_id = chat_obj.receiver_id
        
            # Receiver notification
            async_to_sync(channel_layer.group_send)(
                f"user_{receiver_id}",
                {"type": "new_message_notification", "payload": data}
            )
            async_to_sync(channel_layer.group_send)(
                f"user_{sender_id}",
                {"type": "new_message_notification", "payload": data}
            )
        
            # Room broadcast
            room = self.chat_group_name(sender_id, receiver_id)
            async_to_sync(channel_layer.group_send)(
                room,
                {"type": "new_submit_itinerary", "payload": data}
            )
            
            logger.info(f"Broadcasted new itinerary submission from {sender_id} to {receiver_id}")
            
        except Exception as e:
            logger.error(f"Error broadcasting new itinerary submission: {e}")


class SubmitItineraryFeedbackDetailView(generics.RetrieveAPIView):
    queryset = SubmitItineraryFeedback.objects.all()
    serializer_class = SubmitItineraryFeedbackSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, *args, **kwargs):
        feedback = self.get_object()
        return Response(self.get_serializer(feedback).data, status=status.HTTP_200_OK)


class SubmitItineraryFeedbackUpdateView(generics.UpdateAPIView):
    queryset = SubmitItineraryFeedback.objects.all()
    serializer_class = SubmitItineraryFeedbackSerializer
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, *args, **kwargs):
        feedback = self.get_object()
        if feedback.expert != request.user:
            return Response({"detail": "You cannot Perform this action"},
                            status=status.HTTP_403_FORBIDDEN)
        request.data.pop('status', None)
        return super().patch(request, *args, **kwargs)


class SubmitItineraryFeedbackDeleteView(generics.DestroyAPIView):
    queryset = SubmitItineraryFeedback.objects.all()
    permission_classes = [permissions.IsAuthenticated]

class SubmitItineraryDecisionAPIView(generics.UpdateAPIView):
    queryset = SubmitItineraryFeedback.objects.all()
    serializer_class = SubmitItineraryFeedbackSerializer
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, *args, **kwargs):
        feedback = self.get_object()

        # Check if the status in the request data is valid (either 'accepted' or 'rejected')
        status_value = request.data.get('status')
        if status_value not in ['accepted', 'rejected']:
            return Response({"detail": "Status must be either 'accepted' or 'rejected'."},
                            status=status.HTTP_400_BAD_REQUEST)

        # Proceed to update the status
        feedback.status = status_value
        feedback.save()
        self.broadcast(user=request.user,decision=status_value,instance=feedback)
        self.broadcast(user=feedback.expert,decision=status_value,instance=feedback)
        # Return the updated feedback data
        return Response(self.get_serializer(feedback).data, status=status.HTTP_200_OK)
    
    def broadcast(self, user, decision, instance):
        try:
            channel_layer = get_channel_layer()
            if channel_layer is None:
                logger.error("Channel layer is None, cannot send WebSocket message")
                return
                
            # Send to user's personal group
            async_to_sync(channel_layer.group_send)(
                f"user_{user.id}",
                {
                    "type": f"submit_itinerary_{decision}",
                    "payload": {
                        "id": str(instance.id),
                        "title": instance.title,
                        "message": "Submitted itinerary was " + decision.title(),
                        "status": decision,
                        "timestamp": str(timezone.now()),
                        "expert_id": str(instance.expert.id),
                        "contract_id": str(instance.contract.id)
                    }
                }
            )
            
            # Also send to chat room if both users are in the same chat
            if hasattr(instance, 'contract'):
                other_user = instance.contract.created_by if instance.contract.created_for == user else instance.contract.created_for
                room = self.chat_group_name(user.id, other_user.id)
                async_to_sync(channel_layer.group_send)(
                    room,
                    {
                        "type": f"submit_itinerary_{decision}",
                        "payload": {
                            "id": str(instance.id),
                            "title": instance.title,
                            "message": "Submitted itinerary was " + decision.title(),
                            "status": decision,
                            "timestamp": str(timezone.now())
                        }
                    }
                )
                
        except Exception as e:
            logger.error(f"Error broadcasting WebSocket message: {e}")