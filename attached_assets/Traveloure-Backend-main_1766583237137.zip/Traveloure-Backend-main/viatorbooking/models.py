from django.db import models

class ViatorDestination(models.Model):
    destination_id = models.PositiveIntegerField(unique=True, db_index=True)  # indexed
    name = models.CharField(null=True, blank=True, db_index=True)  # optional index
    type = models.CharField(null=True, blank=True, db_index=True)  # optional index
    parent_destination_id = models.PositiveIntegerField(null=True, blank=True, db_index=True)
    lookup_id = models.CharField(null=True, blank=True, db_index=True)
    destination_url = models.URLField(null=True, blank=True)
    default_currency_code = models.CharField(null=True, blank=True)
    time_zone = models.CharField(null=True, blank=True)
    country_calling_code = models.CharField(null=True, blank=True)
    languages = models.JSONField(default=list)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)

    def __str__(self):
        return f"{self.name} ({self.destination_id})"


class ViatorProduct(models.Model):
    product_code = models.CharField(max_length=100, unique=True, db_index=True)  # indexed
    title = models.CharField(null=True, blank=True, db_index=True)  # optional index
    status = models.CharField(null=True, blank=True, db_index=True)
    pricing_info = models.JSONField()  # dict
    images = models.JSONField(default=list)  # list of image URLs or dicts
    time_zone = models.CharField(null=True, blank=True, db_index=True)
    description = models.TextField(null=True, blank=True)
    inclusions = models.JSONField(default=list)
    exclusions = models.JSONField(default=list)
    additional_info = models.JSONField(default=list)
    destinations = models.ManyToManyField(
        ViatorDestination, 
        related_name="products",
        db_index=True  # adds an index to the intermediate table
    )
    itinerary = models.JSONField()  # dict
    product_options = models.JSONField(default=list)
    product_url = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.title} ({self.product_code})"
