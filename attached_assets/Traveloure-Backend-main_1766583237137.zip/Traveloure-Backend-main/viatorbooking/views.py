from rest_framework import generics
from rest_framework.response import Response
from .models import ViatorDestination, ViatorProduct
from .serializers import ViatorDestinationSerializer, ViatorProductSerializer
from authentication.utils import CustomPagination
from subscription.wallet_utils import get_client_ip, check_anonymous_api_usage, track_anonymous_api_usage
from subscription.wallet_utils import check_wallet_balance
from subscription.views import track_api_usage
from serviceproviderapp.models import AllService
from serviceproviderapp.serializers import AllServiceSerializer
from ai_itinerary.models import Trip, AffiliateTrip
import requests
from ai_itinerary.service_utils import get_booking_hotels, get_car_rentals
import os
from dotenv import load_dotenv
import urllib.parse
from rest_framework.permissions import AllowAny

load_dotenv()

SERP_API_KEY = os.getenv('SERP_API_KEY')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
class ViatorDestinationViewSet(generics.ListAPIView):
    queryset = ViatorDestination.objects.all()
    serializer_class = ViatorDestinationSerializer
    permission_classes = []
    authentication_classes = []
    pagination_class = None

    def list(self, request, *args, **kwargs):
        search = request.query_params.get("search")
        if not search:
            return Response(
                {
                    "message": "Please provide the 'search' parameter",
                    "data": [],
                    "status": False,
                },
                status=400,
            )

        queryset = self.get_queryset().filter(name__icontains=search)
        serializer = self.get_serializer(queryset, many=True)

        if not queryset.exists():
            return Response(
                {
                    "message": "No destinations found matching your search",
                    "data": [],
                    "status": False,
                },
                status=404,
            )

        return Response(
            {
                "message": "Fetched similar found destinations",
                "data": serializer.data,
                "status": True,
            },
            status=200,
        )


class ViatorProductViewSet(generics.ListAPIView):
    queryset = ViatorProduct.objects.all()
    serializer_class = ViatorProductSerializer
    permission_classes = []
    authentication_classes = []
    pagination_class = CustomPagination

    def get_queryset(self):
        destination_id = self.request.query_params.get("destination_id")
        if destination_id:
            return self.queryset.filter(destinations__destination_id=destination_id).all()
        return self.queryset



class TripAPIView(generics.CreateAPIView):
    permission_classes = [AllowAny]
    # authentication_classes = []
    pagination_class = None


    def create(self, request, *args, **kwargs):

        client_ip = get_client_ip(request)
        if request.user.is_authenticated:
            user = request.user
            
            has_credits, message, current_credits, current_balance = check_wallet_balance(user, 0.50)
            if not has_credits:
                return Response({
                    "error": message,
                    "remaining_credits": current_credits,
                    "remaining_balance": current_balance,
                    "required_credits": 1,
                    "api_name": "affiliate_explore",
                    "user_type": "authenticated",
                    "recharge_url": "/plan/wallet/recharge/"
                }, status=402)
            
            # Deduct from wallet
            success, message, remaining_credits, remaining_balance = track_api_usage(user, "affiliate_explore", 0.50)
            if not success:
                return Response({
                    "error": message,
                    "remaining_credits": remaining_credits,
                    "remaining_balance": remaining_balance,
                    "required_credits": 1,
                    "api_name": "affiliate_explore",
                    "user_type": "authenticated",
                    "recharge_url": "/plan/wallet/recharge/"
                }, status=402)
            
            user_type = "authenticated"
            wallet_info = {
                'api_used': 'affiliate_explore',
                'credits_deducted': 1,
                'remaining_credits': remaining_credits,
                'remaining_balance': remaining_balance,
                'cost_deducted': 0.50,  # Keep for backward compatibility
                'user_type': 'authenticated'
            }
        else:
            # Anonymous user - check IP-based usage
            can_use, message = check_anonymous_api_usage(client_ip, "affiliate_explore")
            if not can_use:
                return Response({
                    "error": message,
                    "user_type": "anonymous",
                    "api_name": "affiliate_explore"
                }, status=429)  # Too Many Requests
            
            # Track anonymous usage
            success, message = track_anonymous_api_usage(client_ip, "affiliate_explore")
            if not success:
                return Response({
                    "error": "Error tracking API usage",
                    "user_type": "anonymous",
                    "api_name": "affiliate_explore"
                }, status=500)
            
            user_type = "anonymous"
            wallet_info = {
                'api_used': 'affiliate_explore',
                'cost_deducted': 0.00,
                'remaining_credits': None,
                'remaining_balance': None,
                'user_type': 'anonymous',
                'message': 'Free trial usage. Login to continue using our services.'
            }
        destination_id = request.data.get('destination_id')
        start_date = request.data.get('start_date')
        end_date = request.data.get('end_date')
        destination = request.data.get('destination')
        preferences = request.data.get('preferences', {})

        if not all([start_date, end_date, destination]):
            return Response({'error': 'start_date, end_date, and destination are required'}, status=400)

        user = request.user if request.user.is_authenticated else None

        trip = Trip.objects.create(
            user=user,
            start_date=start_date,
            end_date=end_date,
            destination=destination,
            preferences=preferences
        )

        # After trip creation
        places = []
        if destination_id:
            products = ViatorProduct.objects.filter(destinations__destination_id=destination_id).all()
            places = self.parse_viator_data(products)
        if not destination_id or not places:
            search_query = f"top tourist attractions in {destination}"
            places_params = {
                "engine": "google_maps",
                "q": search_query,
                "hl": "en",
                "gl": "in",
                "api_key": SERP_API_KEY,
            }

            try:
                place_data_raw = requests.get("https://serpapi.com/search", params=places_params).json()
                places = self.parse_places(place_data_raw)
            except Exception as e:
                place_data_raw = {'error': str(e)}
                places = []

        hotel_data = get_booking_hotels(city=destination,check_in_date=start_date,check_out_date=end_date)

        service_data = get_car_rentals(city=destination)

        AffiliateTrip.objects.create(
            trip=trip,
            place_data=places,
            hotel_data=hotel_data,
            service_data=service_data
        )
        services = AllService.objects.filter(location__icontains=destination, form_status='approved')
        other_services = None
        if services:
            other_services = AllServiceSerializer(services, many=True).data

        data = {
            "trip_id": trip.id,
            'places': places,
            'hotels': hotel_data,
            'services': service_data,
            'wallet_info': wallet_info,
            "other_services": other_services if other_services else []
        }

        return Response({'message': "Fetched Successfully", 'data': data, 'status': True}, status=200)
    
    def parse_places(self, data):
        results = []
        for p in data.get("local_results", []):
            if p.get('thumbnail') and p.get('website'):
                results.append({
                    'place_id': p.get('place_id'),
                    'name': p.get('title'),
                    'description': p.get('snippet', ''),
                    'address': p.get('address', ''),
                    'rating': p.get('rating', 0),
                    'image_url': p.get('thumbnail'),
                    'website_url': p.get('website'),
                    'metadata': {
                        'reviews_count': p.get('reviews', 0),
                        'hours': p.get('hours', {}),
                        'phone': p.get('phone', '')
                    }
                })
        return results
    def parse_viator_data(self, data):
        results = []
        for p in data:
            results.append({
            'place_id': p.id,
            'name': p.title,
            'description': p.description or '',
            'address': [{'latitude': d.latitude, 'longitude': d.longitude, 'name': d.name} for d in p.destinations.all()],
            'rating': getattr(p, 'rating', 0),  # if you add a rating field
            'image_url': p.images or '',
            'website_url': p.product_url or '',
            'metadata': {
                'pricing_info': p.pricing_info or {},
                'inclusions': p.inclusions or [],
                'exclusions': p.exclusions or [],
                'additional_info': p.additional_info or [],
                'itinerary': p.itinerary or {},
                'product_options': p.product_options or [],
            }
        })
        return results