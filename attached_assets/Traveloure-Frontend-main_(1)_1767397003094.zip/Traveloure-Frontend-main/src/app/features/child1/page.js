import React from 'react'

function page() {
  return (
    <div>
      features child1 
    </div>
  )
}

export default page
